window.XBOARD_TRANSLATIONS = window.XBOARD_TRANSLATIONS || {};
window.XBOARD_TRANSLATIONS['zh-CN'] = {
  "ddns": {
    "selfHosted": "自建服务",
    "serverId": "服务器 ID",
    "apiUrl": "PowerDNS API 地址",
    "provider": "DNS 服务商",
    "ttl": "DNS TTL（秒）",
    "followUserStatus": "跟随用户状态",
    "personalEnabled": "用户独立域名",
    "expected": "预计使用",
    "title": "DDNS 设置",
    "enabled": "启用 DDNS",
    "preset": "域名配置",
    "prefix": "节点前缀",
    "choose": "请选择",
    "manualIp": "统一入口连接 IP",
    "baseDomain": "基础域名",
    "inherited": "域名设置使用所选前置入口的配置",
    "synced": "已同步",
    "pending": "准备中",
    "error": "同步失败",
    "name": "名称",
    "domain": "可用域名",
    "zoneId": "Zone ID",
    "token": "API Token",
    "keepToken": "留空保留已有凭据",
    "addPreset": "添加域名配置",
    "save": "保存",
    "cancel": "取消",
    "edit": "编辑",
    "delete": "删除",
    "deleteConfirm": "确定删除此域名配置？正在使用的配置无法删除。",
    "refresh": "刷新",
    "failed": "操作失败，请重试",
    "loading": "加载中",
    "capacity": "记录用量 / 额度",
    "accountQuota": "账户级额度",
    "unchecked": "未检查",
    "check": "检查解析",
    "actions": "操作",
    "bindings": "节点域名",
    "node": "节点或前置池",
    "records": "托管记录数",
    "status": "状态",
    "deletedNode": "已删除节点",
    "cleaning": "正在清理",
    "retained": "保留旧解析",
    "sync": "重新同步",
    "cleanup": "清理解析",
    "cleanupConfirm": "清理后，使用这些旧域名的客户端将无法连接。确定清理？"
  },
  "balancer": {
    "dynamicLoad": "动态负载分配",
    "bandwidthThreshold": "带宽利用率阈值（%）",
    "connectionThreshold": "活跃连接数阈值",
    "loadConfirm": "持续确认时间（秒）",
    "loadCooldown": "改派冷却时间（秒）",
    "carrierRouting": "运营商 DNS 分流",
    "carrierLines": "运营商线路",
    "availableBandwidth": "可用带宽（Mbps）",
    "useConnections": "留空按连接数",
    "carrierNotReady": "权威 DNS 尚未完成运营商分流配置",
    "carrierDataUnavailable": "运营商网段库不可用或已过期",
    "bandwidthLoad": "带宽利用率 {{value}}%",
    "connectionLoad": "活跃连接 {{value}}",
    "loadUnavailable": "负载数据不可用，保持分配",
    "linkStates": "各落地链路状态",
    "dynamicLoadRule": "同优先级按平滑后的负载分配；带宽留空时按连接数。持续超阈值后逐步改派，缺测时保持已有分配。",
    "carriers": {"default": "默认", "telecom": "电信", "unicom": "联通", "mobile": "移动"},
    "trafficLite": "Lite 流量",
    "trafficLocal": "本地流量",
    "trafficUnavailable": "数据暂不可用",
    "trafficUnlimited": "不限流量",
    "trafficRemaining": "剩余 {{percent}}%",
    "quotaLow": "剩余流量不足",
    "scheduling": "自动调度",
    "healthCheck": "链路健康探测",
    "quotaScheduling": "剩余流量调度",
    "selectionStrategy": "前置选择方式",
    "manualPriority": "同优先级按权重分配",
    "lowestLatency": "最低延迟单台优先",
    "quotaPercent": "退出候选的剩余流量（%）",
    "latencyTarget": "测速落地",
    "bindLatencyTarget": "先在节点管理中给该池绑定 TCP 落地，再选择测速目标。",
    "landings": "落地主备",
    "events": "切换记录",
    "createLandingPool": "新建落地池",
    "editLandingPool": "编辑落地池",
    "subscriptionLine": "订阅线路",
    "landingPoolHelp": "用户继续使用原订阅线路。按顺序选择可用落地，主落地稳定恢复后自动切回。",
    "primaryLanding": "主落地",
    "backupLanding": "备用 {{index}}",
    "moveUp": "上移",
    "moveDown": "下移",
    "searchLandings": "搜索落地名称或 IP",
    "activeLanding": "当前落地",
    "noActiveLanding": "没有可用落地",
    "deleteLandingPoolHelp": "删除主备配置后恢复原落地，不删除任何节点。确认删除？",
    "noLandingPools": "暂无落地池",
    "eventTime": "时间",
    "eventReason": "原因",
    "previousSelection": "切换前",
    "currentSelection": "切换后",
    "noAvailableMembers": "无可用成员",
    "noEvents": "暂无切换记录",
    "reason": {
      "link_failed": "链路失败",
      "probe_stale": "探测已过期",
      "healthy": "可用",
      "offline": "离线或流量保护",
      "disabled": "已停用",
      "incompatible": "参数不兼容",
      "no_address": "没有有效地址",
      "port_failed": "端口不可达",
      "probe_pending": "等待探测结果",
      "latency_failed": "测速目标不可达",
      "agent_required": "需升级 Agent",
      "heartbeat_only": "按节点状态判断"
    },
    "event": {
      "selection_changed": "前置候选变化",
      "landing_changed": "落地主备切换",
      "dns_failed": "DNS 同步失败",
      "dns_recovered": "DNS 同步恢复"
    },
    "dnsPriorityRule": "数字越小越优先；在可用同级节点中按权重稳定分配用户。",
    "dnsMode": "DNS 调度",
    "serverId": "服务器 ID",
    "apiUrl": "PowerDNS API 地址",
    "provider": "DNS 服务商",
    "endpoint": "连接地址",
    "poolSwitch": "{{name}}启用状态",
    "advanced": "高级设置",
    "title": "前置负载分配",
    "pools": "前置池",
    "presets": "DNS 配置",
    "createPool": "新建前置池",
    "editPool": "编辑前置池",
    "createPreset": "添加 DNS 配置",
    "editPreset": "编辑 DNS 配置",
    "name": "名称",
    "domain": "入口域名",
    "baseDomain": "PowerDNS 区域 / CF 域名",
    "dnsPreset": "DNS 配置",
    "chooseDnsPreset": "请选择 DNS 配置",
    "members": "前置节点",
    "realitySyncEnabled": "自动统一 Reality 配置",
    "realitySyncRule": "保存时将统一配置同步到池内前置节点。修改后，使用旧参数的直连订阅需要更新。",
    "realityServerName": "Reality 握手域名",
    "realityServerPort": "Reality 握手端口",
    "realityPrivateKey": "Reality 私钥",
    "realityPublicKey": "Reality 公钥",
    "realityShortId": "Reality 短 ID",
    "realityKeepPrivateKey": "留空保留当前私钥",
    "realityDerivedPublicKey": "保存时由私钥自动生成",
    "realityGenerate": "生成密钥与短 ID",
    "realityGenerateFailed": "Reality 密钥生成失败，请重试",
    "syncReality": "同步到前置节点",
    "priority": "优先级",
    "selectFirst": "选择首个节点确定协议和公网端口",
    "protocol": "协议",
    "state": "状态",
    "actions": "操作",
    "enabled": "启用",
    "disabled": "停用",
    "online": "在线",
    "offline": "离线",
    "choose": "请选择",
    "save": "保存",
    "saving": "保存中",
    "cancel": "取消",
    "edit": "编辑",
    "delete": "删除",
    "refresh": "刷新",
    "retry": "重试",
    "loading": "加载中",
    "syncDns": "同步 DNS",
    "failed": "请求失败，请重试",
    "confirmDelete": "确定删除？已被引用的配置不能删除。",
    "noPools": "暂无前置池",
    "noPresets": "暂无 DNS 配置",
    "noMembers": "暂无可用的 VLESS Reality TCP 节点",
    "keepToken": "留空保留原 Token",
    "poolOption": "前置池：{{name}}",
    "poolReadFailed": "前置池读取失败，请重试",
    "searchNodes": "搜索名称或 IP",
    "noSearchResults": "没有匹配的节点",
    "compatibility": {
      "machine": "未绑定服务器",
      "parent": "共享节点请使用实际运行的父节点",
      "entry": "请选择独立前置节点",
      "protocol": "协议不兼容，仅支持 VLESS Reality",
      "tls": "TLS 模式不兼容，需要 Reality",
      "network": "传输协议不兼容，需要 TCP",
      "settings": "前置协议配置不完整或不受内核支持",
      "invalidPort": "公网端口必须是 1–65535 的单一端口",
      "missingPublicKey": "缺少 Reality 公钥",
      "missingServerName": "缺少 Reality 握手域名",
      "port": "公网端口与首选节点不同",
      "public_key": "Reality 公钥与首选节点不同",
      "short_id": "Reality 短 ID 与首选节点不同",
      "server_name": "Reality 握手域名与首选节点不同",
      "server_port": "Reality 握手端口与首选节点不同",
      "flow": "VLESS 流控与首选节点不同",
      "encryptionEnabled": "VLESS Encryption 开关与首选节点不同",
      "encryption": "VLESS 客户端加密配置与首选节点不同",
      "decryption": "VLESS 服务端解密配置与首选节点不同",
      "sameMachine": "每台服务器只能选择一个前置节点",
      "sameHost": "节点地址不能相同"
    },
    "latencyBalanced": "低延迟多台分配",
    "cyclePriority": "临近流量重置日优先",
    "weight": "权重",
    "assignedUsers": "已分配 {{count}} 人",
    "resetDate": "流量重置日"
  },
  "logs": {
    "blockUsers": "按用户查看",
    "blockCount": "拦截次数",
    "lastBlocked": "最近拦截",
    "blockDetails": "查看明细",
    "backToUsers": "返回用户列表",
    "actions": "操作",

    "blockRetention": "保存天数",
    "block": "路由拦截",
    "rule": "命中规则",
    "ruleFilter": "规则名称或编号",
    "target": "目标域名 / IP",
    "port": "目标端口",
    "network": "网络类型",
    "unknownUser": "无法识别",

    "settings": {
      "title": "日志设置",
      "description": "设置各类日志是否在面板记录，以及保存天数。",
      "modules": { "system": "面板系统日志", "audit": "管理员操作日志", "agent": "Agent 日志", "user": "用户日志", "access": "代理访问记录" },
      "enabled": "记录", "disabled": "不记录", "retention": "保存", "days": "天",
      "daysLabel": "{{module}}保存天数",
      "expiry": "可保存 1–365 天，到期自动清理；关闭后历史记录仍会清理。缩短期限会删除超期记录，无法恢复。Agent 本地日志由机器设置控制。",
      "invalidDays": "保存天数须为 1–365 的整数。", "loadFailed": "日志设置读取失败，请重试。",
      "saveFailed": "日志设置保存失败，请重试。", "save": "保存设置", "saving": "保存中…", "saved": "已保存"
    },
    "userName": "用户",
    "userFilter": "用户邮箱或编号",
    "navigation": "日志管理",
    "system": "系统日志",
    "agent": "Agent 日志",
    "user": "用户日志",
    "time": "时间",
    "machine": "机器",
    "node": "节点",
    "machine_id": "机器编号",
    "node_id": "节点编号",
    "allNodes": "全部节点",
    "loadingNodes": "正在读取节点",
    "nodesLoadFailed": "节点列表读取失败，可重试或填写节点编号",
    "source": "来源",
    "level": "级别",
    "message": "日志内容",
    "ip": "来源 IP",
    "event": "事件",
    "result": "结果",
    "count": "触发次数",
    "limit": "当时上限",
    "keyword": "搜索日志",
    "start_at": "开始时间",
    "end_at": "结束时间",
    "date": "日期",
    "all": "全部",
    "refresh": "刷新",
    "search": "查询",
    "clear": "清空筛选",
    "retry": "重试",
    "loading": "正在读取日志",
    "empty": "没有符合条件的日志",
    "loadFailed": "日志读取失败，请重试",
    "limited": "日志文件较大，当前仅显示所选日期各文件末尾 2 MB 内的记录",
    "seconds": "{{count}} 秒",
    "sources": {
      "panel": "面板运行",
      "audit": "管理员操作",
      "agent": "Agent",
      "xray": "Xray",
      "singbox": "sing-box"
    },
    "levels": {
      "debug": "调试",
      "info": "信息",
      "warn": "警告",
      "error": "错误",
      "fatal": "严重错误"
    },
    "events": {
      "login": "登录",
      "password_change": "修改密码",
      "password_reset": "重置密码",
      "connection_limit": "连接数超限",
      "connection_rate": "连接建立频率超限",
      "device_limit": "设备数超限",
      "speed_limit": "触发带宽限速"
    },
    "results": {
      "success": "成功",
      "wrong_password": "密码错误",
      "wrong_code": "验证码错误",
      "banned": "账号已停用",
      "rate_limited": "登录受限",
      "rejected": "已拒绝",
      "throttled": "限速等待"
    }
  },
  "database": {
    "title": "数据库",
    "refresh": "刷新",
    "loading": "正在读取数据库占用…",
    "loadFailed": "数据库占用读取失败，请重试。",
    "retry": "重试",
    "databaseSize": "数据库主文件",
    "allocatedSize": "表与索引占用",
    "tableCount": "数据表",
    "databaseType": "数据库类型",
    "reusableSize": "库内空闲空间",
    "tables": "数据表占用",
    "search": "搜索数据表",
    "sort": "排序方式",
    "sortSize": "按占用排序",
    "sortName": "按表名排序",
    "sortRows": "按估算行数排序",
    "tableName": "数据表",
    "usage": "总占用",
    "dataSize": "数据占用",
    "indexSize": "索引占用",
    "estimatedRows": "估算行数",
    "empty": "没有匹配的数据表",
    "sqliteSizeNote": "显示主文件的分页占用，不含写入日志；SQLite 不估算行数。",
    "sqliteUnavailable": "当前 SQLite 未提供各表占用统计，仍可查看数据库总占用和清理历史记录。",
    "cleanup": "历史数据清理",
    "preview": "查看待清理记录",
    "preparing": "正在查询…",
    "unavailable": "数据表不可用",
    "completed": "本轮已清理 {{count}} 条记录",
    "deletedRows": "已删除 {{count}} 条",
    "moreRemaining": "仍有到期记录，可再次查看并继续清理。",
    "confirmTitle": "确认清理历史数据",
    "confirmNote": "共有 {{count}} 条到期记录，每个项目本轮最多删除 {{limit}} 条。",
    "eligible": "到期 {{count}} 条",
    "before": "清理早于 {{time}} 的记录",
    "irreversible": "清理后无法恢复，请先确认已有所需备份。本次查询结果 10 分钟内有效。",
    "cancel": "取消",
    "confirm": "确认清理",
    "cleaning": "正在清理…",
    "requestFailed": "操作失败，请重试。",
    "targets": {
      "access": {
        "name": "访问记录",
        "retention": "保留最近 7 天"
      },
      "machine": {
        "name": "机器监控历史",
        "retention": "保留最近 24 小时"
      },
      "audit": {
        "name": "管理员操作日志",
        "retention": "保留最近 3 个月"
      },
      "telegram": {
        "name": "Telegram 消息防重记录",
        "retention": "保留最近 7 天，账号绑定保持"
      }
    },
    "unknownTable": "暂无用途说明",
    "tableDescriptions": {
      "v2_user_event_log": "用户登录、改密与限制事件",
      "v2_agent_log": "Agent 与核心运行日志",
      "v2_node_report_batch": "节点上报批次与流量结算防重记录",
      "v2_proxy_access_log": "访问记录",
      "v2_stat_route_minute": "用户路由每分钟流量统计",
      "v2_stat_route_hour": "用户路由每小时流量统计",
      "v2_stat_proxy_traffic": "节点与服务器代理流量统计",
      "v2_admin_audit_log": "管理员操作日志",
      "v2_server_machine_load_history": "机器监控历史",
      "v2_stat_user_route_source": "用户路由来源与计费流量统计",
      "failed_jobs": "队列任务失败记录",
      "v2_stat_user_server": "用户在各节点的流量统计",
      "v2_inbound_ip": "入站 IP 位置与属性缓存",
      "v2_stat_server": "节点每日流量统计",
      "v2_stat_user": "用户每日流量统计",
      "v2_stat_user_inbound_ip": "用户入站 IP 使用记录",
      "v2_subscription_hub_sources": "订阅聚合源配置",
      "v2_mail_log": "邮件发送记录",
      "v2_subscribe_templates": "订阅配置模板",
      "v2_subscription_stat": "订阅拉取统计汇总",
      "v2_server": "代理节点配置",
      "personal_access_tokens": "接口访问令牌",
      "v2_order": "用户订单",
      "v2_gift_card_code": "礼品卡兑换码",
      "v2_gift_card_usage": "礼品卡使用记录",
      "v2_subscription_hub_chain_rules": "订阅聚合链式规则",
      "v2_user": "用户账户与套餐信息",
      "v2_subscription_block": "订阅逐次拉取时间记录",
      "v2_telegram_node_incidents": "Telegram 节点故障通知防重记录",
      "v2_server_machine": "服务器配置与当前状态",
      "v2_subscription_batch": "订阅统计批次防重记录",
      "v2_telegram_admin_notifications": "Telegram 管理员通知记录",
      "v2_telegram_business_notifications": "Telegram 业务通知记录",
      "v2_traffic_reset_logs": "用户流量重置记录",
      "v2_commission_log": "佣金记录",
      "v2_gift_card_template": "礼品卡模板",
      "v2_plugins": "插件配置与启用状态",
      "v2_server_route": "节点路由规则",
      "v2_settings": "面板系统设置",
      "v2_subscription_restrictions": "订阅客户端限制规则",
      "v2_telegram_bot_bindings": "Telegram 账号绑定",
      "v2_telegram_bot_reminders": "Telegram 到期与流量提醒记录",
      "v2_telegram_bot_updates": "Telegram 消息防重记录",
      "v2_ticket": "用户工单",
      "v2_mail_templates": "邮件模板",
      "v2_notice": "面板公告",
      "v2_plan": "套餐配置与价格",
      "v2_server_group": "节点权限组",
      "v2_stat": "订单、佣金与注册等运营统计",
      "v2_stat_server_name": "节点名称历史记录",
      "migrations": "数据库结构迁移记录",
      "v2_coupon": "优惠券配置",
      "v2_invite_code": "用户邀请码",
      "v2_knowledge": "知识库文章",
      "v2_log": "旧版系统日志",
      "v2_payment": "支付渠道配置",
      "v2_telegram_bot_configs": "Telegram 机器人配置",
      "v2_telegram_node_states": "Telegram 节点在线状态",
      "v2_ticket_message": "工单消息记录",
      "v2_server_hysteria": "旧版 Hysteria 节点配置",
      "v2_server_shadowsocks": "旧版 Shadowsocks 节点配置",
      "v2_server_trojan": "旧版 Trojan 节点配置",
      "v2_server_vless": "旧版 VLESS 节点配置",
      "v2_server_vmess": "旧版 VMess 节点配置",
      "v2_server_log": "旧版节点日志",
      "v2_server_stat": "旧版节点统计",
      "v2_stat_traffic_hour": "旧版用户每小时流量统计",
      "v2_stat_node_hour": "旧版节点每小时流量汇总",
      "v2_stat_node_hour_detail": "旧版节点每小时流量明细",
      "v2_stat_node_minute_detail": "旧版节点每分钟流量明细"
    }
  },
  "statistics": {
    "subscription": { "title": "订阅统计", "users": "用户订阅汇总", "last90": "最近 90 天", "client": "客户端及版本", "clients": "客户端数", "requests": "拉取次数", "results": "成功 / 失败", "resultCounts": "{{success}} / {{failure}}", "first": "首次拉取", "last": "最近拉取", "time": "拉取时间", "status": "响应状态", "format": "订阅格式", "date": "日期", "daily": "每日统计", "recent": "逐次记录（7 天）", "history": "查看记录", "historyType": "记录类型", "back": "返回用户汇总", "close": "收起记录", "refresh": "刷新", "searchUser": "用户邮箱或编号", "searchClient": "搜索客户端" },
    "accessBack": "返回",
    "accessLogs": "访问记录", "destination": "目标域名 / IP", "targetPort": "目标端口", "connectedAt": "连接时间",
    "accessUsers": "用户访问汇总", "accessCount": "访问次数", "lastAccess": "最近访问", "accessSort": "排序方式", "accessSortCount": "按访问次数", "accessSortTime": "按访问时间",
    "refreshRecords": "刷新", "nodeSearchPlaceholder": "节点名称或 ID", "targetSearchPlaceholder": "完整或部分域名 / IP",
    "lastYear": "最近一年", "dailyHeatmap": "每日用量", "trafficIntensity": "用量深浅", "less": "少", "more": "多",
    "noRecord": "暂无记录", "wholeDays": "30 天前仅保留日汇总，请选择完整日期。",
    "nodeUsage": "节点用量",
    "machineStatistics": "服务器用量",
    "machine": "服务器",
    "machineName": "服务器名称",
    "searchMachine": "搜索服务器",
    "machineRank": "服务器用量排行",
    "operator": "运营商",
    "ipProperties": {
      "fraudScore": "欺诈风险评分",
      "asDomain": "ASN 所属域名",
      "connectionType": "网络连接类别",
      "mobileBrand": "移动运营商品牌",
      "district": "区县",
      "connections": {"DIAL": "拨号", "DSL": "宽带 / 光纤 / 移动网络", "COMP": "企业网络", "T1": "数据中心 / 中转", "SAT": "卫星网络"},
      "title": "IP 属性",
      "view": "查看 {ip} 的 IP 属性",
      "close": "关闭 IP 属性",
      "networkType": "网络类型",
      "networkName": "网络名称",
      "proxyTitle": "代理检测",
      "riskTitle": "风险与爬虫检测",
      "yes": "是",
      "no": "否",
      "unknown": "无法查询",
      "is_proxy": "代理",
      "is_vpn": "VPN",
      "is_tor": "Tor 出口",
      "is_data_center": "数据中心",
      "is_public_proxy": "公共代理",
      "is_web_proxy": "网页代理",
      "is_residential_proxy": "住宅代理",
      "is_consumer_privacy_network": "消费隐私网络",
      "is_enterprise_private_network": "企业专用网络",
      "is_spammer": "垃圾邮件",
      "is_scanner": "网络扫描",
      "is_botnet": "僵尸网络",
      "is_bogon": "非法地址",
      "is_web_crawler": "搜索引擎爬虫",
      "is_ai_crawler": "AI 爬虫",
      "types": {
        "COM": "商业网络",
        "ORG": "组织网络",
        "GOV": "政府网络",
        "MIL": "军事网络",
        "EDU": "教育网络",
        "LIB": "图书馆",
        "CDN": "内容分发网络",
        "ISP": "固定宽带",
        "MOB": "移动网络",
        "ISP/MOB": "固定 / 移动网络",
        "DCH": "数据中心",
        "SES": "搜索引擎爬虫",
        "AIC": "AI 爬虫",
        "RSV": "保留地址"
      }
    },
    "minimumTraffic": "隐藏小于多少 MB 的记录", "trafficFilter": "流量筛选", "hideTrafficBelow": "隐藏小于",
    "trafficMinimumSuffix": "MB 的记录", "trafficFilterApplied": "隐藏小于 {{value}} MB 的记录",
    "showAllTraffic": "显示全部", "applyTrafficFilter": "应用",
    "observedProvinces": "出现省份",
    "inboundIp": "入站 IP", "inboundUsers": "用户入站 IP", "ipCount": "IP 数量", "firstSeen": "首次出现", "lastSeen": "最近出现",
    "backToInbound": "返回入站 IP 列表", "filterProvince": "筛选省份", "allProvinces": "全部省份 / 地区",
    "ipAddress": "IP 地址", "location": "归属地", "asn": "ASN", "unknown": "未知", "inboundCount": "共 {{count}} 个 IP",
    "last24": "近 24 小时", "last14": "近 14 天", "all": "全部", "startTime": "开始时间", "endTime": "结束时间",
    "confirm": "确定", "cancel": "取消", "previousMonth": "上月", "nextMonth": "下月",
    "wholeHours": "跨日或历史查询请选择整点。", "searchNode": "搜索节点", "nodeName": "节点名称", "asc": "升序", "desc": "降序",
    "direct": "直出", "effectiveRate": "生效倍率",
    "hour": "按小时", "perPage": "每页显示", "backToUsers": "返回用户排行",
    "navigation": "统计分析", "overview": "流量统计", "nodeStatistics": "节点用量", "userStatistics": "用户统计",
    "trend": "总流量趋势", "nodeRank": "节点用量排行", "userRank": "用户流量排行", "userDetails": "用户节点明细",
    "period": "时间范围", "last30": "最近 30 天", "last7": "最近 7 天", "today": "今天", "custom": "自定义",
    "unit": "统计单位", "day": "按天", "week": "按周", "month": "按月", "metric": "流量口径", "actual": "实际流量", "billed": "扣费流量",
    "startDate": "开始日期", "endDate": "结束日期", "to": "至", "apply": "查询", "invalidRange": "请选择有效的起止日期。",
    "total": "总流量", "upload": "上传", "download": "下载", "rank": "排名", "node": "节点", "user": "用户", "actions": "操作",
    "viewDetails": "查看明细", "loading": "加载中", "empty": "暂无数据", "loadFailed": "读取失败，请重试。", "retry": "重试",
    "page": "第 {{page}} / {{pages}} 页，共 {{count}} 条", "previous": "上一页", "next": "下一页",
    "searchUser": "搜索用户", "searchPlaceholder": "用户邮箱或 ID", "search": "搜索", "clear": "清除",
    "inboundSearchPlaceholder": "用户邮箱、ID 或 IP", "searchIp": "搜索 IP", "ipSearchPlaceholder": "完整或部分 IP 地址",
    "chooseUser": "搜索用户或从排行中选择用户查看明细。", "filterNode": "筛选节点", "allNodes": "全部节点",
    "entryTotal": "入口合计", "relayTotal": "落地合计", "date": "日期", "position": "流量类型", "entry": "入口", "relay": "中转"
  },
  "telegramBot": {
    "userReminders": "用户提醒", "nodeNotifications": "节点通知", "nodeNotificationSaved": "节点通知已保存",
    "groupLink": "Telegram 群组链接", "groupLinkInvalid": "请输入完整的 HTTP 或 HTTPS 群组链接。",
    "groupNodeSettings": "群组设置", "groupNodeSaved": "群组设置已保存",
    "auto_approve_join": "自动审核入群", "notify_node_offline": "节点掉线通知",
    "notify_xray_crash": "Xray 核心崩溃通知",
    "joinGroups": "审核群组 ID", "joinGroupsPlaceholder": "每行一个群组 ID，例如 -1001234567890",
    "joinGroupsInvalid": "请填写有效的负数群组 ID，最多 20 个；开启审核时至少填写一个。",
    "joinGroupRequirement": "机器人需为群管理员并有邀请用户权限，群邀请链接需开启入群审批。",
    "nodeOfflineMinutes": "连续无心跳多久后通知（分钟）",
    "nodeOfflineRecipients": "发送给已绑定 Telegram 的管理员。",
    "businessNotifications": "工单与支付", "businessNotificationSaved": "工单与支付设置已保存",
    "businessNotificationTypes": { "notify_ticket": "工单通知", "allow_ticket_reply": "工单回复", "notify_payment": "支付通知" },
    "adminNotifications": "管理员通知", "adminNotificationSaved": "管理员通知设置已保存",
    "adminNotificationTypes": { "device": "用户设备数超限通知", "connection": "用户连接数超限通知" },
    "adminRecipients": "管理员接收人（Telegram 数字 ID）",
    "adminRecipientsPlaceholder": "每行一个数字 ID，接收人需先私聊机器人发送 /start",
    "adminRecipientsInvalid": "最多填写 20 个不同的有效 Telegram 数字 ID；开启告警时至少填写一个",
    "adminNotificationInterval": "重复告警间隔（分钟）",
    "reminders": "提醒设置", "reminderSaved": "提醒设置已保存",
    "reminderTypes": { "expiring": "到期提醒", "expired": "过期提醒", "device": "设备数超限提醒", "connection": "连接数超限提醒" },
    "reminderDays": "提前提醒天数", "reminderInterval": "超限提醒间隔（分钟）",
    "reminderRange": "请输入 1 至 {{max}} 的整数",
    "operationFailed": "操作失败，请检查设置后重试。",
    "title": "Telegram Bot", "settings": "机器人设置", "bindings": "用户管理",
    "actions": "操作", "unbind": "解绑", "unbindConfirm": "解除用户绑定？",
    "unbindDescription": "解除该 Telegram 与面板账号的绑定，保留账号、套餐和订阅。用户可重新发送订阅链接进行绑定。",
    "unbindSuccess": "用户绑定已解除", "unbindFailed": "解绑失败，请重试。",
    "loading": "加载中", "loadFailed": "读取失败，请重试。", "retry": "重试",
    "enabledState": "运行状态", "enabled": "已启用", "disabled": "已停用",
    "connectionState": "消息接入", "username": "机器人账号", "notChecked": "未检查",
    "lastReceived": "最近收到消息", "neverReceived": "尚未收到消息",
    "pendingMessages": "待投递消息", "checkWarning": "检查发现消息接入异常",
    "testMessage": "发送测试消息", "testRecipient": "测试接收人（Telegram 数字 ID）",
    "recipientPlaceholder": "接收人需先私聊机器人发送 /start",
    "recipientRequired": "请输入有效的 Telegram 数字 ID，不支持用户名或群组",
    "token": "机器人令牌", "tokenRequired": "请输入机器人令牌",
    "showToken": "显示机器人令牌", "hideToken": "隐藏机器人令牌",
    "tokenPlaceholder": "输入机器人令牌", "tokenInvalid": "请输入有效的机器人令牌",
    "urlInvalid": "请输入有效的 HTTPS 基础地址，不含接收路径、账号或查询参数",
    "saveConfirm": "停用机器人并保存新配置？", "saveDescription": "将先停用当前机器人，再保存新配置。已有账号绑定保留，保存后需要重新启用机器人。",
    "stopFailed": "机器人停用未完成，未保存新配置，请重试。",
    "webhookUrl": "消息接收地址", "webhookBaseUrl": "Webhook Base URL",
    "webhookDocs": "查看 Telegram Webhook 文档", "urlRequired": "请输入 Webhook Base URL",
    "save": "保存", "processing": "处理中", "check": "验证连接", "refresh": "刷新状态",
    "enable": "启用", "disable": "停用", "cancel": "取消", "confirm": "确认",
    "enableConfirm": "启用 Telegram Bot？", "enableDescription": "启用后，机器人会开始接收消息并处理账号绑定。",
    "disableConfirm": "停用 Telegram Bot？", "disableDescription": "停止处理消息，已有账号绑定保留。",
    "email": "账号邮箱", "telegramId": "Telegram ID", "telegramUsername": "Telegram 用户名", "boundAt": "绑定时间",
    "searchPlaceholder": "搜索邮箱、Telegram ID 或用户名", "search": "查询",
    "total": "共 {{count}} 条绑定", "previous": "上一页", "next": "下一页", "page": "第 {{current}} / {{total}} 页",
    "status": { "unconfigured": "未配置", "unchecked": "未检查", "error": "连接异常", "connected": "接收地址已登记", "disconnected": "接收地址未登记" },
    "success": { "saveApplied": "配置已保存，机器人已重新启用", "save": "配置已保存", "saveStopped": "配置已保存，请重新启用机器人", "check": "Telegram 接口检查完成", "enable": "机器人已启用", "disable": "机器人已停用", "testMessage": "测试消息已发送，请到 Telegram 查看" }
  },
  "giftCard": {
    "title": "礼品卡管理",
    "description": "在这里可以管理礼品卡模板、兑换码和使用记录等功能。",
    "tabs": {
      "templates": "模板管理",
      "codes": "兑换码管理",
      "usages": "使用记录",
      "statistics": "统计数据"
    },
    "template": {
      "title": "模板管理",
      "description": "管理礼品卡模板，包括创建、编辑和删除模板。",
      "table": {
        "title": "模板列表",
        "columns": {
          "id": "ID",
          "name": "名称",
          "type": "类型",
          "status": "状态",
          "sort": "排序",
          "rewards": "奖励内容",
          "created_at": "创建时间",
          "actions": "操作",
          "no_rewards": "无奖励"
        }
      },
      "form": {
        "add": "添加模板",
        "edit": "编辑模板",
        "name": {
          "label": "模板名称",
          "placeholder": "请输入模板名称",
          "required": "请输入模板名称"
        },
        "sort": {
          "label": "排序",
          "placeholder": "数字越小越靠前"
        },
        "type": {
          "label": "类型",
          "placeholder": "请选择礼品卡类型"
        },
        "description": {
          "label": "描述",
          "placeholder": "请输入礼品卡描述"
        },
        "status": {
          "label": "状态",
          "description": "禁用后，此模板将无法生成或兑换新的礼品卡。"
        },
        "display": {
          "title": "显示效果"
        },
        "theme_color": {
          "label": "主题颜色"
        },
        "icon": {
          "label": "图标",
          "placeholder": "请输入图标的URL"
        },
        "background_image": {
          "label": "背景图片",
          "placeholder": "请输入背景图片的URL"
        },
        "conditions": {
          "title": "使用条件",
          "new_user_max_days": {
            "label": "新用户注册天数限制",
            "placeholder": "例如: 7 (仅限注册7天内的用户)"
          },
          "new_user_only": {
            "label": "仅限新用户"
          },
          "paid_user_only": {
            "label": "仅限付费用户"
          },
          "require_invite": {
            "label": "需要邀请关系"
          },
          "allowed_plans": {
            "label": "允许的套餐",
            "placeholder": "选择允许兑换的套餐 (留空则不限制)"
          },
          "disallowed_plans": {
            "label": "禁止的套餐",
            "placeholder": "选择禁止兑换的套餐 (留空则不限制)"
          }
        },
        "limits": {
          "title": "使用限制",
          "max_use_per_user": {
            "label": "单用户最大使用次数",
            "placeholder": "留空则不限制"
          },
          "cooldown_hours": {
            "label": "同类卡冷却时间(小时)",
            "placeholder": "留空则不限制"
          },
          "invite_reward_rate": {
            "label": "邀请人奖励比例",
            "placeholder": "例如: 0.2 (代表20%)",
            "description": "使用者有邀请人时，给邀请人的奖励 = 余额奖励 * 此比例"
          }
        },
        "rewards": {
          "title": "奖励内容",
          "balance": {
            "label": "奖励余额 (元)",
            "short_label": "余额",
            "placeholder": "请输入奖励的金额(元)"
          },
          "transfer_enable": {
            "label": "奖励流量 (GB)",
            "short_label": "流量",
            "placeholder": "请输入奖励的流量(GB)"
          },
          "expire_days": {
            "label": "延长有效期 (天)",
            "short_label": "有效期",
            "placeholder": "请输入延长的天数"
          },
          "transfer": {
            "label": "奖励流量 (字节)",
            "placeholder": "请输入奖励的流量(字节)"
          },
          "days": {
            "label": "延长有效期 (天)",
            "placeholder": "请输入延长的天数"
          },
          "device_limit": {
            "label": "增加设备数",
            "short_label": "设备数",
            "placeholder": "请输入增加的设备数量"
          },
          "reset_package": {
            "label": "重置当月流量",
            "description": "开启后，兑换时会将用户当前套餐的已用流量清零。"
          },
          "reset_count": {
            "description": "该类型卡将重置用户当月的流量使用。"
          },
          "task_card": {
            "description": "任务礼品卡的具体奖励将在任务系统中配置。"
          },
          "plan_id": {
            "label": "指定套餐",
            "short_label": "套餐",
            "placeholder": "请选择一个套餐"
          },
          "plan_validity_days": {
            "label": "套餐有效期 (天)",
            "short_label": "套餐有效期",
            "placeholder": "留空则使用套餐默认有效期"
          },
          "random_rewards": {
            "label": "随机奖励池",
            "add": "添加随机奖励项",
            "weight": "权重"
          }
        },
        "special_config": {
          "title": "特殊配置",
          "start_time": {
            "label": "活动开始时间",
            "placeholder": "请选择开始日期"
          },
          "end_time": {
            "label": "活动结束时间",
            "placeholder": "请选择结束日期"
          },
          "festival_bonus": {
            "label": "节日奖励乘数",
            "placeholder": "例如: 1.5 (代表1.5倍)"
          }
        },
        "submit": {
          "saving": "保存中...",
          "save": "保存"
        }
      },
      "actions": {
        "edit": "编辑",
        "delete": "删除",
        "deleteConfirm": {
          "title": "确认删除",
          "description": "此操作将永久删除该模板，确定要继续吗？",
          "confirmText": "删除"
        }
      }
    },
    "code": {
      "title": "兑换码管理",
      "form": {
        "generate": "生成兑换码",
        "template_id": {
          "label": "选择模板",
          "placeholder": "请选择一个模板来生成兑换码"
        },
        "count": {
          "label": "生成数量"
        },
        "prefix": {
          "label": "自定义前缀 (可选)"
        },
        "expires_hours": {
          "label": "有效期 (小时)"
        },
        "max_usage": {
          "label": "最大使用次数"
        },
        "download_csv": "导出CSV",
        "submit": {
          "generating": "生成中...",
          "generate": "立即生成"
        }
      },
      "description": "管理礼品卡兑换码，包括生成、查看和导出兑换码。",
      "generate": {
        "title": "生成兑换码",
        "template": "选择模板",
        "count": "生成数量",
        "prefix": "自定义前缀",
        "expires_hours": "有效期 (小时)",
        "max_usage": "最大使用次数",
        "submit": "生成"
      },
      "table": {
        "title": "兑换码列表",
        "columns": {
          "id": "ID",
          "code": "兑换码",
          "template_name": "模板名称",
          "status": "状态",
          "expires_at": "过期时间",
          "usage_count": "已用次数",
          "max_usage": "可用次数",
          "created_at": "创建时间"
        }
      },
      "actions": {
        "enable": "启用",
        "disable": "禁用",
        "export": "导出",
        "exportConfirm": {
          "title": "确认导出",
          "description": "将导出选定批次的所有兑换码为文本文件。确定要继续吗？",
          "confirmText": "导出"
        }
      },
      "status": {
        "0": "未使用",
        "1": "已使用",
        "2": "已禁用",
        "3": "已过期"
      }
    },
    "usage": {
      "title": "使用记录",
      "description": "查看礼品卡的使用记录和详细信息。",
      "table": {
        "columns": {
          "id": "ID",
          "code": "兑换码",
          "template_name": "模板名称",
          "user_email": "用户邮箱",
          "rewards_given": "获得奖励",
          "invite_rewards": "邀请奖励",
          "multiplier_applied": "倍数加成",
          "ip_address": "IP地址",
          "created_at": "使用时间",
          "actions": "操作"
        }
      },
      "actions": {
        "view": "查看详情"
      }
    },
    "statistics": {
      "title": "统计数据",
      "description": "查看礼品卡的统计数据和使用情况分析。",
      "total": {
        "title": "总体统计",
        "templates_count": "模板总数",
        "active_templates_count": "活跃模板数",
        "codes_count": "兑换码总数",
        "used_codes_count": "已使用兑换码",
        "usages_count": "使用记录数"
      },
      "daily": {
        "title": "每日使用量",
        "chart": "使用量趋势图"
      },
      "type": {
        "title": "类型统计",
        "chart": "类型分布图"
      },
      "dateRange": {
        "label": "日期范围",
        "start": "开始日期",
        "end": "结束日期"
      }
    },
    "types": {
      "1": "通用礼品卡",
      "2": "套餐礼品卡",
      "3": "盲盒礼品卡",
      "4": "任务礼品卡"
    },
    "common": {
      "search": "搜索礼品卡...",
      "reset": "重置",
      "filter": "筛选",
      "export": "导出",
      "refresh": "刷新",
      "back": "返回",
      "close": "关闭",
      "confirm": "确认",
      "cancel": "取消",
      "enabled": "已启用",
      "disabled": "已禁用",
      "loading": "加载中...",
      "noData": "暂无数据",
      "success": "操作成功",
      "error": "操作失败"
    },
    "messages": {
      "formInvalid": "请检查表单输入是否正确",
      "templateCreated": "模板创建成功",
      "templateUpdated": "模板更新成功",
      "templateDeleted": "模板删除成功",
      "codeGenerated": "兑换码生成成功",
      "generateCodeFailed": "兑换码生成失败",
      "codeStatusUpdated": "兑换码状态更新成功",
      "updateCodeStatusFailed": "兑换码状态更新失败",
      "codesExported": "兑换码导出成功",
      "createTemplateFailed": "创建模板失败",
      "updateTemplateFailed": "更新模板失败",
      "deleteTemplateFailed": "删除模板失败",
      "loadDataFailed": "加载数据失败",
      "codesGenerated": "兑换码生成成功"
    }
  },
  "user": {
    "column_settings": "显示列",
    "extend_duration": {
      "title": "增加时长",
      "selected": "已选中 {{count}} 个用户",
      "days": "增加天数",
      "cancel": "取消",
      "confirm": "确认增加",
      "pending": "处理中",
      "result": "已增加 {{updated}} 人，跳过 {{skipped}} 人",
      "failed": "增加失败，请刷新核对后重试"
    },
    "manage": {
      "title": "用户管理",
      "description": "在这里可以管理用户，包括增加、删除、编辑、查询等操作。"
    },
    "columns": {
      "is_admin": "管理员",
      "is_staff": "员工",
      "id": "ID",
      "email": "邮箱",
      "online_count": "在线设备",
      "connection_count": "连接数",
      "upload_speed": "上传速度",
      "download_speed": "下载速度",
      "speed_unknown": "未知",
      "speed_partial": "部分节点数据缺失，仅显示已确认速度",
      "connections_unknown": "暂无有效的连接数上报",
      "connections_partial": "部分节点未上报，仅显示已确认的连接数",
      "status": "状态",
      "subscription": "订阅",
      "group": "权限组",
      "used_traffic": "已用流量",
      "total_traffic": "总流量",
      "expire_time": "到期时间",
      "balance": "余额",
      "commission": "佣金",
      "register_time": "注册时间",
      "actions": "操作",
      "next_reset_at": "下次重置时间",
      "device_limit": {
        "unlimited": "无设备数限制",
        "limited": "最多可同时在线 {{count}} 台设备"
      },
      "status_text": {
        "normal": "正常",
        "banned": "封禁"
      },
      "online_status": {
        "online": "当前在线",
        "never": "从未在线",
        "last_online": "最后在线时间: {{time}}",
        "offline_duration": {
          "days": "离线时长: {{count}}天",
          "hours": "离线时长: {{count}}小时",
          "minutes": "离线时长: {{count}}分钟",
          "seconds": "离线时长: {{count}}秒"
        }
      },
      "expire_status": {
        "permanent": "长期有效",
        "expired": "已过期 {{days}} 天",
        "remaining": "剩余 {{days}} 天"
      },
      "actions_menu": {
        "edit": "编辑",
        "view_details": "查看详情",
        "assign_order": "分配订单",
        "copy_url": "复制订阅URL",
        "reset_secret": "重置UUID及订阅URL",
        "reset_traffic": "重置流量",
        "orders": "TA的订单",
        "invites": "TA的邀请",
        "traffic_records": "TA的流量记录",
        "delete": "删除",
        "delete_confirm_title": "确认删除用户",
        "delete_confirm_description": "此操作将永久删除用户 {{email}} 及其所有相关数据，包括订单、优惠码、流量记录、工单记录等信息。删除后无法恢复，是否继续？"
      }
    },
    "filter": {
      "selected": "已选择 {{count}} 项",
      "no_results": "未找到结果",
      "clear": "清除筛选",
      "search_placeholder": "搜索...",
      "email_search": "搜索用户邮箱...",
      "plan": "套餐",
      "advanced": "高级筛选",
      "reset": "重置筛选",
      "sheet": {
        "title": "高级筛选",
        "description": "添加一个或多个筛选条件来精确查找用户",
        "conditions": "筛选条件",
        "add": "添加条件",
        "condition": "条件 {{number}}",
        "field": "选择字段",
        "operator": "选择操作符",
        "value": "输入值",
        "value_number": "输入数值({{unit}})",
        "reset": "重置",
        "apply": "应用筛选"
      },
      "fields": {
        "email": "邮箱",
        "phone": "手机号",
        "id": "用户ID",
        "plan_id": "订阅",
        "transfer_enable": "流量",
        "total_used": "已用流量",
        "online_count": "在线设备",
        "expired_at": "到期时间",
        "uuid": "UUID",
        "token": "Token",
        "banned": "账号状态",
        "remark": "备注",
        "inviter_email": "邀请人邮箱",
        "invite_user_id": "邀请人ID",
        "is_admin": "管理员",
        "is_staff": "员工"
      },
      "operators": {
        "contains": "包含",
        "eq": "等于",
        "gt": "大于",
        "lt": "小于"
      },
      "status": {
        "normal": "正常",
        "banned": "禁用"
      },
      "boolean": {
        "true": "是",
        "false": "否"
      }
    },
    "generate": {
      "button": "创建用户",
      "title": "创建用户",
      "form": {
        "email": "邮箱",
        "email_prefix": "帐号(批量生成请留空)",
        "email_domain": "域",
        "password": "密码",
        "password_placeholder": "留空则自动生成随机密码",
        "random_password": "随机生成",
        "expire_time": "到期时间",
        "expire_time_placeholder": "请选择用户到期日期，留空为长期有效",
        "permanent": "长期有效",
        "subscription": "订阅计划",
        "subscription_none": "无",
        "generate_count": "生成数量",
        "generate_count_placeholder": "如果为批量生产请输入生成数量",
        "cancel": "取消",
        "submit": "生成",
        "success": "生成成功",
        "download_csv": "导出为 CSV 文件"
      },
      "result": {
        "title": "账号已创建",
        "copy": "复制",
        "copy_all": "复制全部",
        "copied": "已复制",
        "copy_failed": "复制失败，请手动选择复制",
        "close": "关闭"
      }
    },
    "edit": {
      "button": "编辑用户信息",
      "title": "用户管理",
      "form": {
        "email": "邮箱",
        "phone_country": "国家/地区",
        "phone": "手机号",
        "phone_placeholder": "请输入手机号",
        "email_placeholder": "请输入邮箱",
        "inviter_email": "邀请人邮箱",
        "inviter_email_placeholder": "请输入邮箱",
        "password": "密码",
        "password_placeholder": "如需修改密码请输入",
        "random_password": "随机生成",
        "copy_password": "复制密码",
        "password_copied": "密码已复制",
        "copy_failed": "复制失败，请手动选择复制",
        "balance": "余额",
        "balance_placeholder": "请输入余额",
        "commission_balance": "佣金余额",
        "commission_balance_placeholder": "请输入佣金余额",
        "upload": "已用上行",
        "upload_placeholder": "已用上行",
        "download": "已用下行",
        "download_placeholder": "已用下行",
        "total_traffic": "流量",
        "total_traffic_placeholder": "请输入流量",
        "expire_time": "到期时间",
        "expire_time_placeholder": "请选择用户到期日期，留空为长期有效",
        "expire_time_specific": "具体时间",
        "expire_time_today": "设为当天结束",
        "expire_time_permanent": "长期有效",
        "expire_time_1hour": "一个小时",
        "expire_time_1month": "一个月",
        "expire_time_3months": "三个月",
        "expire_time_confirm": "确定",
        "subscription": "订阅计划",
        "subscription_none": "无",
        "account_status": "账户状态",
        "commission_type": "佣金类型",
        "commission_type_system": "跟随系统设置",
        "commission_type_cycle": "循环返利",
        "commission_type_onetime": "首次返利",
        "commission_rate": "推荐返利比例",
        "commission_rate_placeholder": "为空则跟随站点设置返利比例",
        "discount": "专享折扣比例",
        "discount_placeholder": "为空则不享受专享折扣",
        "speed_limit": "限速",
        "speed_limit_placeholder": "留空则不限速",
        "device_limit": "设备限制",
        "device_limit_placeholder": "留空则不限制",
        "conn_limit": "并发连接数",
        "conn_limit_placeholder": "留空则不限制",
        "conn_rate_limit": "新建连接速率",
        "conn_rate_limit_placeholder": "留空则不限制",
        "is_admin": "是否管理员",
        "is_staff": "是否员工",
        "remarks": "备注",
        "remarks_placeholder": "请在这里记录",
        "cancel": "取消",
        "submit": "提交",
        "success": "修改成功"
      }
    },
    "actions": {
      "title": "操作",
      "send_email": "发送邮件",
      "export_csv": "导出 CSV",
      "traffic_reset_stats": "流量重置统计",
      "batch_ban": "批量封禁",
      "confirm_ban": {
        "title": "确认批量封禁",
        "filtered_description": "此操作将封禁所有符合当前筛选条件的用户。此操作无法撤销。",
        "all_description": "此操作将封禁系统中的所有用户。此操作无法撤销。",
        "cancel": "取消",
        "confirm": "确认封禁",
        "banning": "封禁中..."
      }
    },
    "traffic_reset": {
      "title": "流量重置",
      "description": "为用户 {{email}} 重置流量使用量",
      "tabs": {
        "reset": "重置流量",
        "history": "重置历史"
      },
      "user_info": "用户信息",
      "warning": {
        "title": "重要提醒",
        "irreversible": "流量重置操作不可逆，请谨慎操作",
        "reset_to_zero": "重置后用户的上传和下载流量将清零",
        "logged": "所有重置操作都会被记录在系统日志中"
      },
      "reason": {
        "label": "重置原因",
        "placeholder": "请输入重置流量的原因（可选）",
        "optional": "此字段为可选项，用于记录重置原因"
      },
      "confirm_reset": "确认重置",
      "resetting": "重置中...",
      "reset_success": "流量重置成功",
      "reset_failed": "流量重置失败",
      "history": {
        "summary": "重置概览",
        "reset_count": "重置次数",
        "last_reset": "最后重置",
        "next_reset": "下次重置",
        "never": "从未重置",
        "no_schedule": "无定时重置",
        "records": "重置记录",
        "recent_records": "最近10次重置记录",
        "no_records": "暂无重置记录",
        "reset_time": "重置时间",
        "traffic_cleared": "清除流量"
      },
      "stats": {
        "title": "流量重置统计",
        "description": "查看系统流量重置的统计信息",
        "time_range": "统计时间范围",
        "total_resets": "总重置次数",
        "auto_resets": "自动重置",
        "manual_resets": "手动重置",
        "cron_resets": "定时重置",
        "in_period": "最近 {{days}} 天",
        "breakdown": "重置类型分布",
        "breakdown_description": "各类型重置操作的百分比分布",
        "auto_percentage": "自动重置占比",
        "manual_percentage": "手动重置占比",
        "cron_percentage": "定时重置占比",
        "days_options": {
          "week": "最近一周",
          "month": "最近一月",
          "quarter": "最近三月",
          "year": "最近一年"
        }
      }
    },
    "traffic_reset_logs": {
      "title": "流量重置日志",
      "description": "查看系统中所有流量重置操作的详细记录",
      "columns": {
        "id": "日志ID",
        "user": "用户",
        "reset_type": "重置类型",
        "trigger_source": "触发源",
        "cleared_traffic": "清除流量",
        "cleared": "已清除",
        "upload": "上传",
        "download": "下载",
        "reset_time": "重置时间",
        "log_time": "记录时间"
      },
      "filters": {
        "search_user": "搜索用户邮箱...",
        "reset_type": "重置类型",
        "trigger_source": "触发源",
        "all_types": "全部类型",
        "all_sources": "全部来源",
        "start_date": "开始日期",
        "end_date": "结束日期",
        "apply_date": "应用筛选",
        "reset": "重置筛选",
        "filter_title": "筛选条件",
        "filter_description": "设置筛选条件来查找特定的流量重置记录",
        "reset_types": {
          "monthly": "按月重置",
          "first_day_month": "每月1号重置",
          "yearly": "按年重置",
          "first_day_year": "每年1月1日重置",
          "manual": "手动重置"
        },
        "trigger_sources": {
          "auto": "自动触发",
          "manual": "手动触发",
          "cron": "定时任务"
        }
      },
      "actions": {
        "export": "导出日志",
        "exporting": "导出中...",
        "export_success": "导出成功",
        "export_failed": "导出失败"
      },
      "trigger_descriptions": {
        "manual": "管理员手动执行的流量重置",
        "cron": "系统定时任务自动执行",
        "auto": "系统根据条件自动触发",
        "other": "其他方式触发"
      }
    },
    "messages": {
      "success": "成功",
      "error": "错误",
      "export": {
        "success": "导出成功",
        "failed": "导出失败"
      },
      "batch_ban": {
        "success": "批量封禁成功",
        "failed": "批量封禁失败"
      },
      "send_mail": {
        "success": "邮件发送成功",
        "failed": "邮件发送失败",
        "required_fields": "请填写所有必填字段"
      }
    },
    "send_mail": {
      "title": "发送邮件",
      "description": "向所选或已筛选的用户发送邮件",
      "subject": "主题",
      "content": "内容",
      "sending": "发送中...",
      "send": "发送"
    },
    "dialog": {
      "title": "用户详情",
      "basicInfo": "基本信息",
      "subscriptionInfo": "订阅信息",
      "trafficInfo": "流量信息",
      "financialInfo": "财务信息",
      "activityInfo": "活动信息",
      "inviteInfo": "邀请信息",
      "timeInfo": "时间信息",
      "subscriptionUrl": "订阅链接",
      "fields": {
        "userId": "用户ID",
        "email": "邮箱",
        "phone": "手机号",
        "uuid": "UUID",
        "token": "Token",
        "remarks": "备注",
        "subscriptionPlan": "订阅套餐",
        "permissionGroup": "权限组",
        "expiredAt": "到期时间",
        "deviceLimit": "设备限制",
        "speedLimit": "速度限制",
        "transferEnable": "总流量",
        "uploadUsed": "上传已用",
        "downloadUsed": "下载已用",
        "totalUsed": "总已用",
        "lastResetAt": "上次重置",
        "nextResetAt": "下次重置",
        "resetCount": "重置次数",
        "balance": "余额",
        "commissionBalance": "佣金余额",
        "commissionType": "佣金类型",
        "commissionRate": "佣金比例",
        "lastLoginAt": "最后登录",
        "lastLoginIp": "最后登录IP",
        "lastOnlineAt": "最后在线",
        "onlineCount": "在线设备",
        "inviteUser": "邀请人",
        "inviteUserId": "邀请人ID",
        "createdAt": "创建时间",
        "updatedAt": "更新时间",
        "subscribeUrl": "订阅链接",
        "telegramId": "Telegram ID"
      }
    },
    "status": {
      "normal": "正常",
      "banned": "已封禁",
      "admin": "管理员",
      "staff": "员工"
    }
  },
  "nav": {
    "telegramBot": "Telegram Bot",
    "dashboard": "仪表盘",
    "systemManagement": "系统管理",
    "systemConfig": "系统配置",
    "themeConfig": "主题配置",
    "pluginManagement": "插件管理",
    "pluginMenuDemo": "插件菜单（演示）",
    "noticeManagement": "公告管理",
    "paymentConfig": "支付配置",
    "knowledgeManagement": "知识库管理",
    "nodeManagement": "节点管理",
    "machineManagement": "服务器管理",
    "permissionGroupManagement": "权限组管理",
    "routeManagement": "路由管理",
    "subscriptionManagement": "订阅管理",
    "planManagement": "套餐管理",
    "planSettings": "套餐设置",
    "orderManagement": "订单管理",
    "couponManagement": "优惠券管理",
    "giftCardManagement": "礼品卡管理",
    "userManagement": "用户管理",
    "ticketManagement": "工单管理",
    "trafficResetLogs": "流量重置日志",
    "pluginApps": "插件应用"
  },
  "subscribe": {
    "plan": {
      "title": "订阅套餐",
      "add": "添加套餐",
      "search": "搜索套餐...",
      "sort": {
        "edit": "编辑排序",
        "save": "保存排序"
      },
      "columns": {
        "id": "ID",
        "show": "显示",
        "sell": "新购",
        "renew": "续费",
        "renew_tooltip": "在订阅停止销售时，已购用户是否可以续费",
        "name": "名称",
        "stats": "统计",
        "group": "权限组",
        "price": "价格",
        "actions": "操作",
        "edit": "编辑",
        "delete": "删除",
        "delete_confirm": {
          "title": "确认删除",
          "description": "此操作将永久删除该订阅，删除后无法恢复。确定要继续吗？",
          "success": "删除成功"
        },
        "price_period": {
          "monthly": "月付",
          "quarterly": "季付",
          "half_yearly": "半年付",
          "yearly": "年付",
          "two_yearly": "两年付",
          "three_yearly": "三年付",
          "onetime": "流量包",
          "reset_traffic": "重置包",
          "no_price": "无价格",
          "unit": {
            "month": "元/月",
            "quarter": "元/季",
            "half_year": "元/半年",
            "year": "元/年",
            "two_year": "元/两年",
            "three_year": "元/三年",
            "times": "元/次"
          }
        }
      },
      "form": {
        "add_title": "添加套餐",
        "edit_title": "编辑套餐",
        "name": {
          "label": "套餐名称",
          "placeholder": "请输入套餐名称"
        },
        "group": {
          "label": "权限组",
          "add": "添加分组",
          "placeholder": "请选择权限组（可多选）"
        },
        "transfer": {
          "label": "流量",
          "placeholder": "请输入流量限制",
          "unit": "GB"
        },
        "speed": {
          "label": "速度限制",
          "placeholder": "请输入速度限制",
          "unit": "Mbps"
        },
        "price": {
          "title": "价格设置",
          "base_price": "基础价格",
          "clear": {
            "button": "清空",
            "tooltip": "清空所有价格"
          },
          "period": {
            "monthly": "每月",
            "months": "{{count}}个月"
          },
          "onetime_desc": "一次性流量包，无时间限制",
          "reset_desc": "重置流量包，可多次使用"
        },
        "device": {
          "label": "设备限制",
          "placeholder": "请输入设备限制",
          "unit": "台"
        },
        "conn": {
          "label": "并发连接数",
          "placeholder": "留空则不限制",
          "unit": "条"
        },
        "conn_rate": {
          "label": "新建连接速率",
          "placeholder": "留空则不限制",
          "unit": "次/秒"
        },
        "capacity": {
          "label": "容量限制",
          "placeholder": "请输入容量限制",
          "unit": "人"
        },
        "tags": {
          "label": "标签",
          "placeholder": "输入标签后按回车确认"
        },
        "reset_method": {
          "label": "流量重置方式",
          "placeholder": "请选择重置方式",
          "description": "流量重置方式将决定如何重置流量",
          "options": {
            "follow_system": "跟随系统设置",
            "monthly_first": "每月首日",
            "monthly_reset": "每月购买日",
            "no_reset": "不重置",
            "yearly_first": "每年首日",
            "yearly_reset": "每年购买日"
          }
        },
        "content": {
          "label": "套餐说明",
          "placeholder": "请输入套餐说明",
          "description": "支持 Markdown 格式",
          "preview": "预览",
          "preview_button": {
            "show": "显示预览",
            "hide": "隐藏预览"
          },
          "template": {
            "button": "使用模板",
            "tooltip": "使用默认模板",
            "content": "## 套餐详情\n\n- 流量：{{transfer}} GB\n- 速度限制：{{speed}} Mbps\n- 同时在线设备：{{devices}} 台\n\n## 服务说明\n\n1. 流量{{reset_method}}重置\n2. 支持多平台使用\n3. 7×24小时技术支持"
          }
        },
        "force_update": {
          "label": "强制更新用户套餐"
        },
        "submit": {
          "cancel": "取消",
          "submit": "提交",
          "submitting": "提交中...",
          "success": {
            "add": "套餐添加成功",
            "update": "套餐更新成功"
          },
          "error": {
            "validation": "表单校验失败，请检查并修正错误后重试。"
          }
        }
      },
      "page": {
        "description": "在这里可以配置订阅计划，包括添加、删除、编辑等操作。"
      }
    }
  },
  "settings": {
    "node_health": {
      "title": "链路健康",
      "enabled": "默认开启链路检查",
      "url": "HTTPS 检查地址",
      "interval": "检查间隔（秒）",
      "save": "保存全局设置",
      "saving": "保存中…",
      "save_error": "保存失败，请重试",
      "load_error": "读取失败",
      "retry": "重试"
    },
    "appearance": {"title":"外观设置","sidebar":"侧边栏","restore":"全部显示","restore_order":"恢复默认顺序","sort_help":"拖动调整同级菜单顺序，开关控制显示。","move":"调整{{name}}顺序","saving":"保存中","retry":"重试","load_error":"外观设置读取失败","save_error":"保存失败，请重试","loading":"加载中"},
    "title": "系统设置",
    "description": "管理系统核心配置，包括站点、安全、订阅、邀请佣金、节点、邮件和通知等设置",
    "site": {
      "title": "站点设置",
      "description": "配置站点基本信息，包括站点名称、描述、货币单位等核心设置。",
      "form": {
        "siteName": {
          "label": "站点名称",
          "placeholder": "请输入站点名称",
          "description": "用于显示需要站点名称的地方。"
        },
        "siteDescription": {
          "label": "站点描述",
          "placeholder": "请输入站点描述",
          "description": "用于显示需要站点描述的地方。"
        },
        "siteUrl": {
          "label": "站点网址",
          "placeholder": "请输入站点URL，末尾不要/",
          "description": "当前网站最新网址，将会在邮件等需要用于网址处体现。"
        },
        "forceHttps": {
          "label": "强制HTTPS",
          "description": "当站点没有使用HTTPS，CDN或反代开启强制HTTPS时需要开启。"
        },
        "logo": {
          "label": "LOGO",
          "placeholder": "请输入LOGO URL，末尾不要/",
          "description": "用于显示需要LOGO的地方。"
        },
        "subscribeUrl": {
          "label": "订阅URL",
          "placeholder": "每行一个订阅地址，如 https://sub.example.com",
          "description": "默认使用第一个地址，留空使用站点 URL。"
        },
        "tosUrl": {
          "label": "用户条款(TOS)URL",
          "placeholder": "请输入用户条款URL，末尾不要/",
          "description": "用于跳转到用户条款(TOS)"
        },
        "stopRegister": {
          "label": "停止新用户注册",
          "description": "开启后任何人都将无法进行注册。"
        },
        "ticketMustWaitReply": {
          "label": "工单等待回复限制",
          "description": "开启后，用户在管理员回复前无法在同一工单内连续发送消息。"
        },
        "tryOut": {
          "label": "注册试用",
          "placeholder": "关闭",
          "description": "选择需要试用的订阅，如果没有选项请先前往订阅管理添加。",
          "duration": {
            "label": "注册试用时长",
            "placeholder": "0",
            "description": "注册试用时长，单位为小时。"
          }
        },
        "currency": {
          "label": "货币单位",
          "placeholder": "CNY",
          "description": "仅用于展示使用，更改后系统中所有的货币单位都将发生变更。"
        },
        "currencySymbol": {
          "label": "货币符号",
          "placeholder": "¥",
          "description": "仅用于展示使用，更改后系统中所有的货币单位都将发生变更。"
        }
      }
    },
    "totp": {
      "title": "两步验证",
      "description": "为当前管理员账号启用验证器动态码，登录时需要额外输入一次验证码。",
      "loading": "正在加载",
      "statusOn": "当前状态：已启用",
      "statusOff": "当前状态：未启用",
      "recoveryRemaining": "剩余恢复码 {{count}} 个",
      "enable": "启用两步验证",
      "confirm": "确认启用",
      "cancel": "取消",
      "disable": "关闭两步验证",
      "regenerate": "重新生成恢复码",
      "scanHint": "使用验证器 App 扫描二维码，或手动输入下方密钥。",
      "qrAlt": "两步验证绑定二维码",
      "manualKey": "手动输入密钥",
      "codeLabel": "验证码",
      "codePlaceholder": "请输入 6 位验证码或恢复码",
      "recoveryTitle": "恢复码",
      "recoveryHint": "请立即保存到安全的地方。恢复码只显示这一次，每个仅能使用一次。",
      "copyRecovery": "复制全部恢复码",
      "copied": "已复制",
      "enabledToast": "两步验证已启用",
      "disabledToast": "两步验证已关闭"
    },
    "safe": {
      "title": "安全设置",
      "description": "配置系统安全相关选项，包括登录验证、密码策略、API访问等安全设置。",
      "form": {
        "emailVerify": {
          "label": "邮箱验证",
          "description": "开启后将会强制要求用户进行邮箱验证。"
        },
        "gmailLimit": {
          "label": "禁止使用Gmail多别名",
          "description": "开启后Gmail多别名将无法注册。"
        },
        "safeMode": {
          "label": "安全模式",
          "description": "开启后除了站点URL以外的绑定本站点的域名访问都将会被403。"
        },
        "securePath": {
          "label": "后台路径",
          "placeholder": "admin",
          "description": "后台管理路径，修改后将会改变原有的admin路径"
        },
        "emailWhitelist": {
          "label": "邮箱后缀白名单",
          "description": "开启后在名单中的邮箱后缀才允许进行注册。",
          "suffixes": {
            "label": "邮箱后缀",
            "placeholder": "输入邮箱后缀，每行一个",
            "description": "输入允许的邮箱后缀，每行一个"
          }
        },
        "captcha": {
          "enable": {
            "label": "启用验证码",
            "description": "开启后用户注册时需要通过验证码验证。"
          },
          "type": {
            "label": "验证码类型",
            "description": "选择要使用的验证码服务类型",
            "options": {
              "recaptcha": "Google reCAPTCHA v2",
              "recaptcha-v3": "Google reCAPTCHA v3",
              "turnstile": "Cloudflare Turnstile"
            }
          },
          "recaptcha": {
            "key": {
              "label": "reCAPTCHA密钥",
              "placeholder": "输入reCAPTCHA密钥",
              "description": "输入您的reCAPTCHA密钥"
            },
            "siteKey": {
              "label": "reCAPTCHA站点密钥",
              "placeholder": "输入reCAPTCHA站点密钥",
              "description": "输入您的reCAPTCHA站点密钥"
            }
          },
          "recaptcha_v3": {
            "secretKey": {
              "label": "reCAPTCHA v3密钥",
              "placeholder": "输入reCAPTCHA v3密钥",
              "description": "输入您的reCAPTCHA v3服务器密钥"
            },
            "siteKey": {
              "label": "reCAPTCHA v3站点密钥",
              "placeholder": "输入reCAPTCHA v3站点密钥",
              "description": "输入您的reCAPTCHA v3站点密钥"
            },
            "scoreThreshold": {
              "label": "分数阈值",
              "placeholder": "0.5",
              "description": "设置验证分数阈值（0-1），分数越高表示越可能是真人操作"
            }
          },
          "turnstile": {
            "secretKey": {
              "label": "Turnstile密钥",
              "placeholder": "输入Turnstile密钥",
              "description": "输入您的Cloudflare Turnstile密钥"
            },
            "siteKey": {
              "label": "Turnstile站点密钥",
              "placeholder": "输入Turnstile站点密钥",
              "description": "输入您的Cloudflare Turnstile站点密钥"
            }
          }
        },
        "registerLimit": {
          "enable": {
            "label": "IP注册限制",
            "description": "开启后将限制同一IP的注册次数。"
          },
          "count": {
            "label": "注册次数",
            "placeholder": "输入最大注册次数",
            "description": "同一IP允许的最大注册次数"
          },
          "expire": {
            "label": "限制时长",
            "placeholder": "输入限制时长（分钟）",
            "description": "注册限制的持续时间（分钟）"
          }
        },
        "passwordLimit": {
          "enable": {
            "label": "密码尝试限制",
            "description": "开启后将限制密码尝试次数。"
          },
          "count": {
            "label": "尝试次数",
            "placeholder": "输入最大尝试次数",
            "description": "允许的最大密码尝试次数"
          },
          "expire": {
            "label": "锁定时长",
            "placeholder": "输入锁定时长（分钟）",
            "description": "账户锁定的持续时间（分钟）"
          }
        }
      }
    },
    "subscribe": {
      "protection": {
        "title": "订阅防护",
        "block_browser": "禁止浏览器访问订阅",
        "browser_hint": "拦截浏览器页面访问，代理客户端仍按客户端限制规则检查。",
        "brute_force_enabled": "订阅暴力探测防护",
        "brute_hint": "同一 IP 多次访问无效订阅链接后，暂停其订阅访问。",
        "brute_force_max_failures": "最大失败次数",
        "brute_force_window_minutes": "失败统计窗口（分钟）",
        "brute_force_block_minutes": "封禁时长（分钟）",
        "rate_limit_enabled": "订阅频率限制",
        "rate_hint": "按 IP 限制订阅请求次数，所有订阅入口共用额度。",
        "rate_limit_max_requests": "最大请求次数",
        "rate_limit_window_minutes": "请求统计窗口（分钟）",
        "whitelist_ips": "白名单 IP",
        "ips_placeholder": "每行一个 IPv4、IPv6 或网段，也可用逗号分隔",
        "whitelist_users": "白名单用户",
        "users_placeholder": "搜索邮箱或用户编号",
        "whitelist_hint": "命中任一白名单即可跳过本页防护；账号状态和客户端限制仍然生效。",
        "add_user": "添加 {{email}}",
        "remove_user": "移除 {{email}}",
        "missing_user": "已删除的用户 #{{id}}",
        "remove": "移除",
        "searching": "搜索中…",
        "no_users": "未找到用户",
        "search_error": "搜索失败，请重试。",
        "loading": "加载中…",
        "retry": "重试",
        "load_error": "读取失败，请重试。",
        "save": "保存",
        "saving": "保存中…",
        "saved": "已保存",
        "save_error": "保存失败，输入已保留，请重试。",
        "errors": {
          "number": "{{field}}需填写 1–{{max}} 之间的整数。",
          "ips": "白名单 IP 最多 256 项，每项不超过 64 个字符。",
          "users": "最多选择 1000 个有效用户。"
        },
        "user_rate_limit_enabled": "按用户限制订阅频率",
        "user_rate_hint": "同一账号跨 IP 累计请求，所有订阅入口共用额度。",
        "user_rate_limit_max_requests": "用户最大请求次数",
        "user_rate_limit_window_minutes": "用户统计窗口（分钟）",
        "notify_telegram": "订阅防护提醒",
        "notify_hint": "复用 Telegram Bot 的管理员接收人和重复提醒间隔，仅在新触发限制时通知。",
        "restrictions": "当前限制",
        "refresh": "刷新",
        "no_restrictions": "暂无生效中的限制",
        "restrictions_load_error": "限制列表读取失败，请刷新重试。",
        "save_before_release": "请等待设置自动保存后，再处理限制。",
        "kind_ip_ban": "IP 封禁",
        "kind_ip_rate": "IP 限频",
        "kind_user_rate": "用户限频",
        "restriction_count": "窗口内次数",
        "triggered_at": "触发时间",
        "expires_at": "解除时间",
        "release_once": "解除本次限制",
        "whitelist_permanently": "永久加白",
        "confirm_release": "解除 {{target}} 的本次限制并重置对应计数？",
        "confirm_whitelist": "将 {{target}} 永久加入白名单并重置该对象计数？该对象将跳过订阅防护。",
        "confirm": "确认",
        "cancel": "取消",
        "processing": "处理中…",
        "release_error": "操作失败，请重试或刷新列表。",
        "load_more": "加载更多"
      },
      "client_control": {
        "title": "客户端限制",
        "clients": "客户端",
        "rules": "订阅下载规则",
        "mode": "限制模式",
        "modes": {
          "off": "关闭",
          "whitelist": "白名单：仅允许选中软件",
          "blacklist": "黑名单：禁止选中软件"
        },
        "name": "客户端名称",
        "keywords": "匹配关键词",
        "keywords_placeholder": "每行一个，包含任意一项即匹配",
        "selected": "加入名单",
        "select_named": "将 {{name}} 加入名单",
        "remove": "删除",
        "remove_named": "删除 {{name}}",
        "add": "添加客户端",
        "empty": "暂无客户端规则",
        "groups": "豁免权限组",
        "groups_placeholder": "选择豁免权限组",
        "missing_group": "已删除的权限组 #{{id}}",
        "empty_whitelist": "白名单为空，未豁免用户无法下载订阅。",
        "loading": "加载中…",
        "retry": "重试",
        "load_error": "读取失败，请重试。",
        "saving": "保存中…",
        "save_error": "保存失败，输入已保留，请重试。",
        "errors": {
          "mode": "请选择有效的限制模式。",
          "too_many": "最多添加 64 个客户端。",
          "name": "第 {{row}} 项需要填写客户端名称，最多 80 个字。",
          "keywords": "第 {{row}} 项需要填写 1–32 个关键词，每个最多 128 个字。"
        }
      },
      "title": "订阅设置",
      "description": "管理用户订阅相关配置，包括订阅链接格式、更新频率、流量统计等设置。",
      "plan_change_enable": {
        "title": "允许用户更改订阅",
        "description": "开启后用户将会可以对订阅计划进行变更。"
      },
      "reset_traffic_method": {
        "title": "月流量重置方式",
        "description": "全局流量重置方式，默认每月1号。可以在订阅管理为订阅单独设置。",
        "options": {
          "monthly_first": "每月1号",
          "monthly_reset": "按月重置",
          "no_reset": "不重置",
          "yearly_first": "每年1月1号",
          "yearly_reset": "按年重置"
        }
      },
      "surplus_enable": {
        "title": "开启折抵方案",
        "description": "开启后用户更换订阅将会由系统对原有订阅进行折抵，方案参考文档。"
      },
      "new_order_event": {
        "title": "当订阅新购时触发事件",
        "description": "新购订阅完成时将触发该任务。",
        "options": {
          "no_action": "不执行任何动作",
          "reset_traffic": "重置用户流量"
        }
      },
      "renew_order_event": {
        "title": "当订阅续费时触发事件",
        "description": "续费订阅完成时将触发该任务。",
        "options": {
          "no_action": "不执行任何动作",
          "reset_traffic": "重置用户流量"
        }
      },
      "change_order_event": {
        "title": "当订阅变更时触发事件",
        "description": "变更订阅完成时将触发该任务。",
        "options": {
          "no_action": "不执行任何动作",
          "reset_traffic": "重置用户流量"
        }
      },
      "subscribe_path": {
        "title": "订阅路径",
        "description": "订阅路径，修改后将会改变原有的subscribe路径",
        "current_format": "当前订阅路径格式：{path}/xxxxxxxxxx",
        "restart_tip": "修改订阅路径后，可能需要重启服务才能生效。"
      },
      "basic_settings": "基础设置",
      "output_settings": "输出设置",
      "loading": "加载中…",
      "load_failed": "读取失败，请重试。",
      "save_failed": "保存失败，请重试。",
      "retry": "重试",
      "show_flag_to_server": {"title":"自动添加国旗","description":"按节点名称识别国家或地区，在名称前添加国旗；已有国旗或无法识别时不添加。"},
      "show_rate_to_server": {"title":"在名称后添加倍率","description":"在名称末尾显示实际倍率，例如「｜0.8×」；1 倍不显示。"},
      "show_info_to_server": {
        "title": "在订阅中展示订阅信息",
        "description": "开启后将会在用户订阅节点时输出订阅信息。"
      },
      "show_protocol_to_server": {
        "title": "在订阅中线路名称中显示协议名称",
        "description": "开启后订阅线路会附带协议名称（例如: [Hy2]香港）"
      },
      "saving": "保存中...",
      "plan": {
        "title": "订阅套餐",
        "add": "添加套餐",
        "search": "搜索套餐...",
        "sort": {
          "edit": "编辑排序",
          "save": "保存排序"
        },
        "columns": {
          "id": "ID",
          "show": "显示",
          "sell": "新购",
          "renew": "续费",
          "renew_tooltip": "在订阅停止销售时，已购用户是否可以续费",
          "name": "名称",
          "stats": "统计",
          "group": "权限组",
          "price": "价格",
          "actions": "操作",
          "edit": "编辑",
          "delete": "删除",
          "delete_confirm": {
            "title": "确认删除",
            "description": "此操作将永久删除该订阅，删除后无法恢复。确定要继续吗？",
            "success": "删除成功"
          },
          "price_period": {
            "monthly": "月付",
            "quarterly": "季付",
            "half_yearly": "半年付",
            "yearly": "年付",
            "two_yearly": "两年付",
            "three_yearly": "三年付",
            "onetime": "流量包",
            "reset_traffic": "重置包",
            "unit": {
              "month": "元/月",
              "quarter": "元/季",
              "half_year": "元/半年",
              "year": "元/年",
              "two_year": "元/两年",
              "three_year": "元/三年",
              "times": "元/次"
            }
          }
        },
        "form": {
          "add_title": "添加套餐",
          "edit_title": "编辑套餐",
          "name": {
            "label": "套餐名称",
            "placeholder": "请输入套餐名称"
          },
          "group": {
            "label": "权限组",
            "placeholder": "选择权限组",
            "add": "添加权限组"
          },
          "transfer": {
            "label": "流量",
            "placeholder": "请输入流量大小",
            "unit": "GB"
          },
          "speed": {
            "label": "限速",
            "placeholder": "请输入限速",
            "unit": "Mbps"
          },
          "price": {
            "title": "售价设置",
            "base_price": "基础月付价格",
            "clear": {
              "button": "清空价格",
              "tooltip": "清空所有周期的价格设置"
            }
          },
          "device": {
            "label": "设备限制",
            "placeholder": "留空则不限制",
            "unit": "台"
          },
          "capacity": {
            "label": "容量限制",
            "placeholder": "留空则不限制",
            "unit": "人"
          },
          "reset_method": {
            "label": "流量重置方式",
            "placeholder": "选择流量重置方式",
            "description": "设置订阅流量的重置方式，不同的重置方式会影响用户的流量计算方式",
            "options": {
              "follow_system": "跟随系统设置",
              "monthly_first": "每月1号",
              "monthly_reset": "按月重置",
              "no_reset": "不重置",
              "yearly_first": "每年1月1日",
              "yearly_reset": "按年重置"
            }
          },
          "content": {
            "label": "套餐描述",
            "placeholder": "在这里编写套餐描述...",
            "description": "支持 Markdown 格式，可以使用标题、列表、粗体、斜体等样式来美化描述内容",
            "preview": "预览",
            "preview_button": {
              "show": "显示预览",
              "hide": "隐藏预览"
            },
            "template": {
              "button": "使用模板",
              "tooltip": "点击使用预设的套餐描述模板",
              "content": "## 套餐特点\n• 高速稳定的全球网络接入\n• 支持多设备同时在线\n• 无限制的流量重置\n\n## 使用说明\n1. 支持设备：iOS、Android、Windows、macOS\n2. 24/7 技术支持\n3. 自动定期流量重置\n\n## 注意事项\n- 禁止滥用\n- 遵守当地法律法规\n- 支持随时更换套餐"
            }
          },
          "force_update": {
            "label": "强制更新到用户"
          },
          "submit": {
            "submitting": "提交中...",
            "submit": "提交",
            "cancel": "取消",
            "success": {
              "add": "套餐添加成功",
              "update": "套餐更新成功"
            }
          }
        },
        "page": {
          "description": "在这里可以配置订阅计划，包括添加、删除、编辑等操作。"
        }
      }
    },
    "email": {
      "title": "邮件设置",
      "description": "配置系统邮件服务，用于发送验证码、密码重置、通知等邮件，支持多种SMTP服务商。",
      "tab_settings": "基本设置",
      "tab_templates": "模板管理",
      "email_host": {
        "title": "SMTP主机",
        "description": "SMTP服务器地址，例如：smtp.gmail.com"
      },
      "email_port": {
        "title": "SMTP端口",
        "description": "SMTP服务器端口，常用端口：25, 465, 587"
      },
      "email_username": {
        "title": "SMTP用户名",
        "description": "SMTP认证用户名"
      },
      "email_password": {
        "title": "SMTP密码",
        "description": "SMTP认证密码或应用专用密码"
      },
      "email_encryption": {
        "title": "加密方式",
        "description": "邮件加密方式",
        "none": "无",
        "ssl": "SSL/TLS",
        "tls": "STARTTLS"
      },
      "email_from": {
        "title": "发件人地址",
        "description": "发件人邮箱地址"
      },
      "email_from_name": {
        "title": "发件人名称",
        "description": "发件人显示名称"
      },
      "email_template": {
        "title": "邮件模板",
        "description": "自定义邮件模板方式请查看文档",
        "placeholder": "选择邮件模板"
      },
      "remind_mail": {
        "title": "邮件提醒",
        "description": "开启后用户订阅即将到期或流量不足时会收到邮件通知。"
      },
      "test": {
        "title": "发送测试邮件",
        "sending": "发送中...",
        "description": "发送测试邮件以验证配置",
        "success": "测试邮件发送成功",
        "error": "测试邮件发送失败"
      }
    },
    "telegram": {
      "title": "Telegram设置",
      "description": "配置Telegram机器人功能，实现用户通知、账户绑定、指令交互等自动化服务。",
      "bot_token": {
        "title": "机器人令牌",
        "description": "请输入从Botfather获取的令牌。",
        "placeholder": "0000000000:xxxxxxxxx_xxxxxxxxxxxxxxx"
      },
      "webhook_url": {
        "title": "Webhook Base URL",
        "description": "这里只填写基础地址，系统会自动拼接 Telegram 的完整 Webhook 回调路径。留空时默认使用站点网址。",
        "docs": "查看 Telegram Webhook 文档",
        "placeholder": "https://example.com"
      },
      "webhook": {
        "title": "设置Webhook",
        "description": "设置机器人的webhook，不设置将无法收到Telegram通知。",
        "button": "一键设置",
        "setting": "设置中...",
        "success": "Webhook 设置成功",
        "target_default": "当前将使用站点网址作为 Webhook Base URL。",
        "target_custom": "当前将使用自定义 Webhook Base URL：{{url}}",
        "debug": {
          "title": "Webhook 调试信息",
          "success": "成功状态",
          "url": "Webhook 地址",
          "baseUrl": "基础地址"
        }
      },
      "bot_enable": {
        "title": "启用Telegram绑定引导",
        "description": "开启后将在用户端显示Telegram绑定引导，帮助用户绑定Telegram账户以接收通知。"
      },
      "discuss_link": {
        "title": "群组链接",
        "description": "填写后将在用户端显示或在需要的地方使用。",
        "placeholder": "https://t.me/xxxxxx"
      }
    },
    "app": {
      "title": "APP设置",
      "description": "管理移动应用程序相关配置，包括API接口、版本控制、推送通知等功能设置。",
      "common": {
        "placeholder": "请输入"
      },
      "windows": {
        "version": {
          "title": "Windows版本",
          "description": "Windows客户端当前版本号"
        },
        "download": {
          "title": "Windows下载地址",
          "description": "Windows客户端下载链接"
        }
      },
      "macos": {
        "version": {
          "title": "macOS版本",
          "description": "macOS客户端当前版本号"
        },
        "download": {
          "title": "macOS下载地址",
          "description": "macOS客户端下载链接"
        }
      },
      "android": {
        "version": {
          "title": "Android版本",
          "description": "Android客户端当前版本号"
        },
        "download": {
          "title": "Android下载地址",
          "description": "Android客户端下载链接"
        }
      }
    },
    "common": {
      "saving": "保存中...",
      "save_success": "已自动保存",
      "placeholder": "请输入",
      "autoSaved": "已自动保存"
    },
    "invite": {
      "title": "邀请&佣金设置",
      "description": "邀请注册、佣金相关设置。",
      "invite_force": {
        "title": "开启强制邀请",
        "description": "开启后只有被邀请的用户才可以进行注册。"
      },
      "invite_commission": {
        "title": "邀请佣金百分比",
        "description": "默认全局的佣金分配比例，你可以在用户管理单独配置单个比例。",
        "placeholder": "请输入佣金百分比"
      },
      "invite_gen_limit": {
        "title": "用户可创建邀请码上限",
        "description": "用户可创建邀请码上限",
        "placeholder": "请输入创建上限"
      },
      "invite_never_expire": {
        "title": "邀请码永不失效",
        "description": "开启后邀请码被使用后将不会失效，否则使用过后即失效。"
      },
      "commission_first_time": {
        "title": "佣金仅首次发放",
        "description": "开启后被邀请人首次支付时才会产生佣金，可以在用户管理对用户进行单独配置。"
      },
      "commission_auto_check": {
        "title": "佣金自动确认",
        "description": "开启后佣金将会在订单完成3日后自动进行确认。"
      },
      "commission_withdraw_limit": {
        "title": "提现单申请门槛(元)",
        "description": "小于门槛金额的提现单将不会被提交。",
        "placeholder": "请输入提现门槛"
      },
      "commission_withdraw_method": {
        "title": "提现方式",
        "description": "可以支持的提现方式，多个用逗号分隔。",
        "placeholder": "请输入提现方式，多个用逗号分隔"
      },
      "withdraw_close": {
        "title": "关闭提现",
        "description": "关闭后将禁止用户申请提现，且邀请佣金将会直接进入用户余额。"
      },
      "commission_distribution": {
        "title": "三级分销",
        "description": "开启后将佣金将按照设置的3成比例进行分成，三成比例合计请不要大于100%。",
        "l1": "一级邀请人比例",
        "l2": "二级邀请人比例",
        "l3": "三级邀请人比例",
        "placeholder": "请输入比例，如：50"
      },
      "saving": "保存中..."
    },
    "server": {
      "title": "节点配置",
      "description": "配置节点通信和同步设置，包括通信密钥、轮询间隔、负载均衡等高级选项。",
      "server_token": {
        "title": "通讯密钥",
        "description": "Xboard与节点通讯的密钥，以便数据不会被他人获取。",
        "placeholder": "请输入通讯密钥",
        "generate_tooltip": "点击生成随机通信密钥"
      },
      "server_pull_interval": {
        "title": "节点拉取动作轮询间隔",
        "description": "节点从面板获取数据的间隔频率。",
        "placeholder": "请输入拉取间隔"
      },
      "server_push_interval": {
        "title": "节点推送动作轮询间隔",
        "description": "节点推送数据到面板的间隔频率。",
        "placeholder": "请输入推送间隔"
      },
      "device_limit_mode": {
        "title": "设备限制模式",
        "description": "宽松模式下，同一IP地址使用多个节点只统计为一个设备。",
        "strict": "严格模式",
        "relaxed": "宽松模式",
        "placeholder": "请选择设备限制模式"
      },
      "server_auto_sort_enable": {
        "title": "服务器自动排序",
        "description": "新服务器首次上报并识别出国家/地区后，排到同组同地区的最后一台后面。全部未分组时按地区归位；没有匹配节点时保留创建位置。开启不会重排已有服务器。"
      },
      "server_ws_enable": {
        "title": "启用 WebSocket 通信",
        "description": "开启后节点将通过 WebSocket 与面板进行实时通信，延迟更低、推送更及时。",
        "supported_clients": "目前支持 WebSocket 通信的节点端：Xboard Node"
      },
      "server_ws_url": {
        "title": "WebSocket 地址",
        "description": "节点连接面板的 WebSocket 地址，留空则自动使用站点网址。",
        "placeholder": "留空则使用站点网址"
      },
      "reality_scan_targets": {
        "title": "预设扫描目标",
        "description": "每行一个域名、IP 或网段，可填写端口，最多 64 项、合计 512 个地址。离开输入框自动保存，留空恢复默认列表。",
        "placeholder": "www.microsoft.com:443\naws.amazon.com:443"
      },
      "device_ip_exclude": {
        "title": "前置服务器 IP",
        "description": "只填自己的转发机、链式代理前置服务器的出口地址：这些地址不计入设备数；Xray 的 TCP 连接附带真实 IP 时，按真实 IP 计数。",
        "placeholder": "每行一个 IP 或网段，例如 203.0.113.10 或 203.0.113.0/24",
        "errors": {
          "invalid": "第 {{line}} 行不是有效的 IP 地址或网段",
          "too_broad": "第 {{line}} 行网段过宽，IPv4 至少 /16，IPv6 至少 /48",
          "too_many": "最多填写 {{max}} 项"
        }
      },
      "saving": "保存中...",
      "manage": {
        "title": "节点管理",
        "description": "管理所有节点，包括添加、删除、编辑等操作。"
      }
    },
    "subscribe_template": {
      "title": "订阅模板",
      "description": "配置各个客户端的订阅模板",
      "singbox": {
        "title": "Sing-box 订阅模板",
        "description": "配置 Sing-box 的订阅模板格式"
      },
      "clash": {
        "title": "Clash 订阅模板",
        "description": "配置 Clash 的订阅模板格式"
      },
      "clashmeta": {
        "title": "Clash Meta 订阅模板",
        "description": "配置 Clash Meta 的订阅模板格式"
      },
      "stash": {
        "title": "Stash 订阅模板",
        "description": "配置 Stash 的订阅模板格式"
      },
      "surge": {
        "title": "Surge 配置模板",
        "description": "配置 Surge 订阅模板，支持 Surge 配置文件格式"
      },
      "surfboard": {
        "title": "Surfboard 配置模版",
        "description": "配额 Surfboard 订阅模版"
      }
    },
    "email_template": {
      "title": "邮件模板",
      "description": "自定义系统发送的各类邮件内容模板",
      "customized": "已自定义",
      "subject": "邮件主题",
      "subject_placeholder": "输入邮件主题，支持 {{name}} 等占位符",
      "content": "模板内容 (HTML)",
      "preview": "实时预览",
      "override_hint": "修改并保存后将覆盖系统默认模板。点击「恢复默认」可随时还原为当前主题的默认模板。",
      "placeholders": "可用占位符",
      "var_name": "变量",
      "var_desc": "说明",
      "var_sample": "示例值",
      "required": "必填",
      "insert": "插入",
      "placeholder_hint": "* 标记为必须包含的占位符，点击可插入到内容末尾",
      "click_to_insert": "点击插入",
      "save": "保存",
      "save_success": "模板保存成功",
      "save_before_test": "请先保存修改后再发送测试",
      "send_test": "发送测试",
      "test_dialog_title": "发送测试邮件",
      "test_dialog_description": "输入收件邮箱，留空将发送到当前管理员邮箱",
      "test_email_placeholder": "收件邮箱（留空使用当前账号）",
      "sending": "发送中...",
      "test_success": "测试邮件已发送",
      "reset": "恢复默认",
      "reset_title": "恢复默认模板",
      "reset_description": "确定要恢复此模板为默认内容吗？自定义的内容将被删除。",
      "reset_confirm": "确定恢复",
      "reset_success": "已恢复默认模板",
      "unsaved": "有未保存的修改",
      "discard_title": "未保存的修改",
      "discard_description": "当前模板有未保存的修改，切换标签页将丢失这些修改。",
      "discard_confirm": "丢弃修改",
      "cancel": "取消"
    }
  },
  "notice": {
    "title": "公告管理",
    "description": "在这里可以配置公告，包括添加、删除、编辑等操作。",
    "table": {
      "columns": {
        "id": "ID",
        "show": "显示状态",
        "title": "标题",
        "actions": "操作"
      },
      "toolbar": {
        "search": "搜索公告标题...",
        "reset": "重置",
        "sort": {
          "edit": "编辑排序",
          "save": "保存排序"
        }
      },
      "actions": {
        "edit": "编辑",
        "delete": {
          "title": "删除确认",
          "description": "确定要删除该条公告吗？此操作无法撤销。",
          "success": "删除成功"
        }
      }
    },
    "form": {
      "add": {
        "title": "添加公告",
        "button": "添加公告"
      },
      "edit": {
        "title": "编辑公告"
      },
      "fields": {
        "title": {
          "label": "标题",
          "placeholder": "请输入公告标题"
        },
        "content": {
          "label": "公告内容"
        },
        "img_url": {
          "label": "公告背景",
          "placeholder": "请输入公告背景图片URL"
        },
        "show": {
          "label": "显示"
        },
        "tags": {
          "label": "节点标签",
          "placeholder": "输入后回车添加标签"
        }
      },
      "buttons": {
        "cancel": "取消",
        "submit": "提交",
        "success": "提交成功"
      }
    }
  },
  "group": {
    "title": "权限组管理",
    "description": "管理所有权限组，包括添加、删除、编辑等操作。",
    "columns": {
      "id": "组ID",
      "name": "组名称",
      "usersCount": "用户数量",
      "serverCount": "节点数量",
      "actions": "操作"
    },
    "form": {
      "add": "添加权限组",
      "edit": "编辑权限组",
      "create": "创建权限组",
      "update": "更新",
      "name": "组名称",
      "namePlaceholder": "请输入权限组名称",
      "nameDescription": "权限组名称用于标识不同的用户组，建议使用有意义的名称。",
      "cancel": "取消",
      "editDescription": "修改权限组信息，更新后会立即生效。",
      "createDescription": "创建新的权限组，可以为不同的用户分配不同的权限。"
    },
    "toolbar": {
      "searchPlaceholder": "搜索权限组...",
      "reset": "重置",
      "sort": {
        "tip": "拖拽权限组进行排序，完成后点击保存",
        "edit": "编辑排序",
        "save": "保存排序",
        "success": "排序保存成功"
      }
    },
    "messages": {
      "deleteConfirm": "确认删除",
      "deleteDescription": "此操作将永久删除该权限组，删除后无法恢复。确定要继续吗？",
      "deleteButton": "删除",
      "createSuccess": "创建成功",
      "updateSuccess": "更新成功",
      "nameValidation": {
        "min": "组名至少需要2个字符",
        "max": "组名不能超过50个字符",
        "pattern": "组名只能包含字母、数字、中文、下划线和连字符"
      }
    }
  },
  "auth": {
    "signIn": {
      "title": "登录",
      "description": "请输入您的邮箱和密码登录系统",
      "email": "邮箱地址",
      "emailPlaceholder": "name@example.com",
      "password": "密码",
      "passwordPlaceholder": "请输入密码",
      "forgotPassword": "忘记密码？",
      "submit": "登录",
      "rememberMe": "记住我",
      "resetPassword": {
        "title": "重置密码",
        "description": "在站点目录下执行以下命令找回密码",
        "command": "php artisan reset:password 管理员邮箱"
      },
      "totp": {
        "title": "两步验证",
        "description": "请输入验证器 App 上的动态验证码，或使用一个恢复码。",
        "code": "验证码",
        "codePlaceholder": "请输入 6 位验证码或恢复码",
        "submit": "验证并登录",
        "back": "返回重新登录",
        "failed": "验证失败，请重试"
      },
      "validation": {
        "emailRequired": "请输入邮箱地址",
        "emailInvalid": "邮箱地址格式不正确",
        "passwordRequired": "请输入密码",
        "passwordLength": "密码长度至少为7个字符"
      }
    }
  },
  "traffic": {
    "trafficRecord": {
      "title": "流量使用记录",
      "time": "时间",
      "upload": "上行流量",
      "download": "下行流量",
      "rate": "倍率",
      "total": "总计",
      "noRecords": "暂无记录",
      "perPage": "每页显示",
      "records": "条记录",
      "page": "第 {{current}} / {{total}} 页",
      "multiplier": "{{value}}x"
    }
  },
  "payment": {
    "title": "支付配置",
    "description": "在这里可以配置支付方式，包括支付宝、微信等。",
    "table": {
      "columns": {
        "id": "ID",
        "enable": "启用",
        "name": "显示名称",
        "payment": "支付接口",
        "notify_url": "通知地址",
        "notify_url_tooltip": "支付网关将会把数据通知到本地址，请通过防火墙放行本地址。",
        "actions": "操作"
      },
      "actions": {
        "edit": "编辑",
        "delete": {
          "title": "删除确认",
          "description": "确定要删除该支付方式吗？此操作无法撤销。",
          "success": "删除成功"
        }
      },
      "toolbar": {
        "search": "搜索支付方式...",
        "reset": "重置",
        "sort": {
          "hint": "拖拽支付方式进行排序，完成后点击保存",
          "save": "保存排序",
          "edit": "编辑排序"
        }
      }
    },
    "form": {
      "add": {
        "button": "添加支付方式",
        "title": "添加支付方式"
      },
      "edit": {
        "title": "编辑支付方式"
      },
      "fields": {
        "name": {
          "label": "显示名称",
          "placeholder": "请输入支付名称",
          "description": "用于前端显示"
        },
        "icon": {
          "label": "图标URL",
          "placeholder": "https://example.com/icon.svg",
          "description": "用于前端显示的图标地址"
        },
        "notify_domain": {
          "label": "通知域名",
          "placeholder": "https://example.com",
          "description": "网关通知将发送到该域名"
        },
        "handling_fee_percent": {
          "label": "百分比手续费(%)",
          "placeholder": "0-100"
        },
        "handling_fee_fixed": {
          "label": "固定手续费",
          "placeholder": "0"
        },
        "payment": {
          "label": "支付接口",
          "placeholder": "请选择支付接口",
          "description": "选择要使用的支付接口"
        }
      },
      "validation": {
        "name": {
          "min": "名称至少需要2个字符",
          "max": "名称不能超过30个字符"
        },
        "notify_domain": {
          "url": "请输入有效的URL"
        },
        "payment": {
          "required": "请选择支付接口"
        }
      },
      "buttons": {
        "cancel": "取消",
        "submit": "提交"
      },
      "sections": {
        "payment_config": "支付配置"
      },
      "messages": {
        "success": "保存成功"
      }
    }
  },
  "server": {
    "realityScan": {
      "certChain": "证书链",
      "location": "IP 位置",
      "pageStatus": "页面状态",
      "unknown": "未知",
      "notProvided": "未提供",
      "cdnNotDetected": "未发现特征",
      "detailsUpgrade": "CDN 和页面状态需要 Node v2.14.0 或更高版本。",
      "page": {
        "normal": "正常", "redirect": "跳转", "unchanged": "未修改",
        "authentication": "需要认证", "forbidden": "拒绝访问", "notFound": "页面不存在",
        "rateLimited": "请求过多", "restricted": "访问受限", "serverError": "服务错误",
        "clientError": "请求错误", "information": "信息响应", "timeout": "响应超时",
        "failed": "请求失败", "not_checked": "未检测"
      },
      "close": "关闭",
      "scanCurrent": "检测当前目标",
      "scanTargets": "扫描目标",
      "title": "Reality 目标检测",
      "targets": "检测目标",
      "placeholder": "域名、IP 或 CIDR，以逗号或换行分隔；留空检测预设域名",
      "scan": "开始检测",
      "scanning": "检测中…",
      "pending": "等待节点接收",
      "running": "节点正在检测",
      "requestFailed": "无法读取检测结果，请重试。",
      "bindMachine": "请先为节点绑定服务器。",
      "currentRequired": "请先填写伪装域名和有效端口。",
      "currentDestinationRequired": "请先填写回源地址和握手域名。",
      "expired": "检测记录已过期，请重新检测。",
      "retry": "重新读取",
      "applied": "已填入 {{target}}，保存节点后生效。",
      "empty": "没有发现可用域名。",
      "available": "可用",
      "unavailable": "不可用",
      "use": "使用",
      "curve": "密钥交换",
      "certificate": "证书",
      "valid": "有效",
      "invalid": "未通过",
      "expires": "证书到期",
      "certDomain": "证书域名",
      "reason": {
        "dns_failed": "域名解析失败。",
        "private_target": "不支持检测内网、本机或保留地址。",
        "connection_failed": "无法连接目标端口。",
        "tls_failed": "TLS 握手失败或超时。",
        "no_certificate": "目标没有返回证书。",
        "no_domain": "证书中没有可用的具体域名。",
        "discovered": "发现证书域名，但证书链未通过验证。",
        "certificate_invalid": "证书不受信任、已过期或与域名不匹配。",
        "tls13_required": "目标不支持 TLS 1.3。",
        "h2_required": "目标未协商 HTTP/2。",
        "x25519_required": "目标未使用 X25519 密钥交换。",
        "invalid_target": "检测目标格式无效。",
        "invalid_cidr": "网段格式无效或超过 256 个地址。",
        "too_many_targets": "单次检测超过 512 个地址。",
        "timeout": "检测超时，请减少目标数量后重试。",
        "node_restarted": "检测期间节点重启或停用，请重新检测。",
        "unknown": "检测未通过。"
      }
    },
    "visibility": { "hide": "隐藏", "show": "显示", "hidden": "已隐藏", "failed": "显隐更新失败，请重试", "refreshFailed": "显隐已更新，请刷新列表确认" },
    "portConflictWarning": "端口可能冲突",
    "manage": {
      "title": "节点管理",
      "description": "管理所有节点，包括添加、删除、编辑等操作。",
      "filtered_by_server": "当前正在查看服务器 {{server}} (SID:{{id}}) 下的节点",
      "filtered_by_server_description": "在这里新增节点时，可以直接复用当前服务器作为部署目标。",
      "add_node_to_server": "新增节点到此服务器",
      "clear_server_filter": "清除服务器筛选"
    },
    "columns": {
      "sort": "排序",
      "nodeId": "节点ID",
      "show": "显隐",
      "node": "节点",
      "address": "地址",
      "onlineUsers": {
        "title": "在线人数",
        "tooltip": "在线人数根据服务端上报频率而定"
      },
      "rate": {
        "title": "倍率",
        "tooltip": "流量扣费倍率"
      },
      "usage": {"title":"节点用量","tooltip":"用户实际使用线路的原始上传和下载之和。中转只归落地，前置只计直出；不乘倍率。"},
      "capacity": {"title":"承载量 / 上限","tooltip":"沿用原承载量口径与重置规则，入口包含前置转发，不乘倍率。"},
      "traffic": {
        "title": "流量使用",
        "tooltip": "节点流量使用情况，显示已用流量和限制",
        "total": "总流量",
        "used": "已用",
        "percentage": "使用率"
      },
      "groups": {
        "title": "权限组",
        "tooltip": "可订阅到该节点的权限组",
        "empty": "--",
        "more": "查看全部 {{total}} 个权限组"
      },
      "loadStatus": {
        "title": "负载状态",
        "tooltip": "服务器资源使用情况",
        "noData": "暂无数据",
        "details": "系统负载详情",
        "cpu": "CPU 使用率",
        "memory": "内存使用",
        "swap": "交换区",
        "disk": "磁盘使用",
        "lastUpdate": "最后更新",
        "metrics": {
          "title": "运行指标",
          "uptime": "运行时长",
          "conns": "实时/总连接",
          "speed": "实时速率",
          "api": "API 状态",
          "kernel": "内核状态",
          "gc": "GC 暂停",
          "limit": "限速用户",
          "ws": "WebSocket",
          "goroutines": "并发协程",
          "load": "系统负载",
          "users": "在线用户"
        }
      },
      "customId": "自定义ID",
      "originalId": "原始ID",
      "type": "类型",
      "actions": "操作",
      "copyAddress": "复制连接地址",
      "internalPort": "内部端口",
      "deployment": {
        "title": "部署方式",
        "tooltip": "查看节点是独立部署，还是由某台服务器托管，并可直接在列表中调整。",
        "standalone": "独立部署",
        "standalone_row_hint": "未绑定服务器",
        "standalone_description": "该节点不依赖服务器托管，适用于单节点独立部署。",
        "online": "服务器在线",
        "offline": "服务器离线",
        "inactive": "服务器未激活",
        "disabled": "节点停用",
        "enabled": "在服务器上启用",
        "enabled_description": "仅已启用的节点会由所选服务器拉起并同步。",
        "enabled_standalone_description": "独立部署节点无需设置服务器启用状态。",
        "bind_success": "已托管到 {{server}}",
        "standalone_success": "已切换为独立部署",
        "update_success": "部署状态已更新",
        "update_error": "部署状态更新失败"
      },
      "status": {
        "0": "未运行",
        "1": "无人使用或异常",
        "2": "运行正常"
      },
      "childNode": "子节点",
      "actions_dropdown": {
        "edit": "编辑",
        "copy": "复制",
        "reset_traffic": {
          "title": "确认重置流量",
          "description": "此操作将清零该节点的上传和下载流量，并解除禁用状态。确定要继续吗？",
          "confirm": "重置流量"
        },
        "reset_traffic_success": "流量重置成功",
        "delete": {
          "title": "确认删除",
          "description": "此操作将永久删除该节点，删除后无法恢复。确定要继续吗？",
          "confirm": "删除"
        },
        "copy_success": "复制成功",
        "delete_success": "删除成功"
      }
    },
    "toolbar": {
      "unify_reality": {
        "loading_pools": "正在读取关联前置池…",
        "scope_failed": "读取关联前置池失败，请重试",
        "reload_pools": "重新读取关联池",
        "related_pools": "将同步关联前置池：",
        "linked_success": "已统一 {{count}} 个节点，并同步 {{pools}} 个前置池",
        "generate_short_failed": "生成 Short ID 失败，请重试",
        "mode": "统一方式",
        "node_mode": "统一成某个节点",
        "manual_mode": "手动填写",
        "source": "基准节点",
        "menu": "统一 Reality 参数",
        "description": "将所选 {{count}} 个节点的密钥对、短 ID、握手域名和握手端口统一。使用旧参数的客户端需要更新订阅。",
        "server_name": "握手域名",
        "server_port": "握手端口",
        "cancel": "取消",
        "confirm": "确认统一",
        "pending": "正在统一",
        "success": "已统一 {{count}} 个节点的 Reality 参数",
        "failed": "统一 Reality 参数失败，请重试"
      },
      "search": "搜索节点...",
      "country": "地区",
      "country_unknown": "未识别",
      "type": "类型",
      "server": "服务器",
      "server_search": "搜索服务器...",
      "server_empty": "未找到服务器",
      "reset": "重置",
      "actions": "操作",
      "sort": {
        "tip": "拖拽节点进行排序，完成后点击保存",
        "batch": "批量排序",
        "selected": "已选 {{count}} 个节点",
        "top": "移至顶部",
        "up": "上移一位",
        "down": "下移一位",
        "bottom": "移至底部",
        "clear": "取消选择",
        "error": "排序保存或刷新失败，请重试",
        "edit": "编辑排序",
        "save": "保存排序",
        "success": "排序保存成功"
      },
      "batch_delete": {
        "menu": "删除节点",
        "button": "删除 {{count}} 项",
        "title": "确认批量删除",
        "description": "确定要删除选中的 {{count}} 个节点吗？此操作不可恢复。",
        "confirm": "确认删除"
      },
      "batch_delete_success": "成功删除 {{count}} 个节点",
      "batch_delete_error": "批量删除失败",
      "batch_show": {
        "menu": "显示节点"
      },
      "batch_show_success": "成功显示 {{count}} 个节点",
      "batch_show_error": "批量显示失败",
      "batch_hide": {
        "menu": "隐藏节点"
      },
      "batch_hide_success": "成功隐藏 {{count}} 个节点",
      "batch_hide_error": "批量隐藏失败",
      "batch_enable": {
        "menu": "启用节点"
      },
      "batch_enable_success": "成功启用 {{count}} 个节点",
      "batch_enable_error": "批量启用失败",
      "batch_disable": {
        "menu": "禁用节点"
      },
      "batch_disable_success": "成功禁用 {{count}} 个节点",
      "batch_disable_error": "批量禁用失败",
      "batch_reset_traffic": {
        "menu": "重置流量",
        "button": "重置 {{count}} 项流量",
        "title": "确认批量重置流量",
        "description": "确定要重置选中的 {{count}} 个节点的流量吗？此操作将清零流量并解除禁用状态。",
        "confirm": "确认重置"
      },
      "batch_reset_traffic_success": "成功重置 {{count}} 个节点的流量",
      "batch_reset_traffic_error": "批量重置流量失败"
    },
    "form": {
      "add_node": "添加节点",
      "edit_node": "编辑节点",
      "new_node": "新建节点",
      "type": {
        "placeholder": "选择协议类型",
        "select_prompt": "请先选择协议类型",
        "select_error": "请先选择协议类型"
      },
      "name": {
        "label": "节点名称",
        "placeholder": "请输入节点名称",
        "error": "请输入有效的节点名称"
      },
      "rate": {
        "label": "基础倍率",
        "effective_label": "前置倍率",
        "independent_label": "独立倍率",
        "error": "基础倍率不能为空",
        "error_numeric": "基础倍率必须是数字",
        "error_gte_zero": "基础倍率必须大于或等于0",
        "child_node_tooltip": "子节点的基础倍率继承自父节点，无法单独设置",
        "child_node_note": "子节点倍率继承自父节点"
      },
      "traffic_limit": {
        "label": "流量限制",
        "placeholder": "0 表示不限制",
        "hint": "设置节点流量上限（单位：GB），0 表示不限制",
        "error_numeric": "流量限制必须是数字",
        "error_gte_zero": "流量限制必须大于或等于0"
      },
      "banned": {
        "label": "禁用节点",
        "description": "禁用后节点将不可用"
      },
      "dynamic_rate": {
        "section_title": "动态倍率配置",
        "enable_label": "启用动态倍率",
        "enable_description": "根据时间段设置不同的倍率乘数",
        "rules_label": "时间段规则",
        "add_rule": "添加规则",
        "rule_title": "规则 {{index}}",
        "start_time": "开始时间",
        "end_time": "结束时间",
        "multiplier": "倍率乘数",
        "no_rules": "暂无规则，点击上方按钮添加",
        "start_time_error": "开始时间不能为空",
        "end_time_error": "结束时间不能为空",
        "multiplier_error": "倍率乘数不能为空",
        "multiplier_error_numeric": "倍率乘数必须是数字",
        "multiplier_error_gte_zero": "倍率乘数必须大于或等于0"
      },
      "code": {
        "label": "自定义节点ID",
        "optional": "(选填)",
        "placeholder": "请输入自定义节点ID"
      },
      "tags": {
        "label": "节点标签",
        "placeholder": "输入后回车添加标签"
      },
      "groups": {
        "label": "权限组",
        "add": "添加权限组",
        "placeholder": "请选择权限组",
        "empty": "未找到结果"
      },
      "machine": {
        "label": "绑定服务器",
        "placeholder": "选择服务器（可选）",
        "none": "独立部署",
        "enabled_hint": "选择是否由此服务器管理该节点"
      },
      "host": {
        "label": "节点地址",
        "placeholder": "请输入节点域名或者IP",
        "error": "节点地址不能为空"
      },
      "port": {
        "label": "连接端口",
        "placeholder": "用户连接端口",
        "tooltip": "用户实际连接使用的端口号。如果使用了中转或隧道，这个端口可能与服务器实际监听的端口不同。",
        "sync": "同步到服务端口",
        "error": "连接端口不能为空"
      },
      "server_port": {
        "label": "服务端口",
        "placeholder": "请输入服务端口",
        "error": "服务端口不能为空",
        "tooltip": "服务器上的实际监听端口。"
      },
      "listen_address": {
        "label": "监听地址",
        "placeholder": "留空使用默认 (0.0.0.0)，或输入: 127.0.0.1, ::1 等",
        "description": "指定服务器监听的 IP 地址。留空则使用默认地址 (0.0.0.0)，表示监听所有网络接口。可设置为 127.0.0.1 (仅本地) 或特定 IP 地址",
        "show": "监听地址",
        "hide": "隐藏监听地址",
        "optional": "可选"
      },
      "parent": {
        "label": "父级节点",
        "placeholder": "选择父节点",
        "none": "无"
      },
      "proxy_protocol": {
        "label": "接收 PROXY 协议"
      },
      "auto_firewall": {
        "label": "自动管理防火墙",
        "disabled_hint": "关闭后恢复原有规则，来源名单不再由系统防火墙执行。"
      },
      "source_policy": {
        "label": "来源 IP 限制",
        "disabled": "关闭",
        "blacklist": "黑名单",
        "whitelist": "白名单",
        "block_ips": "屏蔽来源 IP",
        "allow_ips": "允许来源 IP",
        "exceptions": "大陆 IP 例外放行",
        "block_cn": "屏蔽大陆来源 IP",
        "placeholder": "输入 IP，按回车添加",
        "invalid_ip": "请填写具体的 IPv4 或 IPv6 地址",
        "max_ips": "每份名单最多添加 128 个 IP",
        "empty_whitelist": "白名单至少填写一个 IP",
        "connections": "连接设置",
        "save": "保存"
      },
      "route": {
        "label": "路由组",
        "placeholder": "选择路由组",
        "empty": "未找到结果"
      },
      "submit": "提交",
      "cancel": "取消",
      "success": "提交成功"
    },
    "dynamic_form": {
      "multiplex": {
        "enabled": {
          "label": "多路复用 (Multiplex)",
          "description": "通过单条 TCP 连接传输多个流，降低握手延迟"
        },
        "protocol": {
          "label": "复用协议"
        },
        "max_connections": {
          "label": "最大连接数"
        },
        "min_streams": {
          "label": "最小流数"
        },
        "padding": {
          "label": "启用填充"
        },
        "brutal": {
          "enabled": {
            "label": "TCP Brutal (激进拥塞控制)"
          },
          "up_mbps": {
            "label": "上行带宽"
          },
          "down_mbps": {
            "label": "下行带宽"
          },
          "description": "TCP Brutal 是双边加速算法，建议带宽设为机器实际带宽的 80%-90%，开启后 BBR 将失效。"
        }
      },
      "ech": {
        "description": "为支持的 TLS 客户端启用 Encrypted Client Hello。留空配置时会尝试通过 DNS 查询。",
        "generate": "自动生成 ECH 密钥对",
        "config": {
          "label": "ECH 配置 (PEM)",
          "placeholder": "粘贴 PEM 格式的 ECH 配置，每行一段内容",
          "description": "留空时，sing-box 会尝试通过 DNS 加载 ECH 配置。"
        },
        "config_path": {
          "label": "ECH 配置文件路径",
          "placeholder": "/etc/sing-box/ech.pem",
          "description": "指向 PEM 格式 ECH 配置文件的路径。"
        },
        "query_server_name": {
          "label": "ECH 查询域名",
          "placeholder": "可选，用于覆盖 HTTPS 记录查询域名",
          "description": "覆盖用于 ECH HTTPS 记录查询的域名，留空时默认使用 server_name。"
        },
        "key": {
          "label": "ECH Key",
          "placeholder": "当后端需要时粘贴 ECH key 内容",
          "description": "后端需要时可填写的 ECH key 内容。"
        },
        "key_path": {
          "label": "ECH Key 路径",
          "placeholder": "/etc/sing-box/ech.key",
          "description": "后端需要时可填写的 ECH key 文件路径。"
        }
      },
      "anytls": {
        "tls": {
          "server_name": {
            "label": "服务器名称指示(SNI)",
            "placeholder": "当节点地址与证书不一致时用于证书验证"
          },
          "allow_insecure": "允许不安全连接"
        },
        "padding_scheme": {
          "label": "填充方案",
          "placeholder": "选择填充方案",
          "edit_btn": "编辑填充方案",
          "configured": "已配置 {{count}} 条规则",
          "not_configured": "未配置",
          "description": "用于混淆流量特征的填充方案，每行一条规则，支持通配符 *",
          "use_default": "使用默认方案"
        }
      },
      "shadowsocks": {
        "cipher": {
          "label": "加密算法",
          "placeholder": "选择加密算法",
          "search_placeholder": "搜索或输入自定义加密方式...",
          "description": "选择预设加密方式或输入自定义加密方式",
          "preset_group": "预设加密方式",
          "custom_group": "自定义加密方式",
          "current_value": "当前值",
          "use_custom": "使用",
          "no_results": "未找到匹配的加密方式",
          "custom_hint": "你可以直接输入自定义的加密方式，如：aes-256-cfb",
          "custom_label": "自定义"
        },
        "plugin": {
          "label": "插件",
          "placeholder": "选择插件",
          "obfs_hint": "提示：配置格式如 obfs=http;obfs-host=www.bing.com;path=/",
          "v2ray_hint": "提示：WebSocket模式格式为 mode=websocket;host=mydomain.me;path=/;tls=true，QUIC模式格式为 mode=quic;host=mydomain.me",
          "gost_hint": "提示：配置格式如 mode=websocket;host=mydomain.me;path=/;tls=true",
          "shadow_tls_hint": "提示：配置格式如 host=cloud.tencent.com;password=auth_password;version=3",
          "restls_hint": "提示：配置格式如 host=www.microsoft.com;password=auth_password;version-hint=tls13;restls-script=300?100<1,400~100",
          "kcptun_hint": "提示：配置格式如 key=psk;crypt=aes-128-gcm;mode=fast;mtu=1350"
        },
        "plugin_opts": {
          "label": "插件选项",
          "description": "按照 key=value;key2=value2 格式输入插件选项",
          "placeholder": "例如: mode=tls;host=bing.com"
        },
        "client_fingerprint": "客户端指纹",
        "client_fingerprint_placeholder": "选择客户端指纹",
        "client_fingerprint_description": "客户端伪装指纹，用于降低被识别风险",
        "obfs": {
          "label": "混淆",
          "placeholder": "选择混淆方式",
          "none": "无",
          "http": "HTTP"
        },
        "obfs_settings": {
          "path": "路径",
          "host": "Host"
        },
        "cert_config": {
          "tab": "TLS 证书",
          "cert_mode": {
            "label": "证书模式",
            "description": "选择证书申请方式，仅部分后端节点支持",
            "self_description": "自签名模式：仅需填写域名，证书由节点后端自动生成（10年有效期）",
            "http_description": "HTTP-01 模式：需要 80 端口可正常访问以完成认证",
            "dns_description": "DNS-01 模式：通过 DNS 解析记录认证，支持申请泛域名证书",
            "content_description": "内容推送模式：直接将证书内容下发至节点"
          },
          "domain": {
            "label": "证书域名",
            "placeholder": "example.com"
          },
          "email": {
            "label": "通知邮箱",
            "placeholder": "admin@example.com"
          },
          "http_port": {
            "label": "认证端口",
            "description": "ACME 认证端口 (默认 80)"
          },
          "dns_provider": {
            "label": "DNS 提供商",
            "doc_link": "查看 DNS 提供商配置指南"
          },
          "dns_env": {
            "label": "环境变量 (API 密钥)",
            "description_short": "每行一个 KEY=VALUE 配置"
          },
          "cert_content": {
            "label": "证书内容 (Public Key)"
          },
          "key_content": {
            "label": "密钥内容 (Private Key)"
          },
          "none_desc": "未启用 TLS 证书配置"
        }
      },
      "vmess": {
        "tls": {
          "label": "TLS",
          "placeholder": "请选择安全性",
          "disabled": "不支持",
          "enabled": "支持"
        },
        "tls_settings": {
          "server_name": {
            "label": "服务器名称指示(SNI)",
            "placeholder": "不使用请留空"
          },
          "allow_insecure": "允许不安全?"
        },
        "network": {
          "label": "传输协议",
          "placeholder": "选择传输协议"
        }
      },
      "trojan": {
        "server_name": {
          "label": "服务器名称指示(SNI)",
          "placeholder": "当节点地址于证书不一致时用于证书验证"
        },
        "allow_insecure": "允许不安全?",
        "reality_settings": {
          "server_name": {
            "label": "伪装站点(dest)",
            "placeholder": "例如：example.com"
          },
          "server_port": {
            "label": "端口(port)",
            "placeholder": "例如：443"
          },
          "allow_insecure": "允许不安全?",
          "private_key": {
            "label": "私钥(Private key)"
          },
          "public_key": {
            "label": "公钥(Public key)"
          },
          "short_id": {
            "label": "Short ID",
            "placeholder": "可留空，长度为2的倍数，最长16位",
            "description": "客户端可用的 shortId 列表，可用于区分不同的客户端，使用0-f的十六进制字符",
            "generate": "生成 Short ID",
            "success": "Short ID 生成成功"
          },
          "key_pair": {
            "generate": "生成密钥对",
            "success": "密钥对生成成功",
            "error": "生成密钥对失败"
          }
        },
        "network": {
          "label": "传输协议",
          "placeholder": "选择传输协议"
        }
      },
      "hysteria": {
        "version": {
          "label": "协议版本",
          "placeholder": "协议版本"
        },
        "alpn": {
          "label": "ALPN",
          "placeholder": "ALPN"
        },
        "obfs": {
          "label": "混淆",
          "type": {
            "label": "混淆实现",
            "placeholder": "选择混淆实现",
            "salamander": "Salamander"
          },
          "password": {
            "label": "混淆密码",
            "placeholder": "请输入混淆密码",
            "generate_success": "混淆密码生成成功"
          }
        },
        "tls": {
          "server_name": {
            "label": "服务器名称指示(SNI)",
            "placeholder": "当节点地址于证书不一致时用于证书验证"
          },
          "allow_insecure": "允许不安全?"
        },
        "bandwidth": {
          "up": {
            "label": "上行宽带",
            "placeholder": "请输入上行宽带",
            "suffix": "Mbps",
            "bbr_tip": "，留空则使用BBR"
          },
          "down": {
            "label": "下行宽带",
            "placeholder": "请输入下行宽带",
            "suffix": "Mbps",
            "bbr_tip": "，留空则使用BBR"
          }
        }
      },
      "vless": {
        "xhttp": {
          "path": "路径",
          "host": "Host",
          "mode": "XHTTP 模式",
          "http": "HTTP 版本",
          "default": "默认",
          "split": "上下行分流",
          "address": "下载地址",
          "port": "下载端口",
          "security": "下载安全性",
          "none": "无",
          "sni": "下载握手域名",
          "publicKey": "下载 Reality 公钥",
          "shortId": "下载 Short ID",
          "sameInbound": "上下行入口须回源到同一个 XHTTP 入站。"
        },
        "tls": {
          "label": "安全性",
          "placeholder": "请选择安全性",
          "none": "无",
          "tls": "TLS",
          "reality": "Reality"
        },
        "tls_settings": {
          "server_name": {
            "label": "服务器名称指示(SNI)",
            "placeholder": "不使用请留空"
          },
          "allow_insecure": "允许不安全?"
        },
        "reality_settings": {
          "anti_abuse": {
            "label": "防盗用模式",
            "description": "伪装回源改走节点本机的专用入口，只放行伪装站点的 TLS 域名，其余流量直接阻断"
          },
          "dest": {
            "label": "回源地址(dest)",
            "placeholder": "例如：127.0.0.1:8443"
          },
          "server_name": {
            "label": "握手域名(SNI)",
            "placeholder": "例如：example.com"
          },
          "server_port": {
            "label": "端口(port)",
            "placeholder": "例如：443"
          },
          "allow_insecure": "允许不安全?",
          "private_key": {
            "label": "私钥(Private key)"
          },
          "public_key": {
            "label": "公钥(Public key)"
          },
          "short_id": {
            "label": "Short ID",
            "placeholder": "可留空，长度为2的倍数，最长16位",
            "description": "客户端可用的 shortId 列表，可用于区分不同的客户端，使用0-f的十六进制字符",
            "generate": "生成 Short ID",
            "success": "Short ID 生成成功"
          },
          "key_pair": {
            "generate": "生成密钥对",
            "success": "密钥对生成成功",
            "error": "生成密钥对失败"
          }
        },
        "network": {
          "label": "传输协议",
          "placeholder": "选择传输协议"
        },
        "flow": {
          "label": "流控",
          "placeholder": "选择流控"
        },
        "encryption": {
          "label": "VLESS Encryption",
          "description": "启用 VLESS 加密",
          "server_label": "decryption",
          "server_placeholder": "./xray vlessenc 生成",
          "server_description": "",
          "client_label": "encryption",
          "client_placeholder": "./xray vlessenc 生成",
          "client_description": "",
          "generate_hint": "./xray vlessenc 生成"
        }
      },
      "tuic": {
        "version": {
          "label": "协议版本",
          "placeholder": "选择TUIC版本"
        },
        "password": {
          "label": "密码",
          "placeholder": "请输入密码",
          "generate_success": "密码生成成功"
        },
        "congestion_control": {
          "label": "拥塞控制",
          "placeholder": "选择拥塞控制算法"
        },
        "udp_relay_mode": {
          "label": "UDP中继模式",
          "placeholder": "选择UDP中继模式"
        },
        "tls": {
          "server_name": {
            "label": "服务器名称指示(SNI)",
            "placeholder": "当节点地址与证书不一致时用于证书验证"
          },
          "allow_insecure": "允许不安全?",
          "alpn": {
            "label": "ALPN",
            "placeholder": "选择ALPN协议",
            "empty": "未找到可用的ALPN协议"
          }
        }
      },
      "socks": {
        "version": {
          "label": "协议版本",
          "placeholder": "选择SOCKS版本"
        },
        "tls": {
          "label": "TLS",
          "placeholder": "请选择安全性",
          "disabled": "不支持",
          "enabled": "支持"
        },
        "tls_settings": {
          "server_name": {
            "label": "服务器名称指示(SNI)",
            "placeholder": "不使用请留空"
          },
          "allow_insecure": "允许不安全?"
        },
        "network": {
          "label": "传输协议",
          "placeholder": "选择传输协议"
        }
      },
      "naive": {
        "tls_settings": {
          "server_name": {
            "label": "服务器名称指示(SNI)",
            "placeholder": "不使用请留空"
          },
          "allow_insecure": "允许不安全?"
        },
        "tls": {
          "label": "TLS",
          "placeholder": "请选择安全性",
          "disabled": "不支持",
          "enabled": "支持",
          "server_name": {
            "label": "服务器名称指示(SNI)",
            "placeholder": "当节点地址与证书不一致时用于证书验证"
          },
          "allow_insecure": "允许不安全连接"
        }
      },
      "http": {
        "tls": {
          "label": "TLS",
          "placeholder": "请选择安全性",
          "disabled": "不支持",
          "enabled": "支持",
          "server_name": {
            "label": "服务器名称指示(SNI)",
            "placeholder": "当节点地址与证书不一致时用于证书验证"
          },
          "allow_insecure": "允许不安全连接"
        },
        "tls_settings": {
          "server_name": {
            "label": "服务器名称指示(SNI)",
            "placeholder": "当节点地址与证书不一致时用于证书验证"
          },
          "allow_insecure": "允许不安全连接"
        }
      },
      "mieru": {
        "transport": {
          "label": "传输协议",
          "placeholder": "选择传输协议"
        },
        "traffic_pattern": {
          "label": "流量 (Base64)",
          "placeholder": "请输入 Base64 字符串用于微调网络行为",
          "success": "流量模式已生成"
        }
      },
      "cert_config": {
        "tab": "TLS 证书",
        "cert_mode": {
          "label": "证书模式",
          "description": "选择证书申请方式，仅部分后端节点支持",
          "none_desc": "未启用 TLS 证书配置"
        },
        "domain": {
          "label": "证书域名"
        },
        "email": {
          "label": "通知邮箱"
        },
        "http_port": {
          "label": "挑战端口",
          "description": "ACME 挑战端口 (默认 80)"
        },
        "dns_provider": {
          "label": "DNS 提供商",
          "doc_link": "查看 DNS 提供商配置指南"
        },
        "dns_env": {
          "label": "环境变量 (API 密钥)",
          "description_short": "每行一个 KEY=VALUE 配置"
        },
        "cert_content": {
          "label": "证书内容 (Public Key)"
        },
        "key_content": {
          "label": "密钥内容 (Private Key)"
        }
      },
      "routing": {
        "outbounds_tab": "自定义 Outbounds",
        "routes_tab": "自定义 Routes",
        "outbounds": "自定义 Outbounds (JSON)",
        "routes": "自定义 Routes (JSON)",
        "error": {
          "must_be_array": "必须是一个 JSON 数组 []",
          "invalid_json": "无效的 JSON 格式"
        }
      },
      "advanced": {
        "trigger_label": "高级设置",
        "dialog_title": "高级协议配置",
        "tls_tab": "TLS",
        "route_tab": "路由",
        "multiplex_tab": "多路复用"
      }
    },
    "network_settings": {
      "edit_protocol": "编辑协议",
      "edit_protocol_config": "编辑协议配置",
      "edit_padding_scheme": "编辑填充方案",
      "use_template": "使用{{template}}模板",
      "json_config_placeholder": "请输入JSON配置",
      "json_config_placeholder_with_template": "请输入JSON配置或选择上方模板",
      "validation": {
        "must_be_array": "配置必须是一个JSON数组",
        "must_be_object": "配置必须是一个JSON对象",
        "invalid_json": "无效的JSON格式"
      },
      "errors": {
        "save_failed": "保存时发生错误"
      }
    },
    "common": {
      "cancel": "取消",
      "confirm": "确定"
    }
  },
  "coupon": {
    "title": "优惠券管理",
    "description": "在这里可以查看优惠券，包括增加、查看、删除等操作。",
    "table": {
      "columns": {
        "id": "ID",
        "show": "启用",
        "name": "卷名称",
        "type": "类型",
        "code": "卷码",
        "limitUse": "剩余次数",
        "limitUseWithUser": "可用次数/用户",
        "validity": "有效期",
        "actions": "操作"
      },
      "validity": {
        "expired": "已过期{{days}}天",
        "notStarted": "{{days}}天后开始",
        "remaining": "剩余{{days}}天",
        "startTime": "开始时间",
        "endTime": "结束时间",
        "unlimited": "无限次",
        "noLimit": "无限制"
      },
      "actions": {
        "edit": "编辑",
        "delete": "删除",
        "deleteConfirm": {
          "title": "确认删除",
          "description": "此操作将永久删除该优惠券，删除后无法恢复。确定要继续吗？",
          "confirmText": "删除"
        }
      },
      "toolbar": {
        "search": "搜索优惠券...",
        "type": "类型",
        "reset": "重置",
        "types": {
          "1": "按金额优惠",
          "2": "按比例优惠"
        }
      }
    },
    "form": {
      "add": "添加优惠券",
      "edit": "编辑优惠券",
      "name": {
        "label": "优惠券名称",
        "placeholder": "请输入优惠券名称",
        "required": "请输入优惠券名称"
      },
      "type": {
        "label": "优惠券类型和值",
        "placeholder": "优惠券类型"
      },
      "value": {
        "placeholder": "请输入值"
      },
      "validity": {
        "label": "优惠券有效期",
        "to": "至",
        "endTimeError": "结束时间必须晚于开始时间"
      },
      "limitUse": {
        "label": "最大使用次数",
        "placeholder": "限制最大使用次数，留空则不限制",
        "description": "设置优惠券的总使用次数限制，留空表示不限制使用次数"
      },
      "limitUseWithUser": {
        "label": "每个用户可使用次数",
        "placeholder": "限制每个用户可使用次数，留空则不限制",
        "description": "限制每个用户可使用该优惠券的次数，留空表示不限制单用户使用次数"
      },
      "limitPeriod": {
        "label": "指定周期",
        "placeholder": "限制指定周期可以使用优惠，留空则不限制",
        "description": "选择可以使用优惠券的订阅周期，留空表示不限制使用周期",
        "empty": "没有找到匹配的周期"
      },
      "limitPlan": {
        "label": "指定订阅",
        "placeholder": "限制指定订阅可以使用优惠，留空则不限制",
        "description": "选择可以使用优惠券的订阅计划，留空表示不限制计划",
        "empty": "没有找到匹配的订阅"
      },
      "code": {
        "label": "自定义优惠码",
        "placeholder": "自定义优惠码，留空则自动生成",
        "description": "可以自定义优惠码，留空则系统自动生成"
      },
      "generateCount": {
        "label": "批量生成数量",
        "placeholder": "批量生成优惠码数量，留空则生成单个",
        "description": "批量生成多个优惠码，留空则只生成单个优惠码"
      },
      "submit": {
        "saving": "保存中...",
        "save": "保存"
      },
      "error": {
        "saveFailed": "保存优惠券失败"
      },
      "timeRange": {
        "quickSet": "快速设置",
        "presets": {
          "1week": "1周",
          "2weeks": "2周",
          "1month": "1个月",
          "3months": "3个月",
          "6months": "6个月",
          "1year": "1年"
        }
      }
    },
    "period": {
      "monthly": "月",
      "quarterly": "季度",
      "half_yearly": "半年",
      "yearly": "年",
      "two_yearly": "两年",
      "three_yearly": "三年",
      "onetime": "一次性",
      "reset_traffic": "重置流量"
    }
  },
  "route": {
    "tabs": {"rules": "路由规则", "blocks": "拦截记录"},
    "title": "路由管理",
    "description": "管理所有路由组，包括添加、删除、编辑等操作。",
    "columns": {
      "id": "组ID",
      "enabled": "启用",
      "remarks": "备注",
      "action": "动作",
      "actions": "操作",
      "matchRules": "匹配{{count}}条规则",
      "portTag": "端口 {{value}}",
      "networkTag": {
        "tcp": "仅 TCP",
        "udp": "仅 UDP"
      },
      "nodes": "{{count}} 个节点",
      "applyToNewNodes": "新增节点默认应用",
      "action_value": {
        "title": "动作值",
        "dns": "DNS: {{value}}",
        "proxy": "转发 ({{value}})",
        "block": "阻止访问",
        "direct": "直连"
      }
    },
    "actions": {
      "dns": "指定DNS服务器进行解析",
      "block": "禁止访问",
      "direct": "直连",
      "proxy": "转发"
    },
    "form": {
      "add": "添加路由",
      "edit": "编辑路由",
      "create": "创建路由",
      "enabled": "启用路由",
      "remarks": "备注",
      "remarksPlaceholder": "请输入备注",
      "match": "匹配值（域名或 IP）",
      "matchPlaceholder": "example.com\n*.example.com",
      "protocol": "协议",
      "protocolAny": "不限",
      "port": "目标端口",
      "portPlaceholder": "25,465,6881-6889",
      "network": "网络类型",
      "networkAny": "TCP 和 UDP",
      "networkTcp": "仅 TCP",
      "networkUdp": "仅 UDP",
      "nodes": "应用节点",
      "nodesPlaceholder": "选择节点",
      "nodesEmpty": "暂无节点",
      "selectAllNodes": "全选",
      "clearNodes": "清空",
      "applyToNewNodes": "新增节点默认应用",
      "action": "动作",
      "actionPlaceholder": "请选择动作",
      "dns": "DNS服务器",
      "dnsPlaceholder": "请输入DNS服务器",
      "proxy": "转发标签 (Outbound Tag)",
      "proxyPlaceholder": "请输入转发标签",
      "cancel": "取消",
      "submit": "提交",
      "validation": {
        "remarks": "请输入有效的备注",
        "condition": "请至少填写一个匹配条件",
        "port": "目标端口“{{value}}”格式不正确，应为 1-65535 的端口或范围"
      }
    },
    "toolbar": {
      "searchPlaceholder": "搜索路由...",
      "reset": "重置"
    },
    "messages": {
      "deleteConfirm": "确认删除",
      "deleteDescription": "此操作将永久删除该路由组，删除后无法恢复。确定要继续吗？",
      "enableRoute": "启用路由：{{name}}",
      "disableRoute": "停用路由：{{name}}",
      "updateFailed": "路由状态保存失败，请重试",
      "deleteButton": "删除",
      "deleteSuccess": "删除成功",
      "createSuccess": "创建成功",
      "updateSuccess": "更新成功"
    }
  },
  "ticket": {
    "title": "工单管理",
    "description": "在这里可以查看用户工单，包括查看、回复、关闭等操作。",
    "columns": {
      "id": "工单号",
      "subject": "主题",
      "level": "优先级",
      "status": "状态",
      "updated_at": "最后更新",
      "created_at": "创建时间",
      "actions": "操作"
    },
    "status": {
      "closed": "已关闭",
      "replied": "已回复",
      "pending": "待回复",
      "processing": "处理中"
    },
    "level": {
      "low": "低优先",
      "medium": "中优先",
      "high": "高优先"
    },
    "filter": {
      "placeholder": "搜索{field}...",
      "no_results": "未找到结果",
      "selected": "已选择 {count} 项",
      "clear": "清除筛选"
    },
    "actions": {
      "view_details": "查看详情",
      "close_ticket": "关闭工单",
      "close_confirm_title": "确认关闭工单",
      "close_confirm_description": "确定要关闭这个工单吗？关闭后会移入已关闭列表，但仍可继续回复。",
      "close_confirm_button": "确认关闭",
      "close_success": "工单已关闭",
      "view_ticket": "查看工单"
    },
    "detail": {
      "no_messages": "暂无消息记录",
      "created_at": "创建于",
      "sender_admin": "管理员",
      "sender_user": "用户",
      "user_info": "用户信息",
      "traffic_records": "流量记录",
      "order_records": "订单记录",
      "input": {
        "closed_reply_placeholder": "工单已关闭，仍可继续回复...",
        "closed_hint": "该工单已关闭，你仍可以继续回复，新的消息会追加到当前工单。",
        "reply_placeholder": "输入回复内容...",
        "sending": "发送中...",
        "send": "发送"
      }
    },
    "list": {
      "title": "工单列表",
      "search_placeholder": "搜索工单标题或用户邮箱",
      "no_tickets": "暂无工单",
      "no_open_tickets": "暂无处理中工单",
      "no_closed_tickets": "暂无已关闭工单",
      "no_search_results": "未找到匹配的工单",
      "collapse": "收起列表",
      "expand": "展开列表"
    }
  },
  "machine": {
    "lite": {
      "binding_pending": "待匹配，每分钟重试",
      "binding_conflict": "IP 匹配冲突，请手动绑定",
      "binding_matched": "已匹配，等待自动绑定",
      "binding_paused": "已暂停自动绑定",
      "resumeAuto": "恢复自动绑定",
      "connect": "接入 Lite",
      "description": "启用后每分钟按公网 IP 自动绑定，冲突可手动选择。",
      "url": "Lite 站点地址",
      "key": "站点 API 密钥",
      "keepKey": "留空保留已保存的密钥",
      "enabled": "启用 Lite",
      "saveRead": "保存并读取",
      "read": "读取服务器",
      "autoBind": "按公网 IP 一键绑定",
      "importSelected": "导入选中（{{count}}）",
      "completed": "已处理 {{count}} 台服务器",
      "refreshFailed": "操作已完成，列表刷新失败，请重新读取。",
      "empty": "Lite 中暂无服务器",
      "select": "选择 {{name}}",
      "boundTo": "已绑定：{{name}}",
      "unbind": "解除绑定",
      "bindTarget": "为 {{name}} 选择服务器",
      "chooseMachine": "选择已有服务器",
      "bind": "绑定",
      "retry": "重试",
      "loading": "读取中",
      "readFailed": "读取失败",
      "historyFailed": "历史数据读取失败",
      "missing": "服务器已不存在",
      "offline": "离线",
      "online": "在线",
      "stale": "数据已过期",
      "unknown": "状态未知",
      "lastReport": "最后上报",
      "traffic": "Lite 流量使用 / 配额",
      "info": "Lite 服务器信息",
      "name": "Lite 名称",
      "country": "国家 / 地区",
      "ip": "公网 IP",
      "os": "操作系统 / 架构",
      "cpu": "处理器",
      "cores": "CPU 核心数",
      "kernel": "内核版本",
      "virtualization": "虚拟化",
      "group": "分组",
      "tags": "标签",
      "bandwidth": "带宽",
      "expires": "到期时间",
      "resetDay": "流量重置日",
      "resetTime": "重置时间 / 时区",
      "nextReset": "下次流量重置",
      "mode": "流量统计方式",
      "remark": "公开备注",
      "noReset": "不自动重置",
      "monthlyDay": "每月 {{day}} 日",
      "mode_up": "仅上传",
      "mode_down": "仅下载",
      "mode_sum": "上传 + 下载",
      "mode_max": "上传和下载取较大值",
      "mode_min": "上传和下载取较小值"
    },
    "traffic": {
      "title": "流量使用 / 总量",
      "limit": "流量上限（GB，0 不限）",
      "resetDay": "每月重置日",
      "mode": "计费方式",
      "outbound": "单向（仅出站）",
      "both": "双向（入站 + 出站）",
      "proxy": "仅计费代理流量",
      "interfaces": "计费网卡",
      "interfacesPlaceholder": "留空自动识别，多个网卡用逗号分隔",
      "unlimitedPlaceholder": "0 为不限",
      "unlimited": "不限",
      "invalidLimit": "请输入 0 至 8388607 之间的流量",
      "invalidMode": "请选择计费方式",
      "invalidDay": "请输入 1 至 31 之间的整数",
      "invalidInterfaces": "请输入有效网卡名称，多个名称用逗号分隔",
      "exceeded": "已达上限",
      "waiting": "等待计量",
      "stale": "计量上报中断",
      "errors": {
        "interfaces_unavailable": "无法识别计费网卡",
        "state_lost": "计量状态丢失，暂停至下个周期",
        "state_write_failed": "计量状态保存失败"
      }
    },
    "agent": {
      "more": "更多操作",
      "confirm": "确认",
      "cancel": "取消",
      "submission": "本次提交",
      "version": "运行版本",
      "publicIp": "公网 IP",
      "operation": "操作状态",
      "upgrade": "升级",
      "restart": "重启",
      "batch_upgrade": "批量更新",
      "batch_restart": "批量重启",
      "upgradeConfirm": "更新选中的 {{count}} 台服务器？",
      "restartConfirm": "重启选中的 {{count}} 台服务器？",
      "interruption": "操作会短暂中断这些服务器上由 yz-agent 管理的节点。更新将使用最新正式版。",
      "selectPage": "选择当前页",
      "selectServer": "选择服务器 {{name}}",
      "clearSelection": "取消选择（{{count}}）",
      "queued": "已提交 {{count}} 台，未提交 {{failed}} 台",
      "inProgress": {
        "upgrade": "升级中",
        "restart": "重启中"
      },
      "results": {
        "updated": "已更新并重启",
        "up_to_date": "已是最新版本",
        "current_newer": "当前版本更高，不自动降级"
      },
      "states": {
        "pending": "等待执行",
        "running": "执行中",
        "succeeded": "成功",
        "failed": "失败",
        "timeout": "超时未确认"
      },
      "errors": {
        "disabled": "服务器已停用",
        "offline": "服务器离线",
        "unsupported": "当前 agent 不支持远程操作",
        "busy": "已有操作执行中",
        "not_found": "服务器不存在",
        "launch_failed": "执行器启动失败",
        "execution_failed": "执行失败",
        "release_query_failed": "查询最新正式版失败，已停止升级",
        "current_version_failed": "读取当前版本失败，已停止升级",
        "current_version_invalid": "无法识别当前版本，已停止升级",
        "latest_version_invalid": "无法识别最新正式版，已停止升级",
        "timeout": "超时未确认，请检查服务状态",
        "request_failed": "提交结果未确认，请刷新后检查"
      }
    },
    "title": "服务器管理",
    "description": "用于查看服务器健康、负载与承载节点，并从运维视角快捷发起节点操作。",
    "columns": {
      "id": "ID",
      "name": "服务器名称",
      "status": "状态",
      "nodes": "节点数",
      "nodesHosted": "已承载节点",
      "nodesIdle": "暂无承载",
      "proxyTraffic": "服务器用量",
      "proxyTrafficTooltip": "原始上传和下载之和，包含直出、前置转发和落地承载；同机中转只计一次，不含其他程序流量。",
      "load": "负载",
      "lastSeen": "最后心跳",
      "actions": "操作",
      "online": "在线",
      "offline": "离线",
      "inactive": "已禁用",
      "noData": "暂无负载数据",
      "cpu": "CPU",
      "memory": "内存",
      "disk": "磁盘",
      "never": "从未上报",
      "lastReport": "负载上报"
    },
    "toolbar": {
      "search": "搜索服务器名称、备注或 SID...",
      "status": "状态",
      "nodes": "节点",
      "with_nodes": "已承载节点",
      "idle_nodes": "空闲服务器",
      "high_load": "高负载",
      "online_ratio": "在线",
      "high_load_count": "高负载",
      "reset": "重置"
    },
    "overview": {
      "total": "服务器总数",
      "total_hint": "共承载 {{count}} 个节点",
      "online": "在线服务器",
      "online_hint": "最近 5 分钟内正常心跳",
      "offline": "离线/失联",
      "offline_hint": "需要检查心跳或节点代理",
      "high_load": "高负载",
      "high_load_hint": "CPU、内存或磁盘接近阈值",
      "nodes_suffix": "节点",
      "attention": "需关注",
      "stable": "稳定",
      "needs_review": "建议检查",
      "normal": "正常"
    },
    "form": {
      "add": "添加服务器",
      "create": "新建服务器",
      "edit": "编辑服务器",
      "createDescription": "当你希望一台服务器承载多个节点时，再创建服务器记录。",
      "editDescription": "修改服务器名称、备注或启用状态。",
      "name": "服务器名称",
      "namePlaceholder": "例如 HK-01",
      "nameError": "请输入服务器名称",
      "notes": "备注",
      "notesPlaceholder": "关于此服务器的可选备注",
      "isActive": "启用服务器",
      "isActiveDescription": "禁用后 xboard-node 将不再使用此服务器。",
      "disableLogs": "隐私保护模式",
      "disableLogsDescription": "开启时加密敏感数据并停用运行日志，关闭后恢复。",
      "cancel": "取消",
      "submit": "提交",
      "update": "更新"
    },
    "token": {
      "title": "服务器 Token",
      "description": "此 Token 用于 xboard-node 向面板认证，请妥善保管。",
      "show": "查看 Token",
      "hide": "隐藏 Token",
      "reset": "重置 Token",
      "resetConfirm": "确认重置 Token？",
      "resetDescription": "旧 Token 将立即失效，xboard-node 需要重新配置新 Token。",
      "copy": "复制",
      "copied": "Token 已复制到剪贴板",
      "copiedInline": "已复制!",
      "copyFailed": "复制失败，请手动复制",
      "autoHide": "{{time}} 后自动隐藏",
      "resetSuccess": "Token 已重置",
      "createdHint": "Token 已生成，后续可在服务器详情页中查看。"
    },
    "install": {
      "title": "安装 xboard-node",
      "description": "在目标服务器上执行此命令，即可用 machine mode 安装 xboard-node 并接入当前服务器记录。",
      "copy": "复制安装命令",
      "copied": "安装命令已复制",
      "copiedInline": "已复制!",
      "copyFailed": "复制失败",
      "loading": "正在生成命令...",
      "hint": "需要 root 或 sudo 权限，且目标服务器需为支持 systemd 的 Linux。"
    },
    "detail": {
      "title": "服务器详情",
      "info": "服务器信息",
      "associatedNodes": "关联节点",
      "noNodes": "暂无绑定节点。",
      "nodeId": "ID",
      "nodeName": "名称",
      "nodeType": "类型",
      "nodeHost": "地址",
      "nodePort": "端口",
      "nodeShow": "可见",
      "nodeEnabled": "已激活",
      "loadTrend": "负载趋势",
      "networkTrend": "网络速率",
      "noHistory": "暂无历史负载数据",
      "openNodeManage": "前往节点管理",
      "addNodeToServer": "新增节点到此服务器",
      "nodeCount": "{{count}} 个节点",
      "nodeEnabledCount": "{{count}} 个已激活",
      "toggleEnabledError": "切换节点状态失败",
      "bindExistingButton": "关联已有节点",
      "bindExistingTitle": "关联已有节点",
      "bindExistingDescription": "选择要关联到「{{name}}」的节点",
      "bindSearchPlaceholder": "搜索节点名称、地址、类型...",
      "noUnboundNodes": "没有未绑定的节点",
      "noSearchResults": "没有匹配的节点",
      "selectAll": "全选（共 {{count}} 个）",
      "selectedCount": "已选 {{count}} 个",
      "bindConfirm": "关联 {{count}} 个节点",
      "binding": "关联中...",
      "bindSuccess": "成功将 {{count}} 个节点关联到「{{name}}」",
      "bindFailed": "关联失败",
      "unbindNode": "取消关联",
      "unbindSuccess": "已取消「{{name}}」的关联",
      "unbindFailed": "取消关联失败",
      "cancel": "取消"
    },
    "messages": {
      "createSuccess": "服务器创建成功",
      "updateSuccess": "服务器更新成功",
      "deleteConfirm": "确认删除服务器？",
      "deleteDescription": "关联节点将自动解绑（不会被删除），此操作不可撤销。",
      "deleteButton": "删除",
      "deleteSuccess": "服务器删除成功",
      "deleteFailed": "删除服务器失败",
      "saveFailed": "保存服务器失败",
      "tokenFetchFailed": "获取令牌失败",
      "tokenResetFailed": "重置令牌失败"
    },
    "nodeForm": {
      "machineId": "绑定服务器",
      "machineIdPlaceholder": "选择一台服务器（可选）",
      "machineIdNone": "独立部署",
      "enabled": "在服务器上激活",
      "enabledDescription": "节点是否在所选服务器上启用运行"
    }
  },
  "search": {
    "placeholder": "搜索菜单和功能...",
    "title": "菜单导航",
    "noResults": "未找到结果",
    "shortcut": {
      "label": "搜索",
      "key": "⌘K"
    }
  },
  "knowledge": {
    "title": "知识库管理",
    "description": "在这里可以配置知识库，包括添加、删除、编辑等操作。",
    "columns": {
      "id": "ID",
      "status": "状态",
      "title": "标题",
      "category": "分类",
      "actions": "操作"
    },
    "form": {
      "add": "添加知识",
      "edit": "编辑知识",
      "title": "标题",
      "titlePlaceholder": "请输入知识标题",
      "category": "分类",
      "categoryPlaceholder": "请输入分类，分类将会自动归类",
      "language": "语言",
      "languagePlaceholder": "请选择语言",
      "content": "内容",
      "show": "显示",
      "cancel": "取消",
      "submit": "提交"
    },
    "languages": {
      "en-US": "English",
      "ja-JP": "日本語",
      "ko-KR": "한국어",
      "vi-VN": "Tiếng Việt",
      "zh-CN": "简体中文",
      "zh-TW": "繁體中文",
      "ru-RU": "Русский"
    },
    "messages": {
      "deleteConfirm": "确认删除",
      "deleteDescription": "此操作将永久删除该知识库记录，删除后无法恢复。确定要继续吗？",
      "deleteButton": "删除",
      "operationSuccess": "操作成功"
    },
    "toolbar": {
      "searchPlaceholder": "搜索知识...",
      "reset": "重置",
      "sortModeHint": "拖拽知识条目进行排序，完成后点击保存",
      "editSort": "编辑排序",
      "saveSort": "保存排序"
    }
  },
  "common": {
    "loading": "加载中...",
    "error": "错误",
    "success": "成功",
    "save": "保存",
    "cancel": "取消",
    "confirm": "确认",
    "close": "关闭",
    "delete": {
      "success": "删除成功",
      "failed": "删除失败"
    },
    "edit": "编辑",
    "view": "查看",
    "toggleNavigation": "切换导航",
    "toggleSidebar": "切换侧边栏",
    "search": "搜索...",
    "theme": {
      "light": "浅色",
      "dark": "深色",
      "system": "跟随系统"
    },
    "user": "用户",
    "defaultEmail": "user@example.com",
    "settings": "设置",
    "logout": "退出登录",
    "copy": {
      "success": "复制成功",
      "failed": "复制失败",
      "error": "复制失败",
      "errorLog": "复制到剪贴板时出错"
    },
    "submit": "提交",
    "saving": "保存中...",
    "table": {
      "noData": "暂无数据",
      "pagination": {
        "selected": "已选择 {{selected}} 项，共 {{total}} 项",
        "itemsPerPage": "每页显示",
        "page": "第",
        "pageOf": "页，共 {{total}} 页",
        "firstPage": "跳转到第一页",
        "previousPage": "上一页",
        "nextPage": "下一页",
        "lastPage": "跳转到最后一页"
      },
      "viewOptions": {
        "button": "显示列",
        "label": "切换显示列"
      }
    },
    "update": {
      "title": "系统更新",
      "newVersion": "发现新版本",
      "currentVersion": "当前版本",
      "latestVersion": "最新版本",
      "updateLater": "稍后更新",
      "updateNow": "立即更新",
      "updating": "更新中...",
      "updateSuccess": "更新成功，系统将在稍后自动重启",
      "updateFailed": "更新失败，请稍后重试"
    },
    "time": {
      "day": "天",
      "hour": "小时"
    },
    "reset": "重置",
    "export": "导出",
    "currency": {
      "yuan": "元"
    },
    "http": {
      "notLoggedIn": "未登录",
      "unknownError": "未知错误",
      "loginExpired": "登录已过期",
      "noPermission": "没有权限",
      "notFound": "资源或接口不存在",
      "unknownException": "未知异常"
    }
  },
  "sidebar": {
    "dashboard": "仪表盘",
    "systemManagement": "系统管理",
    "systemConfig": "系统配置",
    "pluginManagement": "插件管理",
    "themeConfig": "主题配置",
    "noticeManagement": "公告管理",
    "paymentConfig": "支付配置",
    "knowledgeManagement": "知识库管理",
    "nodeManagement": "节点管理",
    "permissionGroupManagement": "权限组管理",
    "routeManagement": "路由管理",
    "subscriptionManagement": "订阅管理",
    "planManagement": "套餐管理",
    "orderManagement": "订单管理",
    "couponManagement": "优惠券管理",
    "userManagement": "用户管理",
    "ticketManagement": "工单管理"
  },
  "plugin": {
    "title": "插件管理",
    "description": "管理和配置系统插件",
    "search": {
      "placeholder": "搜索插件名称或描述..."
    },
    "type": {
      "placeholder": "选择插件类型",
      "all": "全部类型"
    },
    "tabs": {
      "all": "所有插件",
      "installed": "已安装",
      "available": "可用"
    },
    "status": {
      "enabled": "已启用",
      "disabled": "已禁用",
      "not_installed": "未安装",
      "protected": "受保护",
      "filter_placeholder": "安装状态",
      "all": "全部状态",
      "installed": "已安装",
      "available": "可安装"
    },
    "button": {
      "install": "安装",
      "upgrade": "升级",
      "config": "配置",
      "enable": "启用",
      "disable": "禁用",
      "uninstall": "卸载",
      "readme": "查看文档",
      "menuDemo": "菜单演示"
    },
    "upload": {
      "button": "上传插件",
      "title": "上传插件",
      "description": "上传插件包 (.zip)",
      "dragText": "拖拽插件包到此处，或",
      "clickText": "浏览",
      "supportText": "仅支持 .zip 格式文件",
      "uploading": "上传中...",
      "error": {
        "format": "仅支持 .zip 格式文件"
      }
    },
    "delete": {
      "title": "删除插件",
      "description": "确定要删除此插件吗？此操作无法撤销。",
      "button": "删除"
    },
    "uninstall": {
      "title": "卸载插件",
      "description": "确定要卸载此插件吗？卸载后插件数据将被清除。",
      "button": "卸载"
    },
    "upgrade": {
      "title": "升级插件",
      "description": "确定要升级此插件吗？升级过程中插件将暂时不可用。",
      "button": "升级"
    },
    "config": {
      "title": "配置",
      "description": "修改插件配置",
      "save": "保存",
      "cancel": "取消"
    },
    "readme": {
      "title": "插件文档"
    },
    "author": "作者",
    "messages": {
      "installSuccess": "插件安装成功",
      "installError": "插件安装失败",
      "upgradeSuccess": "插件升级成功",
      "upgradeError": "插件升级失败",
      "uninstallSuccess": "插件卸载成功",
      "uninstallError": "插件卸载失败",
      "enableSuccess": "插件启用成功",
      "enableError": "插件启用失败",
      "disableSuccess": "插件禁用成功",
      "disableError": "插件禁用失败",
      "configLoadError": "加载插件配置失败",
      "configSaveSuccess": "配置保存成功",
      "configSaveError": "配置保存失败",
      "uploadSuccess": "插件上传成功",
      "uploadError": "插件上传失败",
      "deleteSuccess": "插件删除成功",
      "deleteError": "插件删除失败"
    }
  },
  "dashboard": {
    "title": "仪表盘",
    "stats": {
      "newUsers": "新用户",
      "totalScore": "总积分",
      "monthlyUpload": "月上传",
      "vsLastMonth": "对比上月",
      "vsYesterday": "对比昨日",
      "todayIncome": "今日收入",
      "monthlyIncome": "月收入",
      "totalIncome": "总收入",
      "totalUsers": "总用户",
      "activeUsers": "活跃用户: {{count}}",
      "totalOrders": "总订单",
      "revenue": "收入",
      "todayRegistered": "今日注册",
      "monthlyRegistered": "月注册",
      "onlineUsers": "在线用户",
      "pendingTickets": "待处理工单",
      "hasPendingTickets": "有工单需要处理",
      "noPendingTickets": "无待处理工单",
      "pendingCommission": "待处理佣金",
      "hasPendingCommission": "有佣金需要确认",
      "noPendingCommission": "无待处理佣金",
      "monthlyNewUsers": "月新增用户",
      "monthlyDownload": "月下载",
      "todayTraffic": "今日: {{value}}",
      "activeUserTrend": "活跃用户趋势",
      "realtimeUsers": "实时用户",
      "todayPeak": "今日峰值",
      "vsLastWeek": "对比上周"
    },
    "trafficRank": {
      "nodeTrafficRank": "节点流量排行",
      "userTrafficRank": "用户流量排行",
      "today": "今天",
      "last7days": "最近7天",
      "last30days": "最近30天",
      "customRange": "自定义范围",
      "selectTimeRange": "选择时间范围",
      "selectDateRange": "选择日期范围",
      "currentTraffic": "当前流量",
      "previousTraffic": "上期流量",
      "changeRate": "变化率",
      "recordTime": "记录时间"
    },
    "overview": {
      "title": "收入概览",
      "thisMonth": "本月",
      "lastMonth": "上月",
      "to": "至",
      "selectTimeRange": "选择范围",
      "selectDate": "选择日期",
      "last7Days": "最近7天",
      "last30Days": "最近30天",
      "last90Days": "最近90天",
      "last180Days": "最近180天",
      "lastYear": "最近一年",
      "customRange": "自定义范围",
      "amount": "金额",
      "count": "数量",
      "transactions": "{{count}} 笔交易",
      "orderAmount": "订单金额",
      "commissionAmount": "佣金金额",
      "orderCount": "订单数量",
      "commissionCount": "佣金数量",
      "totalIncome": "总收入",
      "totalCommission": "总佣金",
      "totalTransactions": "共 {{count}} 笔交易",
      "avgOrderAmount": "平均订单金额:",
      "commissionRate": "佣金比例:"
    },
    "queue": {
      "title": "队列状态",
      "jobDetails": "作业详情",
      "status": {
        "description": "当前队列运行状态",
        "running": "运行状态",
        "normal": "正常",
        "abnormal": "异常",
        "waitTime": "当前等待时间：{{seconds}} 秒",
        "pending": "等待中",
        "processing": "处理中",
        "completed": "已完成",
        "failed": "失败",
        "cancelled": "已取消"
      },
      "details": {
        "description": "队列处理详细信息",
        "recentJobs": "近期任务数",
        "statisticsPeriod": "统计时间范围：{{hours}} 小时",
        "jobsPerMinute": "每分钟处理量",
        "maxThroughput": "最高吞吐量：{{value}}",
        "failedJobs7Days": "7日报错数量",
        "retentionPeriod": "保留 {{hours}} 小时",
        "longestRunningQueue": "最长运行队列",
        "activeProcesses": "活跃进程",
        "id": "作业ID",
        "type": "作业类型",
        "status": "状态",
        "progress": "进度",
        "createdAt": "创建时间",
        "updatedAt": "更新时间",
        "error": "错误信息",
        "data": "作业数据",
        "result": "结果",
        "duration": "耗时",
        "attempts": "重试次数",
        "nextRetry": "下次重试",
        "failedJobsDetailTitle": "失败任务详情",
        "viewFailedJobs": "查看报错详情",
        "jobDetailTitle": "任务详细信息",
        "time": "时间",
        "queue": "队列",
        "name": "任务名称",
        "exception": "异常信息",
        "noFailedJobs": "暂无失败任务",
        "connection": "连接类型",
        "payload": "任务数据",
        "viewDetail": "查看详情",
        "action": "操作"
      },
      "actions": {
        "retry": "重试",
        "cancel": "取消",
        "delete": "删除",
        "viewDetails": "查看详情"
      },
      "empty": "队列中暂无作业",
      "loading": "正在加载队列状态...",
      "error": "加载队列状态失败"
    },
    "common": {
      "refresh": "刷新",
      "close": "关闭",
      "pagination": "第 {{current}}/{{total}} 页，共 {{count}} 条"
    }
  },
  "order": {
    "title": "订单管理",
    "description": "在这里可以查看用户订单，包括分配、查看、删除等操作。",
    "table": {
      "columns": {
        "tradeNo": "订单号",
        "type": "类型",
        "plan": "订阅计划",
        "period": "周期",
        "amount": "支付金额",
        "status": "订单状态",
        "commission": "佣金金额",
        "commissionStatus": "佣金状态",
        "createdAt": "创建时间"
      }
    },
    "type": {
      "NEW": "新购",
      "RENEWAL": "续费",
      "UPGRADE": "升级",
      "RESET_FLOW": "流量重置"
    },
    "period": {
      "month_price": "月付",
      "quarter_price": "季付",
      "half_year_price": "半年付",
      "year_price": "年付",
      "two_year_price": "两年付",
      "three_year_price": "三年付",
      "onetime_price": "一次性",
      "reset_price": "流量重置包"
    },
    "status": {
      "PENDING": "待支付",
      "PROCESSING": "开通中",
      "CANCELLED": "已取消",
      "COMPLETED": "已完成",
      "DISCOUNTED": "已折抵",
      "tooltip": "标记为[已支付]后将会由系统进行开通后并完成"
    },
    "commission": {
      "PENDING": "待确认",
      "PROCESSING": "发放中",
      "VALID": "有效",
      "INVALID": "无效"
    },
    "actions": {
      "markAsPaid": "标记为已支付",
      "cancel": "取消订单",
      "openMenu": "打开菜单",
      "reset": "重置"
    },
    "search": {
      "placeholder": "搜索订单..."
    },
    "dialog": {
      "title": "订单信息",
      "basicInfo": "基本信息",
      "amountInfo": "金额信息",
      "timeInfo": "时间信息",
      "commissionInfo": "佣金信息",
      "commissionStatusActive": "有效",
      "addOrder": "添加订单",
      "assignOrder": "订单分配",
      "fields": {
        "userEmail": "用户邮箱",
        "userPhone": "用户手机号",
        "orderPeriod": "订单周期",
        "subscriptionPlan": "订阅计划",
        "callbackNo": "回调单号",
        "paymentAmount": "支付金额",
        "balancePayment": "余额支付",
        "discountAmount": "优惠金额",
        "refundAmount": "退回金额",
        "deductionAmount": "折抵金额",
        "createdAt": "创建时间",
        "updatedAt": "更新时间",
        "commissionStatus": "佣金状态",
        "commissionAmount": "佣金金额",
        "actualCommissionAmount": "实际佣金",
        "inviteUser": "邀请人",
        "inviteUserId": "邀请人ID"
      },
      "placeholders": {
        "email": "请输入用户邮箱",
        "plan": "请选择订阅计划",
        "period": "请选择购买时长",
        "amount": "请输入需要支付的金额"
      },
      "actions": {
        "cancel": "取消",
        "confirm": "确定"
      },
      "messages": {
        "addSuccess": "添加成功"
      }
    }
  },
  "theme": {
    "title": "主题配置",
    "description": "主题配置，包括主题色、字体大小等。如果你采用前后分离的方式部署V2board，那么主题配置将不会生效。",
    "upload": {
      "button": "上传主题",
      "title": "上传主题",
      "description": "请上传一个有效的主题压缩包（.zip 格式）。主题包应包含完整的主题文件结构。",
      "dragText": "将主题文件拖放到此处，或者",
      "clickText": "点击选择",
      "supportText": "支持 .zip 格式的主题包",
      "uploading": "正在上传...",
      "error": {
        "format": "只支持上传 ZIP 格式的主题文件"
      }
    },
    "preview": {
      "title": "主题预览",
      "imageCount": "{{current}} / {{total}}"
    },
    "card": {
      "version": "版本: {{version}}",
      "currentTheme": "当前主题",
      "activateTheme": "激活主题",
      "configureTheme": "主题设置",
      "preview": "预览",
      "delete": {
        "title": "删除主题",
        "description": "确定要删除该主题吗？删除后无法恢复。",
        "button": "删除",
        "error": {
          "active": "不能删除当前使用的主题"
        }
      }
    },
    "config": {
      "title": "配置{{name}}主题",
      "description": "修改主题的样式、布局和其他显示选项。",
      "cancel": "取消",
      "save": "保存",
      "success": "保存成功"
    }
  }
};

window.XBOARD_TRANSLATIONS = window.XBOARD_TRANSLATIONS || {};
window.XBOARD_TRANSLATIONS['ru-RU'] = {
  "ddns": {
    "selfHosted": "Собственный сервер",
    "serverId": "ID сервера",
    "apiUrl": "Адрес API PowerDNS",
    "provider": "Провайдер DNS",
    "ttl": "DNS TTL (секунды)",
    "followUserStatus": "Учитывать статус пользователя",
    "personalEnabled": "Отдельный домен пользователя",
    "expected": "Ожидаемое использование",
    "title": "Настройки DDNS",
    "enabled": "Включить DDNS",
    "preset": "Настройка домена",
    "prefix": "Префикс узла",
    "choose": "Выберите",
    "manualIp": "IP для подключения к шлюзу",
    "baseDomain": "Базовый домен",
    "inherited": "Настройки домена выбранного входного узла",
    "synced": "Синхронизировано",
    "pending": "Подготовка",
    "error": "Ошибка синхронизации",
    "name": "Название",
    "domain": "Разрешённый домен",
    "zoneId": "Zone ID",
    "token": "API Token",
    "keepToken": "Оставьте пустым для сохранения текущих данных",
    "addPreset": "Добавить домен",
    "save": "Сохранить",
    "cancel": "Отмена",
    "edit": "Изменить",
    "delete": "Удалить",
    "deleteConfirm": "Удалить настройку домена? Используемые настройки удалить нельзя.",
    "refresh": "Обновить",
    "failed": "Ошибка операции. Повторите попытку.",
    "loading": "Загрузка",
    "capacity": "Записей / квота",
    "accountQuota": "Квота аккаунта",
    "unchecked": "Не проверено",
    "check": "Проверить DNS",
    "actions": "Действия",
    "bindings": "Домены узлов",
    "node": "Узел или пул",
    "records": "Управляемые записи",
    "status": "Состояние",
    "deletedNode": "Удалённый узел",
    "cleaning": "Очистка",
    "retained": "Старые записи сохранены",
    "sync": "Синхронизировать",
    "cleanup": "Удалить записи",
    "cleanupConfirm": "После удаления старые домены перестанут работать. Продолжить?"
  },
  "balancer": {
    "dynamicLoad": "Динамическое распределение",
    "bandwidthThreshold": "Порог загрузки канала (%)",
    "connectionThreshold": "Порог активных соединений",
    "loadConfirm": "Время подтверждения (сек.)",
    "loadCooldown": "Пауза между назначениями (сек.)",
    "carrierRouting": "DNS по оператору",
    "carrierLines": "Маршруты операторов",
    "availableBandwidth": "Доступный канал (Мбит/с)",
    "useConnections": "Пусто: по соединениям",
    "carrierNotReady": "Авторитетные DNS ещё не настроены для операторов",
    "carrierDataUnavailable": "Данные IP операторов недоступны или устарели",
    "bandwidthLoad": "Загрузка канала {{value}}%",
    "connectionLoad": "Активных соединений: {{value}}",
    "loadUnavailable": "Нет данных нагрузки; назначения сохранены",
    "linkStates": "Состояние цепочек выходов",
    "dynamicLoadRule": "При одинаковом приоритете используется сглаженная нагрузка. Без полосы — число соединений. Переназначение после устойчивой перегрузки; без данных назначения сохраняются.",
    "carriers": {"default": "По умолчанию", "telecom": "China Telecom", "unicom": "China Unicom", "mobile": "China Mobile"},
    "trafficLite": "Трафик Lite",
    "trafficLocal": "Локальный трафик",
    "trafficUnavailable": "Данные недоступны",
    "trafficUnlimited": "Безлимитный трафик",
    "trafficRemaining": "Осталось {{percent}}%",
    "quotaLow": "Мало оставшегося трафика",
    "scheduling": "Автоматический выбор",
    "healthCheck": "Проверка состояния цепочки",
    "quotaScheduling": "Выбор по оставшемуся трафику",
    "selectionStrategy": "Выбор входного узла",
    "manualPriority": "По весу в пределах приоритета",
    "lowestLatency": "Один узел с минимальной задержкой",
    "quotaPercent": "Порог остатка трафика (%)",
    "latencyTarget": "Выходной узел для проверки",
    "bindLatencyTarget": "Сначала привяжите TCP-выходной узел к этому пулу.",
    "landings": "Резервирование выходов",
    "events": "История переключений",
    "createLandingPool": "Создать пул выходов",
    "editLandingPool": "Изменить пул выходов",
    "subscriptionLine": "Линия подписки",
    "landingPoolHelp": "Линия подписки сохраняется. Выбирается первый доступный выход; после стабильного восстановления используется основной.",
    "primaryLanding": "Основной",
    "backupLanding": "Резерв {{index}}",
    "moveUp": "Выше",
    "moveDown": "Ниже",
    "searchLandings": "Поиск выхода по имени или IP",
    "activeLanding": "Текущий выход",
    "noActiveLanding": "Нет доступных выходов",
    "deleteLandingPoolHelp": "Удалить резервирование и вернуть исходный выход? Узлы сохраняются.",
    "noLandingPools": "Нет пулов выходов",
    "eventTime": "Время",
    "eventReason": "Причина",
    "previousSelection": "До",
    "currentSelection": "После",
    "noAvailableMembers": "Нет доступных участников",
    "noEvents": "Нет переключений",
    "reason": {
      "link_failed": "Сбой цепочки",
      "probe_stale": "Проверка устарела",
      "healthy": "Доступен",
      "offline": "Недоступен или лимит трафика",
      "disabled": "Отключён",
      "incompatible": "Несовместимые параметры",
      "no_address": "Нет адреса",
      "port_failed": "Порт недоступен",
      "probe_pending": "Ожидание проверки",
      "latency_failed": "Цель проверки недоступна",
      "agent_required": "Требуется обновление Agent",
      "heartbeat_only": "По состоянию узла"
    },
    "event": {
      "selection_changed": "Изменились входные узлы",
      "landing_changed": "Выход переключён",
      "dns_failed": "Ошибка синхронизации DNS",
      "dns_recovered": "Синхронизация DNS восстановлена"
    },
    "dnsPriorityRule": "Меньшее число означает больший приоритет. Пользователи стабильно распределяются по весу между доступными узлами.",
    "dnsMode": "Распределение DNS",
    "serverId": "ID сервера",
    "apiUrl": "Адрес API PowerDNS",
    "provider": "Провайдер DNS",
    "endpoint": "Адрес подключения",
    "poolSwitch": "Включить {{name}}",
    "advanced": "Дополнительно",
    "title": "Распределение входных узлов",
    "pools": "Пулы узлов",
    "presets": "Настройки DNS",
    "createPool": "Создать пул",
    "editPool": "Изменить пул",
    "createPreset": "Добавить настройки DNS",
    "editPreset": "Изменить настройки DNS",
    "name": "Название",
    "domain": "Входной домен",
    "baseDomain": "Зона PowerDNS / домен CF",
    "dnsPreset": "Настройки DNS",
    "chooseDnsPreset": "Выберите настройки DNS",
    "members": "Входные узлы",
    "realitySyncEnabled": "Автоматически унифицировать Reality",
    "realitySyncRule": "При сохранении настройки применяются ко всем входным узлам пула. Прямые подписки со старыми параметрами потребуется обновить.",
    "realityServerName": "Домен рукопожатия Reality",
    "realityServerPort": "Порт рукопожатия Reality",
    "realityPrivateKey": "Закрытый ключ Reality",
    "realityPublicKey": "Открытый ключ Reality",
    "realityShortId": "Короткий ID Reality",
    "realityKeepPrivateKey": "Оставьте пустым, чтобы сохранить текущий ключ",
    "realityDerivedPublicKey": "Вычисляется из закрытого ключа при сохранении",
    "realityGenerate": "Создать ключи и короткий ID",
    "realityGenerateFailed": "Не удалось создать ключи Reality. Повторите попытку.",
    "syncReality": "Синхронизировать с входными узлами",
    "priority": "Приоритет",
    "selectFirst": "Первый узел определяет протокол и публичный порт",
    "protocol": "Протокол",
    "state": "Состояние",
    "actions": "Действия",
    "enabled": "Включено",
    "disabled": "Отключено",
    "online": "В сети",
    "offline": "Не в сети",
    "choose": "Выберите",
    "save": "Сохранить",
    "saving": "Сохранение",
    "cancel": "Отмена",
    "edit": "Изменить",
    "delete": "Удалить",
    "refresh": "Обновить",
    "retry": "Повторить",
    "loading": "Загрузка",
    "syncDns": "Обновить DNS",
    "failed": "Ошибка запроса. Повторите попытку.",
    "confirmDelete": "Удалить? Используемые профили и пулы удалить нельзя.",
    "noPools": "Нет пулов",
    "noPresets": "Нет настроек DNS",
    "noMembers": "Нет доступных узлов VLESS Reality TCP",
    "keepToken": "Оставьте пустым, чтобы сохранить токен",
    "poolOption": "Пул: {{name}}",
    "poolReadFailed": "Не удалось загрузить пулы. Повторите попытку.",
    "searchNodes": "Поиск по имени или IP",
    "noSearchResults": "Узлы не найдены",
    "compatibility": {
      "machine": "Сервер не назначен",
      "parent": "Выберите родительский узел, запускающий сервис",
      "entry": "Выберите независимый входной узел",
      "protocol": "Требуется VLESS Reality",
      "tls": "Требуется режим TLS Reality",
      "network": "Требуется транспорт TCP",
      "settings": "Настройки входа неполны или не поддерживаются ядром",
      "invalidPort": "Публичный порт должен быть одним числом от 1 до 65535",
      "missingPublicKey": "Отсутствует публичный ключ Reality",
      "missingServerName": "Отсутствует домен рукопожатия Reality",
      "port": "Публичный порт отличается от первого узла",
      "public_key": "Публичный ключ Reality отличается от первого узла",
      "short_id": "Короткий ID Reality отличается от первого узла",
      "server_name": "Домен рукопожатия Reality отличается от первого узла",
      "server_port": "Порт рукопожатия Reality отличается от первого узла",
      "flow": "Поток VLESS отличается от первого узла",
      "encryptionEnabled": "Режим VLESS Encryption отличается от первого узла",
      "encryption": "Шифрование клиента VLESS отличается от первого узла",
      "decryption": "Дешифрование сервера VLESS отличается от первого узла",
      "sameMachine": "Выберите один входной узел на сервер",
      "sameHost": "Адреса участников должны различаться"
    },
    "latencyBalanced": "Распределение между быстрыми узлами",
    "cyclePriority": "Ближайший сброс лимита трафика",
    "weight": "Вес",
    "assignedUsers": "Назначено пользователей: {{count}}",
    "resetDate": "Сброс лимита"
  },
  "logs": {
    "blockUsers": "По пользователям",
    "blockCount": "Блокировок",
    "lastBlocked": "Последняя блокировка",
    "blockDetails": "Подробнее",
    "backToUsers": "К пользователям",
    "actions": "Действия",

    "blockRetention": "Срок хранения",
    "block": "Блокировки маршрутов",
    "rule": "Правило",
    "ruleFilter": "Название или ID правила",
    "target": "Домен / IP назначения",
    "port": "Порт назначения",
    "network": "Сеть",
    "unknownUser": "Неизвестный пользователь",

    "settings": {
      "title": "Настройки журналов",
      "description": "Выберите журналы для записи в панели и срок их хранения.",
      "modules": { "system": "Системные журналы панели", "audit": "Действия администраторов", "agent": "Журналы агента", "user": "Журналы пользователей", "access": "Записи прокси-доступа" },
      "enabled": "Запись", "disabled": "Выключено", "retention": "Хранить", "days": "дней",
      "daysLabel": "{{module}}: срок хранения",
      "expiry": "Срок хранения — от 1 до 365 дней. Устаревшие записи удаляются автоматически, даже если запись отключена. Сокращение срока безвозвратно удаляет старые записи. Локальные журналы агента управляются настройками машины.",
      "invalidDays": "Введите целое число от 1 до 365.", "loadFailed": "Не удалось загрузить настройки. Повторите попытку.",
      "saveFailed": "Не удалось сохранить настройки. Повторите попытку.", "save": "Сохранить настройки", "saving": "Сохранение…", "saved": "Сохранено"
    },
    "userName": "Пользователь",
    "userFilter": "Почта или номер пользователя",
    "navigation": "Журналы",
    "system": "Системный журнал",
    "agent": "Журнал Agent",
    "user": "Журнал пользователей",
    "time": "Время",
    "machine": "Сервер",
    "node": "Узел",
    "machine_id": "Номер сервера",
    "node_id": "Номер узла",
    "allNodes": "Все узлы",
    "loadingNodes": "Загрузка узлов",
    "nodesLoadFailed": "Не удалось загрузить узлы. Повторите попытку или введите номер узла.",
    "source": "Источник",
    "level": "Уровень",
    "message": "Сообщение",
    "ip": "IP источника",
    "event": "Событие",
    "result": "Результат",
    "count": "Количество",
    "limit": "Лимит на тот момент",
    "keyword": "Поиск в журнале",
    "start_at": "Начало",
    "end_at": "Окончание",
    "date": "Дата",
    "all": "Все",
    "refresh": "Обновить",
    "search": "Найти",
    "clear": "Сбросить фильтры",
    "retry": "Повторить",
    "loading": "Загрузка журнала",
    "empty": "Нет подходящих записей",
    "loadFailed": "Не удалось загрузить журнал. Повторите попытку.",
    "limited": "Для выбранной даты показаны записи из последних 2 МБ каждого файла.",
    "seconds": "{{count}} сек.",
    "sources": {
      "panel": "Работа панели",
      "audit": "Действия администратора",
      "agent": "Agent",
      "xray": "Xray",
      "singbox": "sing-box"
    },
    "levels": {
      "debug": "Отладка",
      "info": "Информация",
      "warn": "Предупреждение",
      "error": "Ошибка",
      "fatal": "Критическая ошибка"
    },
    "events": {
      "login": "Вход",
      "password_change": "Изменение пароля",
      "password_reset": "Сброс пароля",
      "connection_limit": "Лимит соединений",
      "connection_rate": "Лимит новых соединений",
      "device_limit": "Лимит устройств",
      "speed_limit": "Ограничение скорости"
    },
    "results": {
      "success": "Успешно",
      "wrong_password": "Неверный пароль",
      "wrong_code": "Неверный код",
      "banned": "Учётная запись отключена",
      "rate_limited": "Вход ограничен",
      "rejected": "Отклонено",
      "throttled": "Ожидание скорости"
    }
  },
  "database": {
    "title": "База данных",
    "refresh": "Обновить",
    "loading": "Загрузка размеров базы данных…",
    "loadFailed": "Не удалось загрузить размеры базы данных. Повторите попытку.",
    "retry": "Повторить",
    "databaseSize": "Основной файл базы",
    "allocatedSize": "Таблицы и индексы",
    "tableCount": "Таблицы",
    "databaseType": "Тип базы данных",
    "reusableSize": "Свободное место внутри базы",
    "tables": "Размер таблиц",
    "search": "Поиск таблиц",
    "sort": "Сортировка",
    "sortSize": "По размеру",
    "sortName": "По имени таблицы",
    "sortRows": "По оценке числа строк",
    "tableName": "Таблица",
    "usage": "Всего",
    "dataSize": "Данные",
    "indexSize": "Индексы",
    "estimatedRows": "Оценка числа строк",
    "empty": "Таблицы не найдены",
    "sqliteSizeNote": "Показаны страницы основного файла без журнала записи. Оценка числа строк в SQLite недоступна.",
    "sqliteUnavailable": "Эта сборка SQLite не предоставляет размеры таблиц. Общий размер и очистка истории доступны.",
    "cleanup": "Очистка истории",
    "preview": "Посмотреть записи для очистки",
    "preparing": "Поиск записей…",
    "unavailable": "Таблица недоступна",
    "completed": "Удалено записей за этот запуск: {{count}}",
    "deletedRows": "Удалено: {{count}}",
    "moreRemaining": "Остались устаревшие записи. Просмотрите их снова для продолжения очистки.",
    "confirmTitle": "Подтверждение очистки истории",
    "confirmNote": "Устаревших записей: {{count}}. За один запуск удаляется до {{limit}} в каждой категории.",
    "eligible": "Устаревших записей: {{count}}",
    "before": "Удалить записи до {{time}}",
    "irreversible": "Удаление необратимо. Убедитесь в наличии нужной резервной копии. Результаты запроса действуют 10 минут.",
    "cancel": "Отмена",
    "confirm": "Подтвердить очистку",
    "cleaning": "Очистка…",
    "requestFailed": "Ошибка операции. Повторите попытку.",
    "targets": {
      "access": {
        "name": "Записи доступа",
        "retention": "Хранить последние 7 дней"
      },
      "machine": {
        "name": "История мониторинга серверов",
        "retention": "Хранить последние 24 часа"
      },
      "audit": {
        "name": "Журнал действий администраторов",
        "retention": "Хранить последние 3 месяца"
      },
      "telegram": {
        "name": "Дедупликация сообщений Telegram",
        "retention": "Хранить последние 7 дней; привязки аккаунтов сохраняются"
      }
    },
    "unknownTable": "Описание отсутствует",
    "tableDescriptions": {
      "v2_user_event_log": "Вход, пароль и ограничения пользователей",
      "v2_agent_log": "Журнал Agent и ядра",
      "v2_node_report_batch": "Пакеты отчётов узлов и защита от повторного учёта трафика",
      "v2_proxy_access_log": "Записи доступа",
      "v2_stat_route_minute": "Поминутный трафик маршрутов пользователей",
      "v2_stat_route_hour": "Почасовой трафик маршрутов пользователей",
      "v2_stat_proxy_traffic": "Трафик прокси узлов и серверов",
      "v2_admin_audit_log": "Журнал действий администраторов",
      "v2_server_machine_load_history": "История мониторинга серверов",
      "v2_stat_user_route_source": "Источники маршрутов и оплачиваемый трафик пользователей",
      "failed_jobs": "Ошибки заданий очереди",
      "v2_stat_user_server": "Трафик пользователей по узлам",
      "v2_inbound_ip": "Кэш местоположения и свойств входящих IP",
      "v2_stat_server": "Суточный трафик узлов",
      "v2_stat_user": "Суточный трафик пользователей",
      "v2_stat_user_inbound_ip": "Использование входящих IP пользователями",
      "v2_subscription_hub_sources": "Источники агрегации подписок",
      "v2_mail_log": "История отправки почты",
      "v2_subscribe_templates": "Шаблоны конфигурации подписок",
      "v2_subscription_stat": "Сводная статистика запросов подписок",
      "v2_server": "Настройки узлов прокси",
      "personal_access_tokens": "Токены доступа к API",
      "v2_order": "Заказы пользователей",
      "v2_gift_card_code": "Коды активации подарочных карт",
      "v2_gift_card_usage": "Использование подарочных карт",
      "v2_subscription_hub_chain_rules": "Правила цепочек агрегации подписок",
      "v2_user": "Учётные записи и тарифы пользователей",
      "v2_subscription_block": "Время отдельных запросов подписок",
      "v2_telegram_node_incidents": "Защита от повторных уведомлений Telegram о сбоях узлов",
      "v2_server_machine": "Настройки и текущее состояние серверов",
      "v2_subscription_batch": "Защита от повторного учёта пакетов статистики подписок",
      "v2_telegram_admin_notifications": "Уведомления администраторов в Telegram",
      "v2_telegram_business_notifications": "Уведомления об операциях в Telegram",
      "v2_traffic_reset_logs": "История сброса трафика пользователей",
      "v2_commission_log": "История комиссий",
      "v2_gift_card_template": "Шаблоны подарочных карт",
      "v2_plugins": "Настройки и состояние плагинов",
      "v2_server_route": "Правила маршрутизации узлов",
      "v2_settings": "Настройки панели",
      "v2_subscription_restrictions": "Ограничения клиентов подписок",
      "v2_telegram_bot_bindings": "Привязки аккаунтов Telegram",
      "v2_telegram_bot_reminders": "Напоминания Telegram о сроках и трафике",
      "v2_telegram_bot_updates": "Дедупликация сообщений Telegram",
      "v2_ticket": "Обращения пользователей",
      "v2_mail_templates": "Шаблоны писем",
      "v2_notice": "Объявления панели",
      "v2_plan": "Тарифы и цены",
      "v2_server_group": "Группы доступа к узлам",
      "v2_stat": "Статистика заказов, комиссий и регистраций",
      "v2_stat_server_name": "История названий узлов",
      "migrations": "История миграций базы данных",
      "v2_coupon": "Настройки купонов",
      "v2_invite_code": "Пригласительные коды пользователей",
      "v2_knowledge": "Статьи базы знаний",
      "v2_log": "Системные журналы старой версии",
      "v2_payment": "Настройки платёжных каналов",
      "v2_telegram_bot_configs": "Настройки бота Telegram",
      "v2_telegram_node_states": "Состояние узлов для Telegram",
      "v2_ticket_message": "Сообщения обращений",
      "v2_server_hysteria": "Узлы Hysteria старой версии",
      "v2_server_shadowsocks": "Узлы Shadowsocks старой версии",
      "v2_server_trojan": "Узлы Trojan старой версии",
      "v2_server_vless": "Узлы VLESS старой версии",
      "v2_server_vmess": "Узлы VMess старой версии",
      "v2_server_log": "Журналы узлов старой версии",
      "v2_server_stat": "Статистика узлов старой версии",
      "v2_stat_traffic_hour": "Почасовой трафик пользователей старой версии",
      "v2_stat_node_hour": "Почасовые итоги трафика узлов старой версии",
      "v2_stat_node_hour_detail": "Почасовой трафик отдельных узлов старой версии",
      "v2_stat_node_minute_detail": "Поминутный трафик отдельных узлов старой версии"
    }
  },
  "statistics": {
    "subscription": { "title": "Статистика подписок", "users": "Подписки по пользователям", "last90": "Последние 90 дней", "client": "Клиент и версия", "clients": "Клиенты", "requests": "Запросы", "results": "Успешно / Ошибки", "resultCounts": "{{success}} / {{failure}}", "first": "Первый запрос", "last": "Последний запрос", "time": "Время запроса", "status": "Статус ответа", "format": "Формат подписки", "date": "Дата", "daily": "По дням", "recent": "Запросы (7 дней)", "history": "Записи", "historyType": "Тип записей", "back": "К пользователям", "close": "Свернуть записи", "refresh": "Обновить", "searchUser": "Почта или ID пользователя", "searchClient": "Поиск клиента" },
    "accessBack": "Назад",
    "accessLogs": "Журнал подключений", "destination": "Домен / IP", "targetPort": "Порт назначения", "connectedAt": "Время подключения",
    "accessUsers": "Подключения по пользователям", "accessCount": "Подключения", "lastAccess": "Последнее подключение", "accessSort": "Сортировка", "accessSortCount": "По числу подключений", "accessSortTime": "По времени подключения",
    "refreshRecords": "Обновить", "nodeSearchPlaceholder": "Имя или ID узла", "targetSearchPlaceholder": "Домен или IP целиком или частично",
    "lastYear": "Последний год", "dailyHeatmap": "Расход по дням", "trafficIntensity": "Интенсивность расхода", "less": "Меньше", "more": "Больше",
    "noRecord": "Нет данных", "wholeDays": "Для дат старше 30 дней доступны только суточные итоги. Выберите полные дни.",
    "nodeUsage": "Использование узлов",
    "machineStatistics": "Использование серверов",
    "machine": "Сервер",
    "machineName": "Имя сервера",
    "searchMachine": "Поиск серверов",
    "machineRank": "Рейтинг расхода серверов",
    "operator": "Оператор",
    "ipProperties": {
      "fraudScore": "Оценка риска мошенничества",
      "asDomain": "Домен AS",
      "connectionType": "Тип подключения",
      "mobileBrand": "Бренд мобильного оператора",
      "district": "Район",
      "connections": {"DIAL": "Коммутируемый доступ", "DSL": "Широкополосная / кабельная / оптоволоконная / мобильная сеть", "COMP": "Корпоративная сеть", "T1": "Дата-центр / транзит", "SAT": "Спутниковая сеть"},
      "title": "Свойства IP",
      "view": "Свойства IP {ip}",
      "close": "Закрыть свойства IP",
      "networkType": "Тип сети",
      "networkName": "Название сети",
      "proxyTitle": "Проверка прокси",
      "riskTitle": "Риски и роботы",
      "yes": "Да",
      "no": "Нет",
      "unknown": "Недоступно",
      "is_proxy": "Прокси",
      "is_vpn": "VPN",
      "is_tor": "Выход Tor",
      "is_data_center": "Дата-центр",
      "is_public_proxy": "Публичный прокси",
      "is_web_proxy": "Веб-прокси",
      "is_residential_proxy": "Резидентный прокси",
      "is_consumer_privacy_network": "Сеть конфиденциальности",
      "is_enterprise_private_network": "Корпоративная сеть",
      "is_spammer": "Спам",
      "is_scanner": "Сканер",
      "is_botnet": "Ботнет",
      "is_bogon": "Некорректный адрес",
      "is_web_crawler": "Поисковый робот",
      "is_ai_crawler": "ИИ-робот",
      "types": {
        "COM": "Коммерческая сеть",
        "ORG": "Организация",
        "GOV": "Государственная сеть",
        "MIL": "Военная сеть",
        "EDU": "Образование",
        "LIB": "Библиотека",
        "CDN": "Сеть доставки контента",
        "ISP": "Фиксированный доступ",
        "MOB": "Мобильная сеть",
        "ISP/MOB": "Фиксированный / мобильный доступ",
        "DCH": "Дата-центр",
        "SES": "Поисковый робот",
        "AIC": "ИИ-робот",
        "RSV": "Зарезервировано"
      }
    },
    "minimumTraffic": "Скрыть трафик меньше (МБ)", "trafficFilter": "Фильтр трафика", "hideTrafficBelow": "Скрыть меньше",
    "trafficMinimumSuffix": "МБ", "trafficFilterApplied": "Скрыть записи меньше {{value}} МБ",
    "showAllTraffic": "Показать всё", "applyTrafficFilter": "Применить",
    "observedProvinces": "Регионы появления",
    "inboundIp": "Входящие IP", "inboundUsers": "Входящие IP пользователей", "ipCount": "Число IP", "firstSeen": "Первое появление", "lastSeen": "Последнее появление",
    "backToInbound": "К списку входящих IP", "filterProvince": "Выбрать регион", "allProvinces": "Все регионы",
    "ipAddress": "IP-адрес", "location": "Местоположение", "asn": "ASN", "unknown": "Неизвестно", "inboundCount": "Всего IP: {{count}}",
    "last24": "За 24 часа", "last14": "За 14 дней", "all": "Всё", "startTime": "Начало", "endTime": "Конец",
    "confirm": "Применить", "cancel": "Отмена", "previousMonth": "Назад", "nextMonth": "Вперёд",
    "wholeHours": "Для прошлых дат и диапазонов в несколько дней выбирайте целые часы.", "searchNode": "Поиск узлов", "nodeName": "Название узла", "asc": "По возрастанию", "desc": "По убыванию",
    "direct": "Напрямую", "effectiveRate": "Применённый множитель",
    "hour": "По часам", "perPage": "Строк на странице", "backToUsers": "К рейтингу пользователей",
    "navigation": "Статистика", "overview": "Статистика трафика", "nodeStatistics": "Использование узлов", "userStatistics": "Статистика пользователей",
    "trend": "Динамика общего трафика", "nodeRank": "Рейтинг использования узлов", "userRank": "Рейтинг пользователей", "userDetails": "Трафик по пользователям и узлам",
    "period": "Период", "last30": "Последние 30 дней", "last7": "Последние 7 дней", "today": "Сегодня", "custom": "Выбрать даты",
    "unit": "Группировка", "day": "По дням", "week": "По неделям", "month": "По месяцам", "metric": "Тип трафика", "actual": "Фактический", "billed": "Списанный",
    "startDate": "Начальная дата", "endDate": "Конечная дата", "to": "до", "apply": "Применить", "invalidRange": "Выберите допустимый диапазон дат.",
    "total": "Всего", "upload": "Отправлено", "download": "Получено", "rank": "Место", "node": "Узел", "user": "Пользователь", "actions": "Действия",
    "viewDetails": "Подробнее", "loading": "Загрузка", "empty": "Нет данных", "loadFailed": "Не удалось загрузить данные. Повторите попытку.", "retry": "Повторить",
    "page": "Страница {{page}} / {{pages}}, записей: {{count}}", "previous": "Назад", "next": "Далее",
    "searchUser": "Поиск пользователей", "searchPlaceholder": "Почта или ID пользователя", "search": "Поиск", "clear": "Сбросить",
    "inboundSearchPlaceholder": "Почта, ID или IP пользователя", "searchIp": "Поиск IP", "ipSearchPlaceholder": "Полный IP-адрес или его часть",
    "chooseUser": "Найдите пользователя или выберите его в рейтинге.", "filterNode": "Фильтр узлов", "allNodes": "Все узлы",
    "entryTotal": "Всего на входе", "relayTotal": "Всего на выходе", "date": "Дата", "position": "Тип передачи", "entry": "Вход", "relay": "Ретрансляция"
  },
  "telegramBot": {
    "userReminders": "Напоминания пользователям", "nodeNotifications": "Уведомления об узлах", "nodeNotificationSaved": "Уведомления об узлах сохранены",
    "groupLink": "Ссылка на группу Telegram", "groupLinkInvalid": "Укажите полную HTTP или HTTPS ссылку на группу.",
    "groupNodeSettings": "Настройки групп", "groupNodeSaved": "Настройки групп сохранены",
    "auto_approve_join": "Автоматическая проверка заявок", "notify_node_offline": "Уведомления об отключении узлов",
    "notify_xray_crash": "Уведомления о сбое ядра Xray",
    "joinGroups": "ID групп для проверки", "joinGroupsPlaceholder": "Один ID группы на строку, например -1001234567890",
    "joinGroupsInvalid": "Укажите до 20 отрицательных ID групп; при включении проверки нужна хотя бы одна группа.",
    "joinGroupRequirement": "Бот должен быть администратором с правом приглашения. Ссылка должна требовать одобрения заявки.",
    "nodeOfflineMinutes": "Уведомлять при отсутствии связи (минуты)",
    "nodeOfflineRecipients": "Отправляются администраторам, привязанным к Telegram Bot.",
    "businessNotifications": "Тикеты и платежи", "businessNotificationSaved": "Настройки тикетов и платежей сохранены",
    "businessNotificationTypes": { "notify_ticket": "Уведомления о тикетах", "allow_ticket_reply": "Ответы на тикеты", "notify_payment": "Уведомления о платежах" },
    "adminNotifications": "Уведомления администраторам", "adminNotificationSaved": "Настройки уведомлений администраторам сохранены",
    "adminNotificationTypes": { "device": "Предупреждения о лимите устройств", "connection": "Предупреждения о лимите соединений" },
    "adminRecipients": "Получатели (числовые Telegram ID)",
    "adminRecipientsPlaceholder": "Один ID в строке; каждый получатель должен сначала отправить боту /start в личном чате",
    "adminRecipientsInvalid": "Укажите до 20 разных действительных Telegram ID; при включённых предупреждениях нужен хотя бы один",
    "adminNotificationInterval": "Интервал повторных предупреждений (минуты)",
    "reminders": "Напоминания", "reminderSaved": "Настройки напоминаний сохранены",
    "reminderTypes": { "expiring": "Скорое окончание подписки", "expired": "Подписка истекла", "device": "Превышен лимит устройств", "connection": "Превышен лимит соединений" },
    "reminderDays": "Дней до окончания подписки", "reminderInterval": "Интервал уведомлений о лимитах (минуты)",
    "reminderRange": "Введите целое число от 1 до {{max}}",
    "operationFailed": "Операция не выполнена. Проверьте настройки и повторите попытку.",
    "title": "Telegram Bot", "settings": "Настройки бота", "bindings": "Управление пользователями",
    "actions": "Действия", "unbind": "Отвязать", "unbindConfirm": "Отвязать пользователя?",
    "unbindDescription": "Связь между пользователем Telegram и аккаунтом панели будет удалена. Аккаунт, тариф и подписка сохранятся. Для повторной привязки пользователь может отправить ссылку на подписку.",
    "unbindSuccess": "Пользователь отвязан", "unbindFailed": "Не удалось отвязать пользователя. Повторите попытку.",
    "loading": "Загрузка", "loadFailed": "Не удалось загрузить данные. Повторите попытку.", "retry": "Повторить",
    "enabledState": "Состояние", "enabled": "Включён", "disabled": "Выключен",
    "connectionState": "Приём сообщений", "username": "Аккаунт бота", "notChecked": "Не проверено",
    "lastReceived": "Последнее сообщение", "neverReceived": "Сообщений пока нет",
    "pendingMessages": "Сообщения в очереди", "checkWarning": "Проверка выявила проблему приёма сообщений",
    "testMessage": "Отправить тестовое сообщение", "testRecipient": "Получатель теста (числовой Telegram ID)",
    "recipientPlaceholder": "Получатель должен сначала отправить боту /start в личном чате",
    "recipientRequired": "Введите числовой Telegram ID; имена пользователей и группы не поддерживаются",
    "token": "Токен бота", "tokenRequired": "Введите токен бота",
    "showToken": "Показать токен бота", "hideToken": "Скрыть токен бота",
    "tokenPlaceholder": "Введите токен бота", "tokenInvalid": "Введите действительный токен бота",
    "urlInvalid": "Введите HTTPS-адрес без пути приёма сообщений, учётных данных и параметров запроса",
    "saveConfirm": "Выключить бота и сохранить новые настройки?", "saveDescription": "Текущий бот будет выключен перед сохранением новых настроек. Привязки аккаунтов сохранятся. После сохранения включите бота снова.",
    "stopFailed": "Не удалось завершить выключение бота. Новые настройки не сохранены. Повторите попытку.",
    "webhookUrl": "Адрес приёма сообщений", "webhookBaseUrl": "Webhook Base URL",
    "webhookDocs": "Документация Telegram Webhook", "urlRequired": "Введите Webhook Base URL",
    "save": "Сохранить", "processing": "Обработка", "check": "Проверить соединение", "refresh": "Обновить состояние",
    "enable": "Включить", "disable": "Выключить", "cancel": "Отмена", "confirm": "Подтвердить",
    "enableConfirm": "Включить Telegram Bot?", "enableDescription": "Бот начнёт принимать сообщения и привязывать аккаунты.",
    "disableConfirm": "Выключить Telegram Bot?", "disableDescription": "Обработка сообщений прекратится. Привязки аккаунтов сохранятся.",
    "email": "Почта аккаунта", "telegramId": "Telegram ID", "telegramUsername": "Имя пользователя Telegram", "boundAt": "Дата привязки",
    "searchPlaceholder": "Поиск по почте, Telegram ID или имени пользователя", "search": "Поиск",
    "total": "Привязок: {{count}}", "previous": "Назад", "next": "Далее", "page": "Страница {{current}} / {{total}}",
    "status": { "unconfigured": "Не настроено", "unchecked": "Не проверено", "error": "Ошибка соединения", "connected": "Адрес приёма зарегистрирован", "disconnected": "Адрес приёма не зарегистрирован" },
    "success": { "saveApplied": "Настройки сохранены, бот снова включён", "save": "Настройки сохранены", "saveStopped": "Настройки сохранены. Включите бота снова.", "check": "Проверка API Telegram завершена", "enable": "Бот включён", "disable": "Бот выключен", "testMessage": "Тестовое сообщение отправлено. Проверьте Telegram." }
  },
  "giftCard": {
    "title": "Управление подарочными картами",
    "description": "Управление шаблонами подарочных карт, кодами активации и записями об использовании.",
    "tabs": {
      "templates": "Управление шаблонами",
      "codes": "Коды активации",
      "usages": "История использования",
      "statistics": "Статистика"
    },
    "template": {
      "title": "Управление шаблонами",
      "description": "Создание, редактирование и удаление шаблонов подарочных карт.",
      "table": {
        "title": "Список шаблонов",
        "columns": {
          "id": "ID",
          "name": "Название",
          "type": "Тип",
          "status": "Статус",
          "sort": "Сортировка",
          "rewards": "Награды",
          "created_at": "Дата создания",
          "actions": "Действия",
          "no_rewards": "Нет наград"
        }
      },
      "form": {
        "add": "Добавить шаблон",
        "edit": "Изменить шаблон",
        "name": {
          "label": "Название шаблона",
          "placeholder": "Введите название шаблона",
          "required": "Пожалуйста, введите название шаблона"
        },
        "sort": {
          "label": "Сортировка",
          "placeholder": "Меньшие числа отображаются первыми"
        },
        "type": {
          "label": "Тип",
          "placeholder": "Выберите тип карты"
        },
        "description": {
          "label": "Описание",
          "placeholder": "Введите описание подарочной карты"
        },
        "status": {
          "label": "Статус",
          "description": "Если отключено, этот шаблон нельзя использовать для создания или активации новых карт."
        },
        "display": {
          "title": "Визуальные эффекты"
        },
        "theme_color": {
          "label": "Цвет темы"
        },
        "icon": {
          "label": "Иконка",
          "placeholder": "Введите URL иконки"
        },
        "background_image": {
          "label": "Фоновое изображение",
          "placeholder": "Введите URL фонового изображения"
        },
        "conditions": {
          "title": "Условия использования",
          "new_user_max_days": {
            "label": "Лимит дней регистрации нового пользователя",
            "placeholder": "Пример: 7 (Только для пользователей, зарегистрированных в течение 7 дней)"
          },
          "new_user_only": {
            "label": "Только для новых пользователей"
          },
          "paid_user_only": {
            "label": "Только для платных пользователей"
          },
          "require_invite": {
            "label": "Требуется наличие пригласителя"
          },
          "allowed_plans": {
            "label": "Разрешенные тарифы",
            "placeholder": "Выберите тарифы, доступные для активации (оставьте пустым для всех)"
          },
          "disallowed_plans": {
            "label": "Запрещенные тарифы",
            "placeholder": "Выберите тарифы, для которых активация запрещена"
          }
        },
        "limits": {
          "title": "Ограничения",
          "max_use_per_user": {
            "label": "Макс. использований на пользователя",
            "placeholder": "Оставьте пустым для безлимита"
          },
          "cooldown_hours": {
            "label": "Кулдаун (часы) для однотипных карт",
            "placeholder": "Оставьте пустым для безлимита"
          },
          "invite_reward_rate": {
            "label": "Доля вознаграждения пригласителя",
            "placeholder": "Пример: 0.2 (означает 20%)",
            "description": "Если у пользователя есть пригласитель, его бонус = бонус пользователя × эта доля"
          }
        },
        "rewards": {
          "title": "Награды",
          "balance": {
            "label": "Бонусный баланс (Валюта)",
            "short_label": "Баланс",
            "placeholder": "Введите сумму вознаграждения"
          },
          "transfer_enable": {
            "label": "Бонусный трафик (ГБ)",
            "short_label": "Трафик",
            "placeholder": "Введите объем трафика (ГБ)"
          },
          "expire_days": {
            "label": "Продление срока (дней)",
            "short_label": "Срок",
            "placeholder": "Введите количество дней"
          },
          "transfer": {
            "label": "Бонусный трафик (Байты)",
            "placeholder": "Введите объем трафика (байты)"
          },
          "days": {
            "label": "Продление срока (дней)",
            "placeholder": "Введите количество дней"
          },
          "device_limit": {
            "label": "Увеличить лимит устройств",
            "short_label": "Устройства",
            "placeholder": "Введите количество дополнительных устройств"
          },
          "reset_package": {
            "label": "Сбросить месячный трафик",
            "description": "Если включено, активация очистит использованный трафик текущего тарифа пользователя."
          },
          "reset_count": {
            "description": "Этот тип карты сбрасывает использование месячного трафика пользователя."
          },
          "task_card": {
            "description": "Награды для бонусных карт за задания настраиваются в системе заданий."
          },
          "plan_id": {
            "label": "Указанный тариф",
            "short_label": "Тариф",
            "placeholder": "Пожалуйста, выберите тариф"
          },
          "plan_validity_days": {
            "label": "Срок действия тарифа (дней)",
            "short_label": "Срок тарифа",
            "placeholder": "Оставьте пустым для срока по умолчанию"
          },
          "random_rewards": {
            "label": "Пул случайных наград",
            "add": "Добавить случайную награду",
            "weight": "Вес"
          }
        },
        "special_config": {
          "title": "Специальная конфигурация",
          "start_time": {
            "label": "Время начала события",
            "placeholder": "Выберите дату начала"
          },
          "end_time": {
            "label": "Время окончания события",
            "placeholder": "Выберите дату окончания"
          },
          "festival_bonus": {
            "label": "Множитель праздничной награды",
            "placeholder": "Пример: 1.5 (означает 1.5x)"
          }
        },
        "submit": {
          "saving": "Сохранение...",
          "save": "Сохранить"
        }
      },
      "actions": {
        "edit": "Изменить",
        "delete": "Удалить",
        "deleteConfirm": {
          "title": "Подтверждение удаления",
          "description": "Это действие навсегда удалит этот шаблон. Вы уверены, что хотите продолжить?",
          "confirmText": "Удалить"
        }
      }
    },
    "code": {
      "title": "Управление кодами активации",
      "form": {
        "generate": "Сгенерировать коды активации",
        "template_id": {
          "label": "Выберите шаблон",
          "placeholder": "Выберите шаблон для генерации кодов активации"
        },
        "count": {
          "label": "Количество кодов"
        },
        "prefix": {
          "label": "Кастомный префикс (опционально)"
        },
        "expires_hours": {
          "label": "Срок действия (часов)"
        },
        "max_usage": {
          "label": "Лимит использований кода"
        },
        "download_csv": "Экспорт в CSV",
        "submit": {
          "generating": "Генерация...",
          "generate": "Сгенерировать сейчас"
        }
      },
      "description": "Управление кодами активации: генерация, просмотр и экспорт.",
      "table": {
        "title": "Список кодов активации",
        "columns": {
          "id": "ID",
          "code": "Код активации",
          "template_name": "Название шаблона",
          "status": "Статус",
          "expires_at": "Истекает",
          "usage_count": "Использовано",
          "max_usage": "Доступно",
          "created_at": "Дата создания"
        }
      },
      "actions": {
        "enable": "Включить",
        "disable": "Отключить",
        "export": "Экспорт",
        "exportConfirm": {
          "title": "Подтверждение экспорта",
          "description": "Все коды из выбранной группы будут экспортированы в текстовый файл. Продолжить?",
          "confirmText": "Экспорт"
        }
      },
      "status": {
        "0": "Не использован",
        "1": "Использован",
        "2": "Отключен",
        "3": "Истек"
      }
    },
    "usage": {
      "title": "История использования",
      "description": "Просмотр записей об использовании подарочных карт.",
      "table": {
        "columns": {
          "id": "ID",
          "code": "Код активации",
          "template_name": "Название шаблона",
          "user_email": "Email пользователя",
          "rewards_given": "Выданные награды",
          "invite_rewards": "Бонус пригласителя",
          "multiplier_applied": "Применен множитель",
          "ip_address": "IP адрес",
          "created_at": "Время использования",
          "actions": "Действия"
        }
      },
      "actions": {
        "view": "Детали"
      }
    },
    "statistics": {
      "title": "Статистика",
      "description": "Анализ использования подарочных карт.",
      "total": {
        "title": "Общая статистика",
        "templates_count": "Всего шаблонов",
        "active_templates_count": "Активных шаблонов",
        "codes_count": "Всего кодов активации",
        "used_codes_count": "Использовано кодов",
        "usages_count": "Записей об активации"
      },
      "daily": {
        "title": "Использование за день"
      }
    }
  },
  "user": {
    "column_settings": "Столбцы",
    "extend_duration": {
      "title": "Продлить срок",
      "selected": "Выбрано пользователей: {{count}}",
      "days": "Добавить дней",
      "cancel": "Отмена",
      "confirm": "Подтвердить продление",
      "pending": "Обработка",
      "result": "Продлено: {{updated}}, пропущено: {{skipped}}",
      "failed": "Не удалось продлить. Обновите и проверьте данные перед повтором"
    },
    "manage": {
      "title": "Управление пользователями",
      "description": "Здесь вы можете управлять пользователями, включая добавление, удаление, редактирование и поиск."
    },
    "columns": {
      "is_admin": "Админ",
      "is_staff": "Персонал",
      "id": "ID",
      "email": "Email",
      "online_count": "Устройства онлайн",
      "connection_count": "Соединения",
      "upload_speed": "Скорость отдачи",
      "download_speed": "Скорость загрузки",
      "speed_unknown": "Неизвестно",
      "speed_partial": "Данные части узлов недоступны; показана подтверждённая скорость",
      "connections_unknown": "Нет свежих данных о соединениях",
      "connections_partial": "Не все узлы передали данные; показаны только подтверждённые соединения",
      "status": "Статус",
      "subscription": "Подписка",
      "group": "Группа",
      "used_traffic": "Использовано",
      "total_traffic": "Всего трафика",
      "expire_time": "Срок действия",
      "balance": "Баланс",
      "commission": "Комиссия",
      "register_time": "Дата регистрации",
      "actions": "Действия",
      "next_reset_at": "След. сброс",
      "device_limit": {
        "unlimited": "Без лимита устройств",
        "limited": "Максимум {{count}} устройств"
      },
      "status_text": {
        "normal": "Нормальный",
        "banned": "Забанен"
      },
      "online_status": {
        "online": "В сети",
        "never": "Никогда не был в сети",
        "last_online": "Был в сети: {{time}}",
        "offline_duration": {
          "days": "Не в сети: {{count}}д",
          "hours": "Не в сети: {{count}}ч",
          "minutes": "Не в сети: {{count}}м",
          "seconds": "Не в сети: {{count}}с"
        }
      },
      "expire_status": {
        "permanent": "Бессрочно",
        "expired": "Истекло {{days}} дн. назад",
        "remaining": "Осталось {{days}} дн."
      },
      "actions_menu": {
        "edit": "Редактировать",
        "view_details": "Просмотреть детали",
        "assign_order": "Назначить заказ",
        "copy_url": "Копировать ссылку подписки",
        "reset_secret": "Сбросить UUID и URL",
        "orders": "Заказы",
        "invites": "Приглашения",
        "traffic_records": "Записи трафика",
        "reset_traffic": "Сбросить трафик",
        "delete": "Удалить",
        "delete_confirm_title": "Подтверждение удаления пользователя",
        "delete_confirm_description": "Это действие навсегда удалит пользователя {{email}} и все связанные данные, включая заказы, купоны, записи трафика и тикеты. Это действие нельзя отменить. Продолжить?"
      }
    },
    "filter": {
      "selected": "Выбрано {{count}}",
      "no_results": "Результатов не найдено.",
      "clear": "Очистить фильтры",
      "search_placeholder": "Поиск...",
      "email_search": "Поиск по email...",
      "plan": "Тариф",
      "advanced": "Расширенный фильтр",
      "reset": "Сбросить фильтр",
      "sheet": {
        "title": "Расширенный фильтр",
        "description": "Добавьте одно или несколько условий для точного поиска пользователей",
        "conditions": "Условия фильтрации",
        "add": "Добавить условие",
        "condition": "Условие {{number}}",
        "field": "Выберите поле",
        "operator": "Выберите оператор",
        "value": "Введите значение",
        "value_number": "Введите значение ({{unit}})",
        "reset": "Сброс",
        "apply": "Применить фильтр"
      },
      "fields": {
        "email": "Email",
        "phone": "Номер телефона",
        "id": "ID пользователя",
        "plan_id": "Подписка",
        "transfer_enable": "Трафик",
        "total_used": "Использовано",
        "online_count": "Устройства онлайн",
        "expired_at": "Срок действия",
        "uuid": "UUID",
        "token": "Токен",
        "banned": "Статус аккаунта",
        "remark": "Примечание",
        "inviter_email": "Email пригласителя",
        "invite_user_id": "ID пригласителя",
        "is_admin": "Админ",
        "is_staff": "Персонал"
      },
      "operators": {
        "contains": "Содержит",
        "eq": "Равно",
        "gt": "Больше",
        "lt": "Меньше"
      },
      "status": {
        "normal": "Нормальный",
        "banned": "Забанен"
      },
      "boolean": {
        "true": "Да",
        "false": "Нет"
      }
    },
    "generate": {
      "button": "Создать пользователя",
      "title": "Создание пользователя",
      "form": {
        "email": "Email",
        "email_prefix": "Префикс аккаунта (оставьте пустым для пакетной генерации)",
        "email_domain": "Домен",
        "password": "Пароль",
        "password_placeholder": "Оставьте пустым, чтобы сгенерировать случайный пароль",
        "random_password": "Случайный",
        "expire_time": "Срок действия",
        "expire_time_placeholder": "Выберите срок действия, оставьте пустым для бессрочного",
        "permanent": "Бессрочно",
        "subscription": "Тарифный план",
        "subscription_none": "Нет",
        "generate_count": "Количество для генерации",
        "generate_count_placeholder": "Введите количество для пакетной генерации",
        "cancel": "Отмена",
        "submit": "Создать",
        "success": "Пользователи созданы",
        "download_csv": "Скачать как CSV"
      },
      "result": {
        "title": "Аккаунты созданы",
        "copy": "Копировать",
        "copy_all": "Копировать все",
        "copied": "Скопировано",
        "copy_failed": "Не удалось скопировать, выделите и скопируйте вручную",
        "close": "Закрыть"
      }
    },
    "edit": {
      "button": "Редактировать пользователя",
      "title": "Управление пользователем",
      "form": {
        "email": "Email",
        "phone_country": "Страна/регион",
        "phone": "Номер телефона",
        "phone_placeholder": "Введите номер телефона",
        "email_placeholder": "Пожалуйста, введите email",
        "inviter_email": "Email пригласителя",
        "inviter_email_placeholder": "Пожалуйста, введите email",
        "password": "Пароль",
        "password_placeholder": "Введите новый пароль, если хотите изменить его",
        "random_password": "Случайный",
        "copy_password": "Копировать пароль",
        "password_copied": "Пароль скопирован",
        "copy_failed": "Не удалось скопировать, выделите и скопируйте вручную",
        "balance": "Баланс",
        "balance_placeholder": "Пожалуйста, введите баланс",
        "commission_balance": "Баланс комиссии",
        "commission_balance_placeholder": "Пожалуйста, введите баланс комиссии",
        "upload": "Трафик (загрузка)",
        "upload_placeholder": "Введите трафик загрузки",
        "download": "Трафик (скачивание)",
        "download_placeholder": "Введите трафик скачивания",
        "total_traffic": "Общий трафик",
        "total_traffic_placeholder": "Пожалуйста, введите трафик",
        "expire_time": "Срок действия",
        "expire_time_placeholder": "Выберите дату, оставьте пустым для бессрочного",
        "expire_time_specific": "Конкретное время",
        "expire_time_today": "До конца сегодня",
        "expire_time_permanent": "Бессрочно",
        "expire_time_1hour": "Один час",
        "expire_time_1month": "Один месяц",
        "expire_time_3months": "Три месяца",
        "expire_time_confirm": "Подтвердить",
        "subscription": "Тарифный план",
        "subscription_none": "Нет",
        "account_status": "Статус аккаунта",
        "commission_type": "Тип комиссии",
        "commission_type_system": "По системным настройкам",
        "commission_type_cycle": "Циклическая комиссия",
        "commission_type_onetime": "Единоразовая комиссия",
        "commission_rate": "Ставка комиссии",
        "commission_rate_placeholder": "Оставьте пустым для системной ставки",
        "discount": "Эксклюзивная скидка",
        "discount_placeholder": "Оставьте пустым, если нет скидки",
        "speed_limit": "Лимит скорости",
        "speed_limit_placeholder": "Оставьте пустым для безлимита",
        "device_limit": "Лимит устройств",
        "device_limit_placeholder": "Оставьте пустым для безлимита",
        "conn_limit": "Одновременные соединения",
        "conn_limit_placeholder": "Оставьте пустым для безлимита",
        "conn_rate_limit": "Скорость новых соединений",
        "conn_rate_limit_placeholder": "Оставьте пустым для безлимита",
        "is_admin": "Админ",
        "is_staff": "Персонал",
        "remarks": "Примечания",
        "remarks_placeholder": "Введите примечания здесь",
        "cancel": "Отмена",
        "submit": "Отправить",
        "success": "Изменено успешно"
      }
    },
    "actions": {
      "title": "Действия",
      "send_email": "Отправить Email",
      "export_csv": "Экспорт в CSV",
      "traffic_reset_stats": "Статистика сброса трафика",
      "batch_ban": "Пакетный бан",
      "confirm_ban": {
        "title": "Подтверждение пакетного бана",
        "filtered_description": "Это действие забанит всех пользователей, соответствующих вашим текущим фильтрам. Это нельзя отменить.",
        "all_description": "Это действие забанит всех пользователей в системе. Это нельзя отменить.",
        "cancel": "Отмена",
        "confirm": "Подтвердить бан",
        "banning": "Баню..."
      }
    },
    "messages": {
      "success": "Успех",
      "error": "Ошибка",
      "export": {
        "success": "Экспорт выполнен",
        "failed": "Ошибка экспорта"
      },
      "batch_ban": {
        "success": "Пакетный бан выполнен",
        "failed": "Ошибка пакетного бана"
      },
      "send_mail": {
        "success": "Email отправлен",
        "failed": "Ошибка отправки email",
        "required_fields": "Пожалуйста, заполните обязательные поля"
      }
    },
    "traffic_reset": {
      "title": "Сброс трафика",
      "description": "Сбросить трафик для пользователя {{email}}",
      "tabs": {
        "reset": "Сбросить трафик",
        "history": "История сбросов"
      },
      "user_info": "Информация о пользователе",
      "warning": {
        "title": "Важное уведомление",
        "irreversible": "Операция сброса трафика необратима, пожалуйста, будьте осторожны",
        "reset_to_zero": "После сброса трафик загрузки и скачивания пользователя будет обнулен",
        "logged": "Все операции сброса записываются в системные логи"
      },
      "reason": {
        "label": "Причина сброса",
        "placeholder": "Введите причину сброса (опционально)",
        "optional": "Это поле не обязательно и используется для записи причины сброса"
      },
      "confirm_reset": "Подтвердить сброс",
      "resetting": "Сбрасываю...",
      "reset_success": "Трафик сброшен успешно",
      "reset_failed": "Ошибка при сбросе трафика",
      "history": {
        "summary": "Обзор сбросов",
        "reset_count": "Количество сбросов",
        "last_reset": "Последний сброс",
        "next_reset": "Следующий сброс",
        "never": "Никогда не сбрасывался",
        "no_schedule": "Сброс не запланирован",
        "records": "Записи о сбросе",
        "recent_records": "Последние 10 записей",
        "no_records": "Записей о сбросе нет",
        "reset_time": "Время сброса",
        "traffic_cleared": "Трафик обнулен"
      },
      "stats": {
        "title": "Статистика сброса трафика",
        "description": "Просмотр системной статистики сброса трафика",
        "time_range": "Временной диапазон",
        "total_resets": "Всего сбросов",
        "auto_resets": "Автоматические",
        "manual_resets": "Ручные",
        "cron_resets": "По расписанию/Cron",
        "in_period": "За последние {{days}} дн.",
        "breakdown": "Разбивка по типам",
        "breakdown_description": "Процентное соотношение различных типов операций сброса",
        "auto_percentage": "Доля автосбросов",
        "manual_percentage": "Доля ручных сбросов",
        "cron_percentage": "Доля сбросов по Cron",
        "days_options": {
          "week": "За неделю",
          "month": "За месяц",
          "quarter": "За квартал",
          "year": "За год"
        }
      }
    },
    "traffic_reset_logs": {
      "title": "Логи сброса трафика",
      "description": "Просмотр подробных записей всех операций сброса трафика в системе",
      "columns": {
        "id": "ID лога",
        "user": "Пользователь",
        "reset_type": "Тип сброса",
        "trigger_source": "Источник",
        "cleared_traffic": "Обнуленный трафик",
        "cleared": "Обнулено",
        "upload": "Загрузка",
        "download": "Скачивание",
        "reset_time": "Время сброса",
        "log_time": "Время записи"
      },
      "filters": {
        "search_user": "Поиск по email...",
        "reset_type": "Тип сброса",
        "trigger_source": "Источник",
        "all_types": "Все типы",
        "all_sources": "Все источники",
        "start_date": "Дата начала",
        "end_date": "Дата окончания",
        "apply_date": "Применить фильтр",
        "reset": "Сбросить фильтр",
        "filter_title": "Параметры фильтрации",
        "filter_description": "Установите условия для поиска записей о сбросе трафика",
        "reset_types": {
          "monthly": "Ежемесячно",
          "first_day_month": "Первое число месяца",
          "yearly": "Ежегодно",
          "first_day_year": "Первое число года",
          "manual": "Вручную"
        },
        "trigger_sources": {
          "auto": "Автоматически",
          "manual": "Вручную",
          "cron": "По расписанию/Cron"
        }
      },
      "actions": {
        "export": "Экспорт логов",
        "exporting": "Экспортирую...",
        "export_success": "Экспорт выполнен успешно",
        "export_failed": "Ошибка экспорта"
      },
      "trigger_descriptions": {
        "manual": "Сброс трафика выполнен администратором вручную",
        "cron": "Сброс выполнен автоматически системной задачей (Cron)",
        "auto": "Автоматический сброс при выполнении условий системы",
        "other": "Сброс выполнен другим способом"
      }
    },
    "send_mail": {
      "title": "Отправить Email",
      "description": "Отправить сообщение выбранным или отфильтрованным пользователям",
      "subject": "Тема",
      "content": "Содержимое",
      "sending": "Отправка...",
      "send": "Отправить"
    },
    "dialog": {
      "title": "Детали пользователя",
      "basicInfo": "Основная информация",
      "subscriptionInfo": "Информация о подписке",
      "trafficInfo": "Информация о трафике",
      "financialInfo": "Финансовая информация",
      "activityInfo": "Активность",
      "inviteInfo": "Реферальная информация",
      "timeInfo": "Временные метки",
      "subscriptionUrl": "Ссылка подписки",
      "fields": {
        "userId": "ID пользователя",
        "email": "Email",
        "phone": "Номер телефона",
        "uuid": "UUID",
        "token": "Токен",
        "remarks": "Примечания",
        "subscriptionPlan": "Тариф",
        "permissionGroup": "Группы доступа",
        "expiredAt": "Истекает",
        "deviceLimit": "Лимит устройств",
        "speedLimit": "Лимит скорости",
        "transferEnable": "Всего трафика",
        "uploadUsed": "Использовано (Up)",
        "downloadUsed": "Использовано (Down)",
        "totalUsed": "Всего использовано",
        "lastResetAt": "Последний сброс",
        "nextResetAt": "Следующий сброс",
        "resetCount": "Кол-во сбросов",
        "balance": "Баланс",
        "commissionBalance": "Баланс комиссии",
        "commissionType": "Тип комиссии",
        "commissionRate": "Ставка комиссии",
        "lastLoginAt": "Последний вход",
        "lastLoginIp": "IP последнего входа",
        "lastOnlineAt": "Последний раз онлайн",
        "onlineCount": "Устройства онлайн",
        "inviteUser": "Пригласитель",
        "inviteUserId": "ID пригласителя",
        "createdAt": "Дата создания",
        "updatedAt": "Дата обновления",
        "subscribeUrl": "Ссылка подписки",
        "telegramId": "Telegram ID"
      }
    },
    "status": {
      "normal": "Нормальный",
      "banned": "Забанен",
      "admin": "Админ",
      "staff": "Персонал"
    }
  },
  "nav": {
    "telegramBot": "Telegram Bot",
    "dashboard": "Панель управления",
    "systemManagement": "Управление системой",
    "systemConfig": "Настройки системы",
    "themeConfig": "Настройки темы",
    "noticeManagement": "Управление уведомлениями",
    "pluginManagement": "Управление плагинами",
    "paymentConfig": "Настройки оплаты",
    "knowledgeManagement": "База знаний",
    "nodeManagement": "Управление узлами",
    "machineManagement": "Управление серверами",
    "permissionGroupManagement": "Группы доступа",
    "routeManagement": "Управление маршрутами",
    "subscriptionManagement": "Подписки",
    "planManagement": "Тарифные планы",
    "planSettings": "Настройки тарифов",
    "orderManagement": "Управление заказами",
    "couponManagement": "Купоны",
    "giftCardManagement": "Подарочные карты",
    "userManagement": "Пользователи",
    "trafficResetLogs": "Логи сброса трафика",
    "ticketManagement": "Тикеты",
    "pluginApps": "Приложения плагинов"
  },
  "subscribe": {
    "plan": {
      "title": "Тарифные планы",
      "add": "Добавить план",
      "search": "Поиск планов...",
      "sort": {
        "edit": "Изменить порядок",
        "save": "Сохранить порядок"
      },
      "columns": {
        "id": "ID",
        "show": "Показывать",
        "sell": "Продавать",
        "renew": "Продление",
        "renew_tooltip": "Могут ли существующие пользователи продлевать подписку, когда она снята с продажи",
        "name": "Название",
        "stats": "Статистика",
        "group": "Группа доступа",
        "price": "Цена",
        "actions": "Действия",
        "edit": "Изменить",
        "delete": "Удалить",
        "delete_confirm": {
          "title": "Подтверждение удаления",
          "description": "Это действие навсегда удалит этот тарифный план. Вы уверены, что хотите продолжить?",
          "success": "Тариф успешно удален"
        },
        "price_period": {
          "monthly": "Ежемесячно",
          "quarterly": "Ежеквартально",
          "half_yearly": "Раз в полгода",
          "yearly": "Ежегодно",
          "two_yearly": "Раз в 2 года",
          "three_yearly": "Раз в 3 года",
          "onetime": "Единоразово",
          "reset_traffic": "Сброс трафика",
          "no_price": "Нет цены",
          "unit": {
            "month": "/мес",
            "quarter": "/квартал",
            "half_year": "/полгода",
            "year": "/год",
            "two_year": "/2 года",
            "three_year": "/3 года",
            "times": "/раз"
          }
        }
      },
      "form": {
        "add_title": "Добавить тариф",
        "edit_title": "Изменить тариф",
        "name": {
          "label": "Название тарифа",
          "placeholder": "Введите название тарифа"
        },
        "group": {
          "label": "Группы доступа",
          "add": "Добавить группу",
          "placeholder": "Выберите группы доступа"
        },
        "transfer": {
          "label": "Трафик",
          "placeholder": "Введите лимит трафика",
          "unit": "ГБ"
        },
        "speed": {
          "label": "Ограничение скорости",
          "placeholder": "Введите лимит скорости",
          "unit": "Мбит/с"
        },
        "price": {
          "title": "Настройки цены",
          "base_price": "Базовая цена",
          "clear": {
            "button": "Очистить",
            "tooltip": "Очистить все цены"
          },
          "period": {
            "monthly": "Добавить",
            "months": "{{count}} Мес."
          },
          "onetime_desc": "Единоразовый пакет трафика, без ограничения по времени",
          "reset_desc": "Пакет сброса трафика, может быть использован многократно"
        },
        "device": {
          "label": "Лимит устройств",
          "placeholder": "Введите лимит устройств",
          "unit": "Устройств"
        },
        "conn": {
          "label": "Одновременные соединения",
          "placeholder": "Оставьте пустым для безлимита",
          "unit": "шт"
        },
        "conn_rate": {
          "label": "Скорость новых соединений",
          "placeholder": "Оставьте пустым для безлимита",
          "unit": "в секунду"
        },
        "capacity": {
          "label": "Лимит пользователей",
          "placeholder": "Введите лимит емкости",
          "unit": "Пользователей"
        },
        "tags": {
          "label": "Теги",
          "placeholder": "Введите тег и нажмите Enter"
        },
        "reset_method": {
          "label": "Метод сброса трафика",
          "placeholder": "Выберите метод сброса",
          "description": "Метод сброса определяет, когда и как будет сброшен трафик пользователя",
          "options": {
            "follow_system": "Следовать системным настройкам",
            "monthly_first": "Первое число каждого месяца",
            "monthly_reset": "Ежемесячно (в день покупки)",
            "no_reset": "Без сброса",
            "yearly_first": "Первое число года",
            "yearly_reset": "Ежегодно (в день покупки)"
          }
        },
        "content": {
          "label": "Описание тарифа",
          "placeholder": "Введите описание тарифа",
          "description": "Поддерживается формат Markdown",
          "preview": "Предпросмотр",
          "preview_button": {
            "show": "Показать предпросмотр",
            "hide": "Скрыть предпросмотр"
          },
          "template": {
            "button": "Использовать шаблон",
            "tooltip": "Использовать стандартный шаблон",
            "content": "## Детали плана\n\n- Трафик: {{transfer}} ГБ\n- Скорость: {{speed}} Мбит/с\n- Устройств: {{devices}}\n\n## Информация о сервисе\n\n1. Сброс трафика: {{reset_method}}\n2. Поддержка всех платформ\n3. Техподдержка 24/7"
          }
        },
        "force_update": {
          "label": "Принудительно обновить планы пользователей"
        },
        "submit": {
          "cancel": "Отмена",
          "submit": "Отправить",
          "submitting": "Отправка...",
          "success": {
            "add": "Тариф успешно добавлен",
            "update": "Тариф успешно обновлен"
          },
          "error": {
            "validation": "Ошибка валидации формы. Пожалуйста, проверьте данные."
          }
        }
      },
      "page": {
        "description": "Здесь вы можете настраивать тарифные планы, включая операции добавления, удаления и редактирования."
      }
    }
  },
  "settings": {
    "node_health": {
      "title": "Состояние соединения",
      "enabled": "Включить проверки по умолчанию",
      "url": "HTTPS-адрес проверки",
      "interval": "Интервал проверки (секунды)",
      "save": "Сохранить общие настройки",
      "saving": "Сохранение…",
      "save_error": "Не удалось сохранить. Повторите попытку.",
      "load_error": "Ошибка загрузки",
      "retry": "Повторить"
    },
    "appearance": {"title":"Внешний вид","sidebar":"Боковое меню","restore":"Показать всё","restore_order":"Сбросить порядок","sort_help":"Перетаскивайте пункты одного уровня. Переключатели управляют видимостью.","move":"Переместить {{name}}","saving":"Сохранение","retry":"Повторить","load_error":"Не удалось загрузить настройки","save_error":"Не удалось сохранить. Повторите попытку.","loading":"Загрузка"},
    "title": "Системные настройки",
    "description": "Управление основными конфигурациями системы, включая сайт, безопасность, подписки, реферальную программу, узлы и уведомления.",
    "server": {
      "title": "Конфигурация сервера",
      "description": "Настройка связи и синхронизации узлов, включая ключи связи, интервалы опроса, балансировку нагрузки и другие параметры.",
      "server_token": {
        "title": "Токен связи",
        "placeholder": "Введите токен связи",
        "description": "Используется для аутентификации между серверами и панелью",
        "generate_tooltip": "Нажмите для генерации случайного токена"
      },
      "server_pull_interval": {
        "title": "Интервал получения данных (Pull)",
        "description": "Частота, с которой узлы запрашивают данные из панели.",
        "placeholder": "Введите интервал"
      },
      "server_push_interval": {
        "title": "Интервал отправки данных (Push)",
        "description": "Частота, с которой узлы отправляют статистику в панель.",
        "placeholder": "Введите интервал"
      },
      "device_limit_mode": {
        "title": "Режим лимита устройств",
        "description": "В мягком режиме несколько узлов с одного IP считаются как одно устройство.",
        "strict": "Строгий режим",
        "relaxed": "Мягкий режим",
        "placeholder": "Выберите режим лимита"
      },
      "server_auto_sort_enable": {
        "title": "Автоматическая сортировка серверов",
        "description": "После первого отчёта и определения страны или региона новый сервер помещается за последним сервером той же группы и региона. Если групп нет, учитывается только регион. Без совпадений сохраняется позиция при создании. Включение не меняет порядок существующих серверов."
      },
      "server_ws_enable": {
        "title": "Включить связь через WebSocket",
        "description": "При включении узлы будут связываться с панелью через WebSocket для снижения задержки.",
        "supported_clients": "Клиенты, поддерживающие WebSocket: Xboard Node"
      },
      "server_ws_url": {
        "title": "URL WebSocket",
        "description": "Адрес WebSocket для подключения узлов. Оставьте пустым, чтобы использовать URL сайта.",
        "placeholder": "Оставьте пустым для URL сайта"
      },
      "reality_scan_targets": {
        "title": "Цели сканирования по умолчанию",
        "description": "Один домен, IP или подсеть на строку, порт необязателен. До 64 записей и 512 адресов. Сохраняется при выходе из поля; пустое поле восстанавливает стандартный список.",
        "placeholder": "www.microsoft.com:443\naws.amazon.com:443"
      },
      "device_ip_exclude": {
        "title": "IP входных серверов",
        "description": "Указывайте только выходные адреса своих серверов переадресации или входных серверов цепочки прокси. Эти адреса не учитываются как устройства; для TCP-соединений Xray с переданным реальным IP учитывается этот IP.",
        "placeholder": "Один IP или подсеть в строке, например 203.0.113.10 или 203.0.113.0/24",
        "errors": {
          "invalid": "Строка {{line}} не является допустимым IP-адресом или подсетью",
          "too_broad": "Строка {{line}}: слишком широкая подсеть, для IPv4 не менее /16, для IPv6 не менее /48",
          "too_many": "Не более {{max}} записей"
        }
      },
      "saving": "Сохранение..."
    },
    "invite": {
      "title": "Реферальная программа",
      "description": "Настройка регистрации по приглашениям и комиссионных вознаграждений.",
      "invite_force": {
        "title": "Принудительное приглашение",
        "description": "Если включено, регистрация доступна только по пригласительному коду."
      },
      "invite_commission": {
        "title": "Процент комиссии",
        "description": "Процент вознаграждения по умолчанию. Можно настроить индивидуально для каждого пользователя.",
        "placeholder": "Введите процент"
      },
      "invite_gen_limit": {
        "title": "Лимит генерации кодов",
        "description": "Максимальное количество кодов, которое может создать пользователь.",
        "placeholder": "Введите лимит"
      },
      "invite_never_expire": {
        "title": "Бессрочные коды",
        "description": "Если включено, коды не сгорают после использования."
      },
      "commission_first_time": {
        "title": "Комиссия только за первую покупку",
        "description": "Вознаграждение начисляется только за первый платеж приглашенного."
      },
      "commission_auto_check": {
        "title": "Автоматическое подтверждение",
        "description": "Комиссия подтверждается автоматически через 3 дня после завершения заказа."
      },
      "commission_withdraw_limit": {
        "title": "Минимальная сумма вывода",
        "description": "Запросы на вывод ниже этой суммы не принимаются.",
        "placeholder": "Введите сумму"
      },
      "commission_withdraw_method": {
        "title": "Методы вывода",
        "description": "Поддерживаемые способы вывода средств, разделяйте запятыми.",
        "placeholder": "Введите методы (напр. USDT, Карта)"
      },
      "withdraw_close": {
        "title": "Отключить вывод средств",
        "description": "Если включено, пользователи не могут запрашивать вывод, комиссия идет сразу на баланс."
      },
      "commission_distribution": {
        "title": "Трехуровневая система",
        "description": "Распределение комиссии по трем уровням пригласителей. Сумма не должна превышать 100%.",
        "l1": "Уровень 1 (%)",
        "l2": "Уровень 2 (%)",
        "l3": "Уровень 3 (%)",
        "placeholder": "Введите процент"
      },
      "saving": "Сохранение..."
    },
    "site": {
      "title": "Настройки сайта",
      "description": "Базовая информация о сайте: название, описание, валюта и другие параметры.",
      "form": {
        "siteName": {
          "label": "Название сайта",
          "placeholder": "Введите название",
          "description": "Отображается в заголовках и интерфейсе."
        },
        "siteDescription": {
          "label": "Описание сайта",
          "placeholder": "Введите описание",
          "description": "Используется для SEO и подзаголовков."
        },
        "siteUrl": {
          "label": "URL сайта",
          "placeholder": "Напр. https://domain.com (без / в конце)",
          "description": "Используется в ссылках, письмах и API."
        },
        "forceHttps": {
          "label": "Принудительный HTTPS",
          "description": "Включите, если сайт за прокси/CDN с HTTPS, но сам сервер работает без него."
        },
        "logo": {
          "label": "Логотип (URL)",
          "placeholder": "URL вашего логотипа",
          "description": "Ссылка на изображение логотипа."
        },
        "subscribeUrl": {
          "label": "URL подписки (кастомный)",
          "placeholder": "Один URL подписки на строку, например https://sub.example.com",
          "description": "По умолчанию используется первый URL. Оставьте пустым для URL сайта."
        },
        "tosUrl": {
          "label": "URL условий (TOS)",
          "placeholder": "Ссылка на правила сервиса",
          "description": "Ссылка на страницу правил использования."
        },
        "stopRegister": {
          "label": "Отключить регистрацию",
          "description": "Запретить регистрацию новых пользователей."
        },
        "ticketMustWaitReply": {
          "label": "Ожидание ответа в тикетах",
          "description": "Пользователь не может отправить новое сообщение, пока админ не ответит."
        },
        "tryOut": {
          "label": "Тестовый период",
          "placeholder": "Отключено",
          "description": "Выберите тариф для триала при регистрации.",
          "duration": {
            "label": "Длительность (часов)",
            "placeholder": "0",
            "description": "Время действия пробного периода."
          }
        },
        "currency": {
          "label": "Код валюты",
          "placeholder": "RUB",
          "description": "Отображаемый код (влияет на весь интерфейс)."
        },
        "currencySymbol": {
          "label": "Символ валюты",
          "placeholder": "₽",
          "description": "Отображаемый символ (влияет на весь интерфейс)."
        }
      }
    },
    "totp": {
      "title": "Двухфакторная аутентификация",
      "description": "Требовать одноразовый код из приложения-аутентификатора при входе в эту учётную запись администратора.",
      "loading": "Загрузка",
      "statusOn": "Статус: включена",
      "statusOff": "Статус: не включена",
      "recoveryRemaining": "Осталось кодов восстановления: {{count}}",
      "enable": "Включить двухфакторную аутентификацию",
      "confirm": "Подтвердить и включить",
      "cancel": "Отмена",
      "disable": "Отключить двухфакторную аутентификацию",
      "regenerate": "Создать новые коды восстановления",
      "scanHint": "Отсканируйте QR-код приложением-аутентификатором или введите ключ вручную.",
      "qrAlt": "QR-код двухфакторной аутентификации",
      "manualKey": "Ключ для ручного ввода",
      "codeLabel": "Код подтверждения",
      "codePlaceholder": "Введите 6-значный код или код восстановления",
      "recoveryTitle": "Коды восстановления",
      "recoveryHint": "Сохраните их в надёжном месте. Коды показываются один раз, каждый действует однократно.",
      "copyRecovery": "Скопировать все коды",
      "copied": "Скопировано",
      "enabledToast": "Двухфакторная аутентификация включена",
      "disabledToast": "Двухфакторная аутентификация отключена"
    },
    "safe": {
      "title": "Безопасность",
      "description": "Настройки защиты: капча, лимиты паролей, белые списки Email и другие параметры.",
      "form": {
        "emailVerify": {
          "label": "Верификация Email",
          "description": "Обязательное подтверждение почты при регистрации."
        },
        "gmailLimit": {
          "label": "Запретить алиасы Gmail",
          "description": "Запретить регистрацию с использованием '+' в адресах Gmail."
        },
        "safeMode": {
          "label": "Безопасный режим домена",
          "description": "Доступ к сайту только через указанный URL (остальные 403)."
        },
        "securePath": {
          "label": "Путь к админ-панели",
          "placeholder": "admin",
          "description": "Изменение стандартного адреса входа в админку."
        },
        "emailWhitelist": {
          "label": "Белый список доменов почты",
          "description": "Разрешить регистрацию только для указанных доменов.",
          "suffixes": {
            "label": "Домены почты",
            "placeholder": "Один домен на строку (напр. gmail.com)",
            "description": "Список разрешенных почтовых сервисов."
          }
        },
        "captcha": {
          "enable": {
            "label": "Включить капчу",
            "description": "Проверка пользователя при регистрации."
          },
          "type": {
            "label": "Тип капчи",
            "description": "Выберите сервис проверки",
            "options": {
              "recaptcha": "Google reCAPTCHA v2",
              "recaptcha-v3": "Google reCAPTCHA v3",
              "turnstile": "Cloudflare Turnstile"
            }
          },
          "recaptcha": {
            "key": {
              "label": "Secret Key",
              "placeholder": "Введите Secret Key",
              "description": "Ваш секретный ключ reCAPTCHA"
            },
            "siteKey": {
              "label": "Site Key",
              "placeholder": "Введите Site Key",
              "description": "Ваш публичный ключ reCAPTCHA"
            }
          },
          "recaptcha_v3": {
            "secretKey": {
              "label": "v3 Secret Key",
              "placeholder": "Введите v3 Secret Key",
              "description": "Секретный ключ v3"
            },
            "siteKey": {
              "label": "v3 Site Key",
              "placeholder": "Введите v3 Site Key",
              "description": "Публичный ключ v3"
            },
            "scoreThreshold": {
              "label": "Порог оценки (Score)",
              "placeholder": "0.5",
              "description": "Порог (0-1), где выше — более вероятно человек."
            }
          },
          "turnstile": {
            "secretKey": {
              "label": "Turnstile Secret Key",
              "placeholder": "Введите секретный ключ",
              "description": "Ключ от Cloudflare Turnstile"
            },
            "siteKey": {
              "label": "Turnstile Site Key",
              "placeholder": "Введите Site Key",
              "description": "Публичный ключ Turnstile"
            }
          }
        },
        "registerLimit": {
          "enable": {
            "label": "Лимит регистраций по IP",
            "description": "Ограничение количества аккаунтов с одного адреса."
          },
          "count": {
            "label": "Кол-во регистраций",
            "placeholder": "Максимум аккаунтов",
            "description": "Сколько раз можно зарегистрироваться с одного IP."
          },
          "expire": {
            "label": "Длительность (мин)",
            "placeholder": "Время блокировки",
            "description": "Через сколько минут лимит сбросится."
          }
        },
        "passwordLimit": {
          "enable": {
            "label": "Лимит попыток входа",
            "description": "Защита от брутфорса паролей."
          },
          "count": {
            "label": "Кол-во попыток",
            "placeholder": "Макс. попыток входа",
            "description": "Допустимое количество неверных паролей."
          },
          "expire": {
            "label": "Время блокировки (мин)",
            "placeholder": "Длительность бана",
            "description": "На сколько минут блокируется вход."
          }
        }
      }
    },
    "subscribe": {
      "protection": {
        "title": "Защита подписок",
        "block_browser": "Запретить доступ из браузера",
        "browser_hint": "Блокировать запросы страниц из браузера. Для прокси-клиентов действуют ограничения клиентов.",
        "brute_force_enabled": "Защита от перебора подписок",
        "brute_hint": "Временно блокировать доступ после нескольких неверных ссылок с одного IP.",
        "brute_force_max_failures": "Максимум ошибок",
        "brute_force_window_minutes": "Период учёта ошибок (минуты)",
        "brute_force_block_minutes": "Время блокировки (минуты)",
        "rate_limit_enabled": "Ограничение частоты запросов",
        "rate_hint": "Лимит запросов на IP. Все адреса подписки используют общий счётчик.",
        "rate_limit_max_requests": "Максимум запросов",
        "rate_limit_window_minutes": "Период учёта запросов (минуты)",
        "whitelist_ips": "Разрешённые IP",
        "ips_placeholder": "IPv4, IPv6 или CIDR — по одному в строке или через запятую",
        "whitelist_users": "Разрешённые пользователи",
        "users_placeholder": "Поиск по почте или номеру пользователя",
        "whitelist_hint": "Любой белый список исключает из защиты подписок. Статус аккаунта и правила клиентов сохраняются.",
        "add_user": "Добавить {{email}}",
        "remove_user": "Убрать {{email}}",
        "missing_user": "Удалённый пользователь #{{id}}",
        "remove": "Убрать",
        "searching": "Поиск…",
        "no_users": "Пользователи не найдены",
        "search_error": "Ошибка поиска. Повторите попытку.",
        "loading": "Загрузка…",
        "retry": "Повторить",
        "load_error": "Не удалось загрузить. Повторите попытку.",
        "save": "Сохранить",
        "saving": "Сохранение…",
        "saved": "Сохранено",
        "save_error": "Не удалось сохранить. Изменения сохранены в форме. Повторите попытку.",
        "errors": {
          "number": "{{field}}: целое число от 1 до {{max}}.",
          "ips": "Не более 256 IP, до 64 символов каждый.",
          "users": "Выберите не более 1000 существующих пользователей."
        },
        "user_rate_limit_enabled": "Частота подписок по пользователю",
        "user_rate_hint": "Запросы одного аккаунта суммируются для всех IP и адресов подписки.",
        "user_rate_limit_max_requests": "Максимум запросов пользователя",
        "user_rate_limit_window_minutes": "Окно пользователя (минуты)",
        "notify_telegram": "Уведомления о защите подписок",
        "notify_hint": "Используются получатели и интервал уведомлений администраторов Telegram Bot. Только новые ограничения.",
        "restrictions": "Активные ограничения",
        "refresh": "Обновить",
        "no_restrictions": "Нет активных ограничений",
        "restrictions_load_error": "Не удалось загрузить ограничения. Обновите список.",
        "save_before_release": "Дождитесь автоматического сохранения настроек перед изменением ограничений.",
        "kind_ip_ban": "Блокировка IP",
        "kind_ip_rate": "Частота по IP",
        "kind_user_rate": "Частота по пользователю",
        "restriction_count": "Запросов за окно",
        "triggered_at": "Начало",
        "expires_at": "Окончание",
        "release_once": "Снять это ограничение",
        "whitelist_permanently": "В белый список навсегда",
        "confirm_release": "Снять это ограничение для {{target}} и сбросить соответствующий счётчик?",
        "confirm_whitelist": "Добавить {{target}} в белый список навсегда и сбросить его счётчики? Защита подписок к нему применяться не будет.",
        "confirm": "Подтвердить",
        "cancel": "Отмена",
        "processing": "Обработка…",
        "release_error": "Ошибка операции. Повторите или обновите список.",
        "load_more": "Загрузить ещё"
      },
      "client_control": {
        "title": "Ограничения клиентов",
        "clients": "Клиенты",
        "rules": "Правила загрузки подписки",
        "mode": "Режим ограничений",
        "modes": {
          "off": "Выключено",
          "whitelist": "Белый список: только выбранные клиенты",
          "blacklist": "Чёрный список: запрет выбранных клиентов"
        },
        "name": "Название клиента",
        "keywords": "Ключевые слова",
        "keywords_placeholder": "По одному в строке; достаточно одного совпадения",
        "selected": "Включить в список",
        "select_named": "Включить {{name}} в список",
        "remove": "Удалить",
        "remove_named": "Удалить {{name}}",
        "add": "Добавить клиент",
        "empty": "Нет правил для клиентов",
        "groups": "Группы без ограничений",
        "groups_placeholder": "Выберите группы без ограничений",
        "missing_group": "Удалённая группа #{{id}}",
        "empty_whitelist": "Белый список пуст. Пользователи без освобождения от ограничений не смогут загрузить подписку.",
        "loading": "Загрузка…",
        "retry": "Повторить",
        "load_error": "Не удалось загрузить правила. Повторите попытку.",
        "saving": "Сохранение…",
        "save_error": "Не удалось сохранить. Введённые данные сохранены; повторите попытку.",
        "errors": {
          "mode": "Выберите допустимый режим.",
          "too_many": "Можно добавить не более 64 клиентов.",
          "name": "В строке {{row}} укажите название длиной до 80 символов.",
          "keywords": "В строке {{row}} укажите от 1 до 32 ключевых слов, каждое до 128 символов."
        }
      },
      "title": "Настройки подписки",
      "description": "Управление форматом ссылок, частотой обновления, статистикой трафика и другими параметрами подписок.",
      "plan_change_enable": {
        "title": "Разрешить смену тарифа",
        "description": "Позволить пользователям переходить на другие планы самостоятельно."
      },
      "reset_traffic_method": {
        "title": "Метод глобального сброса трафика",
        "description": "Настройка сброса по умолчанию (1-е число месяца). Можно переопределить в тарифах.",
        "options": {
          "monthly_first": "1-е число месяца",
          "monthly_reset": "Ежемесячно (день покупки)",
          "no_reset": "Без сброса",
          "yearly_first": "1 января каждого года",
          "yearly_reset": "Раз в год (день покупки)"
        }
      },
      "surplus_enable": {
        "title": "Режим зачета средств",
        "description": "При смене тарифа остаток средств со старого плана пойдет в счет нового."
      },
      "new_order_event": {
        "title": "Событие при новой подписке",
        "description": "Что сделать, когда пользователь покупает новый тариф.",
        "options": {
          "no_action": "Ничего",
          "reset_traffic": "Сбросить использованный трафик"
        }
      },
      "renew_order_event": {
        "title": "Событие при продлении",
        "description": "Что сделать при оплате продления тарифа.",
        "options": {
          "no_action": "Ничего",
          "reset_traffic": "Сбросить использованный трафик"
        }
      },
      "change_order_event": {
        "title": "Событие при смене тарифа",
        "description": "Что сделать при переходе на другой тариф.",
        "options": {
          "no_action": "Ничего",
          "reset_traffic": "Сбросить использованный трафик"
        }
      },
      "subscribe_path": {
        "title": "Путь подписки",
        "description": "Формат ссылки. Изменение повлияет на все существующие ссылки.",
        "current_format": "Текущий формат: {path}/xxxxxxxxxx",
        "restart_tip": "Может потребоваться перезапуск сервиса для применения."
      },
      "basic_settings": "Основные настройки",
      "output_settings": "Настройки вывода",
      "loading": "Загрузка…",
      "load_failed": "Не удалось загрузить. Повторите попытку.",
      "save_failed": "Не удалось сохранить. Повторите попытку.",
      "retry": "Повторить",
      "show_flag_to_server": {"title":"Добавлять флаги стран","description":"Определять страну или регион по названию узла и добавлять флаг в начале. Существующие флаги и неизвестные названия сохраняются."},
      "show_rate_to_server": {"title":"Добавлять множитель трафика","description":"Добавлять действующий множитель в конце названия, например «｜0.8×». При 1× не показывать."},
      "show_info_to_server": {
        "title": "Инфо в подписке (клиент)",
        "description": "Показывать информацию о трафике и сроке действия в приложении пользователя."
      },
      "show_protocol_to_server": {
        "title": "Протокол в имени узла",
        "description": "Добавлять название протокола к узлам (напр. [Hy2] Hong Kong)."
      },
      "saving": "Сохранение...",
      "plan": {
        "title": "Тарифные планы",
        "add": "Добавить",
        "search": "Поиск...",
        "sort": {
          "edit": "Сортировка",
          "save": "Сохранить"
        },
        "columns": {
          "id": "ID",
          "show": "Показ",
          "sell": "Продажа",
          "renew": "Продл.",
          "renew_tooltip": "Можно ли продлевать, если тариф снят с продажи",
          "name": "Название",
          "stats": "Стат.",
          "group": "Группа",
          "price": "Цена",
          "actions": "Действия",
          "edit": "Изм.",
          "delete": "Уд.",
          "delete_confirm": {
            "title": "Удаление",
            "description": "Это действие нельзя отменить. Продолжить?",
            "success": "Удалено"
          },
          "price_period": {
            "monthly": "Месяц",
            "quarterly": "Квартал",
            "half_yearly": "Полгода",
            "yearly": "Год",
            "two_yearly": "2 Года",
            "three_yearly": "3 Года",
            "onetime": "Единоразово",
            "reset_traffic": "Сброс трафика",
            "unit": {
              "month": "/мес",
              "quarter": "/кв",
              "half_year": "/п-года",
              "year": "/год",
              "two_year": "/2г",
              "three_year": "/3г",
              "times": "/раз"
            }
          }
        },
        "form": {
          "add_title": "Добавить тариф",
          "edit_title": "Изменить тариф",
          "name": {
            "label": "Название",
            "placeholder": "Введите название"
          },
          "group": {
            "label": "Группа доступа",
            "placeholder": "Выберите группу",
            "add": "Добавить"
          },
          "transfer": {
            "label": "Трафик",
            "placeholder": "Объем трафика",
            "unit": "ГБ"
          },
          "speed": {
            "label": "Лимит скорости",
            "placeholder": "Макс. скорость",
            "unit": "Мбит/с"
          },
          "price": {
            "title": "Настройка цены",
            "base_price": "Базовая цена",
            "clear": {
              "button": "Очистить",
              "tooltip": "Удалить все цены"
            }
          },
          "device": {
            "label": "Лимит устройств",
            "placeholder": "Без лимита",
            "unit": "шт"
          },
          "capacity": {
            "label": "Лимит емкости",
            "placeholder": "Без лимита",
            "unit": "чел"
          },
          "reset_method": {
            "label": "Способ сброса",
            "placeholder": "Выберите способ",
            "description": "Как будет считаться трафик для этого тарифа.",
            "options": {
              "follow_system": "Как в системе",
              "monthly_first": "1-е число месяца",
              "monthly_reset": "День покупки",
              "no_reset": "Без сброса",
              "yearly_first": "1 января",
              "yearly_reset": "Раз в год"
            }
          },
          "content": {
            "label": "Описание тарифа",
            "placeholder": "Введите описание...",
            "description": "Markdown разрешен. Списки, жирный текст и т.д.",
            "preview": "Предпросмотр",
            "preview_button": {
              "show": "Показать",
              "hide": "Скрыть"
            },
            "template": {
              "button": "Шаблон",
              "tooltip": "Вставить стандартное описание",
              "content": "## Особенности тарифа\n• Высокая скорость и стабильность\n• Поддержка нескольких устройств\n• Регулярный сброс трафика\n\n## Инструкции\n1. Поддержка: iOS, Android, Windows, macOS\n2. Техподдержка 24/7\n3. Автообновление трафика\n\n## Важно\n- Запрещен абуз\n- Соблюдайте законодательство\n- Можно сменить тариф в любой момент"
            }
          },
          "force_update": {
            "label": "Принудительно обновить у всех"
          },
          "submit": {
            "submitting": "Сохранение...",
            "submit": "Применить",
            "cancel": "Отмена",
            "success": {
              "add": "Тариф добавлен",
              "update": "Тариф обновлен"
            }
          }
        },
        "page": {
          "description": "Настройка тарифных планов: лимиты, цены и видимость."
        }
      }
    },
    "email": {
      "title": "Настройки почты",
      "description": "Настройка SMTP для отправки кодов подтверждения, восстановления пароля и системных уведомлений.",
      "tab_settings": "Настройки",
      "tab_templates": "Шаблоны",
      "email_host": {
        "title": "SMTP Сервер",
        "description": "Адрес сервера, напр. smtp.gmail.com"
      },
      "email_port": {
        "title": "SMTP Порт",
        "description": "Обычно: 465 (SSL) или 587 (TLS)"
      },
      "email_username": {
        "title": "Имя пользователя SMTP",
        "description": "Ваш Email или логин"
      },
      "email_password": {
        "title": "Пароль SMTP",
        "description": "Пароль приложения или основной пароль"
      },
      "email_encryption": {
        "title": "Шифрование",
        "description": "Способ защиты соединения",
        "none": "Нет",
        "ssl": "SSL/TLS",
        "tls": "STARTTLS"
      },
      "email_from": {
        "title": "Email отправителя",
        "description": "Будет отображаться в заголовке письма"
      },
      "email_from_name": {
        "title": "Имя отправителя",
        "description": "Напр. 'Администрация Xboard'"
      },
      "email_template": {
        "title": "Шаблон письма",
        "description": "Выберите стиль оформления уведомлений",
        "placeholder": "Выберите шаблон"
      },
      "remind_mail": {
        "title": "Email напоминания",
        "description": "Уведомлять пользователей об окончании трафика или срока действия."
      },
      "test": {
        "title": "Тестовое письмо",
        "sending": "Отправка...",
        "description": "Проверить настройки, отправив письмо себе",
        "success": "Письмо успешно отправлено",
        "error": "Ошибка при отправке теста"
      }
    },
    "telegram": {
      "title": "Настройки Telegram",
      "description": "Связь с Telegram ботом: уведомления, привязка аккаунтов и команды.",
      "bot_token": {
        "title": "Токен бота",
        "description": "Получите у @BotFather.",
        "placeholder": "0000000000:xxxxxxxxx_xxxxxxxxxxxxxxx"
      },
      "webhook_url": {
        "title": "Webhook Base URL",
        "description": "Оставьте пустым для URL сайта. Система сама добавит нужные пути.",
        "docs": "Документация Telegram Webhook",
        "placeholder": "https://example.com"
      },
      "webhook": {
        "title": "Установить Webhook",
        "description": "Без этой настройки бот не будет получать сообщения от пользователей.",
        "button": "Настройка в 1 клик",
        "setting": "Настройка...",
        "success": "Webhook установлен успешно",
        "target_default": "Используется основной URL сайта.",
        "target_custom": "Используется кастомный URL: {{url}}",
        "debug": {
          "title": "Отладка Webhook",
          "success": "Успех",
          "url": "Полный URL",
          "baseUrl": "Base URL"
        }
      },
      "bot_enable": {
        "title": "Гайд по привязке",
        "description": "Показывать инструкцию по подключению Telegram на стороне пользователя."
      },
      "discuss_link": {
        "title": "Ссылка на группу/чат",
        "description": "Будет отображаться в личном кабинете.",
        "placeholder": "https://t.me/your_chat"
      }
    },
    "app": {
      "title": "Настройки приложений",
      "description": "Конфигурация ссылок на скачивание и версий клиентов для различных платформ.",
      "common": {
        "placeholder": "Введите значение"
      },
      "windows": {
        "version": {
          "title": "Версия Windows",
          "description": "Текущая версия клиента для Windows"
        },
        "download": {
          "title": "Ссылка скачивания Windows",
          "description": "URL для загрузки .exe файла"
        }
      },
      "macos": {
        "version": {
          "title": "Версия macOS",
          "description": "Текущая версия клиента для macOS"
        },
        "download": {
          "title": "Ссылка скачивания macOS",
          "description": "URL для загрузки .dmg файла"
        }
      },
      "android": {
        "version": {
          "title": "Версия Android",
          "description": "Текущая версия .apk"
        },
        "download": {
          "title": "Ссылка скачивания Android",
          "description": "URL для загрузки APK"
        }
      }
    },
    "common": {
      "saving": "Сохранение...",
      "save_success": "Автоматически сохранено",
      "placeholder": "Текст...",
      "autoSaved": "Сохранено"
    },
    "subscribe_template": {
      "title": "Шаблоны подписки",
      "description": "Конфигурация форматов выдачи для различных клиентов.",
      "singbox": {
        "title": "Шаблон Sing-box",
        "description": "Формат конфига для Sing-box"
      },
      "clash": {
        "title": "Шаблон Clash",
        "description": "Формат конфига для Clash"
      },
      "clashmeta": {
        "title": "Шаблон Clash Meta",
        "description": "Формат конфига для Clash Meta (Mihomo)"
      },
      "stash": {
        "title": "Шаблон Stash",
        "description": "Формат конфига для Stash (iOS)"
      },
      "surge": {
        "title": "Шаблон Surge",
        "description": "Формат конфига для Surge"
      },
      "surfboard": {
        "title": "Шаблон Surfboard",
        "description": "Формат конфига для Surfboard"
      }
    },
    "email_template": {
      "title": "Шаблоны писем",
      "description": "Настройка шаблонов системных email-уведомлений",
      "customized": "Изменен",
      "subject": "Тема",
      "subject_placeholder": "Введите тему письма, поддерживаются {{name}} и другие переменные",
      "content": "Содержимое шаблона (HTML)",
      "preview": "Предварительный просмотр",
      "override_hint": "Сохранение переопределит системный шаблон по умолчанию. Нажмите «По умолчанию», чтобы восстановить шаблон темы.",
      "placeholders": "Доступные переменные",
      "var_name": "Переменная",
      "var_desc": "Описание",
      "var_sample": "Пример",
      "required": "Обяз.",
      "insert": "Вставить",
      "placeholder_hint": "* обязательные переменные. Нажмите для вставки в конец содержимого.",
      "click_to_insert": "Нажмите для вставки",
      "save": "Сохранить",
      "save_success": "Шаблон сохранён",
      "save_before_test": "Сохраните изменения перед отправкой тестового письма",
      "send_test": "Тестовое письмо",
      "test_dialog_title": "Отправить тестовое письмо",
      "test_dialog_description": "Введите email получателя. Оставьте пустым для отправки на ваш admin email.",
      "test_email_placeholder": "Email получателя (пусто = текущий аккаунт)",
      "sending": "Отправка...",
      "test_success": "Тестовое письмо отправлено",
      "reset": "По умолчанию",
      "reset_title": "Сброс шаблона",
      "reset_description": "Вы уверены, что хотите сбросить шаблон? Ваши изменения будут удалены.",
      "reset_confirm": "Подтвердить",
      "reset_success": "Шаблон сброшен",
      "unsaved": "Есть несохранённые изменения",
      "discard_title": "Несохранённые изменения",
      "discard_description": "В этом шаблоне есть несохранённые изменения. При переключении вкладки они будут потеряны.",
      "discard_confirm": "Отменить изменения",
      "cancel": "Отмена"
    }
  },
  "notice": {
    "title": "Управление объявлениями",
    "description": "Здесь вы можете настраивать объявления, включая добавление, удаление, редактирование и другие операции.",
    "table": {
      "columns": {
        "id": "ID",
        "show": "Статус показа",
        "title": "Заголовок",
        "actions": "Действия"
      },
      "toolbar": {
        "search": "Поиск по заголовку...",
        "reset": "Сброс",
        "sort": {
          "edit": "Изменить порядок",
          "save": "Сохранить порядок"
        }
      },
      "actions": {
        "edit": "Изменить",
        "delete": {
          "title": "Подтверждение удаления",
          "description": "Вы уверены, что хотите удалить это объявление? Это действие нельзя отменить.",
          "success": "Успешно удалено"
        }
      }
    },
    "form": {
      "add": {
        "title": "Добавить объявление",
        "button": "Добавить объявление"
      },
      "edit": {
        "title": "Изменить объявление"
      },
      "fields": {
        "title": {
          "label": "Заголовок",
          "placeholder": "Введите заголовок объявления"
        },
        "content": {
          "label": "Содержимое"
        },
        "img_url": {
          "label": "Фоновое изображение",
          "placeholder": "Введите URL фонового изображения"
        },
        "show": {
          "label": "Показывать"
        },
        "tags": {
          "label": "Теги",
          "placeholder": "Нажмите Enter для добавления тегов"
        }
      },
      "buttons": {
        "cancel": "Отмена",
        "submit": "Отправить",
        "success": "Успешно отправлено"
      }
    }
  },
  "group": {
    "title": "Группы прав",
    "description": "Управление всеми группами прав, включая добавление, удаление и редактирование.",
    "columns": {
      "id": "ID группы",
      "name": "Название группы",
      "usersCount": "Пользователей",
      "serverCount": "Узлов",
      "actions": "Действия"
    },
    "form": {
      "add": "Добавить группу",
      "edit": "Изменить группу",
      "create": "Создать группу",
      "update": "Обновить",
      "name": "Название группы",
      "namePlaceholder": "Введите название группы",
      "nameDescription": "Название группы используется для идентификации. Рекомендуется использовать понятные имена.",
      "cancel": "Отмена",
      "editDescription": "Изменение информации о группе. Изменения вступят в силу немедленно.",
      "createDescription": "Создайте новую группу прав для разграничения доступа пользователей."
    },
    "toolbar": {
      "searchPlaceholder": "Поиск групп...",
      "reset": "Сбросить",
      "sort": {
        "tip": "Перетаскивайте группы для сортировки, затем нажмите сохранить",
        "edit": "Редактировать порядок",
        "save": "Сохранить порядок",
        "success": "Порядок сортировки сохранён"
      }
    },
    "messages": {
      "deleteConfirm": "Подтверждение удаления",
      "deleteDescription": "Это действие навсегда удалит эту группу прав. Продолжить?",
      "deleteButton": "Удалить",
      "createSuccess": "Создано успешно",
      "updateSuccess": "Обновлено успешно",
      "nameValidation": {
        "min": "Название должно содержать минимум 2 символа",
        "max": "Название не может превышать 50 символов",
        "pattern": "Название может содержать только буквы, цифры, китайские иероглифы, подчеркивания и дефисы"
      }
    }
  },
  "auth": {
    "signIn": {
      "title": "Вход",
      "description": "Введите свой email и пароль для входа",
      "email": "Email",
      "emailPlaceholder": "name@example.com",
      "password": "Пароль",
      "passwordPlaceholder": "Введите ваш пароль",
      "forgotPassword": "Забыли пароль?",
      "submit": "Войти",
      "rememberMe": "Запомнить меня",
      "resetPassword": {
        "title": "Сброс пароля",
        "description": "Выполните следующую команду в директории сайта, чтобы сбросить пароль",
        "command": "php artisan reset:password admin-email"
      },
      "totp": {
        "title": "Двухфакторная аутентификация",
        "description": "Введите код из приложения-аутентификатора или один из кодов восстановления.",
        "code": "Код подтверждения",
        "codePlaceholder": "Введите 6-значный код или код восстановления",
        "submit": "Подтвердить и войти",
        "back": "Вернуться к входу",
        "failed": "Проверка не пройдена, попробуйте снова"
      },
      "validation": {
        "emailRequired": "Пожалуйста, введите адрес электронной почты",
        "emailInvalid": "Пожалуйста, введите корректный адрес электронной почты",
        "passwordRequired": "Пожалуйста, введите пароль",
        "passwordLength": "Пароль должен содержать не менее 7 символов"
      }
    }
  },
  "traffic": {
    "trafficRecord": {
      "title": "Записи использования трафика",
      "time": "Время",
      "upload": "Отдача",
      "download": "Загрузка",
      "rate": "Множитель",
      "total": "Всего",
      "noRecords": "Записей не найдено",
      "perPage": "Показывать по",
      "records": "записей",
      "page": "Страница {{current}} / {{total}}",
      "multiplier": "{{value}}x"
    }
  },
  "payment": {
    "title": "Способы оплаты",
    "description": "Настройка способов оплаты, включая Alipay, WeChat Pay и др.",
    "table": {
      "columns": {
        "id": "ID",
        "enable": "Включено",
        "name": "Название",
        "payment": "Шлюз",
        "notify_url": "URL уведомления",
        "notify_url_tooltip": "Шлюз будет отправлять уведомления на этот адрес. Убедитесь, что он доступен через ваш брандмауэр.",
        "actions": "Действия"
      },
      "actions": {
        "edit": "Изменить",
        "delete": {
          "title": "Подтверждение удаления",
          "description": "Вы уверены, что хотите удалить этот способ оплаты? Это действие нельзя отменить.",
          "success": "Успешно удалено"
        }
      },
      "toolbar": {
        "search": "Поиск способов оплаты...",
        "reset": "Сбросить",
        "sort": {
          "hint": "Перетаскивайте для сортировки, затем нажмите сохранить",
          "save": "Сохранить порядок",
          "edit": "Изменить порядок"
        }
      }
    },
    "form": {
      "add": {
        "button": "Добавить способ оплаты",
        "title": "Добавить способ оплаты"
      },
      "edit": {
        "title": "Изменить способ оплаты"
      },
      "fields": {
        "name": {
          "label": "Отображаемое название",
          "placeholder": "Введите название",
          "description": "Используется для отображения пользователям"
        },
        "icon": {
          "label": "URL иконки",
          "placeholder": "https://example.com/icon.svg",
          "description": "URL иконки для отображения"
        },
        "notify_domain": {
          "label": "Домен уведомлений",
          "placeholder": "https://example.com",
          "description": "Домен для получения уведомлений от шлюза"
        },
        "handling_fee_percent": {
          "label": "Комиссия (%)",
          "placeholder": "0-100"
        },
        "handling_fee_fixed": {
          "label": "Фиксированная комиссия",
          "placeholder": "0"
        },
        "payment": {
          "label": "Платежный шлюз",
          "placeholder": "Выберите шлюз",
          "description": "Выберите технический шлюз для обработки оплаты"
        }
      },
      "validation": {
        "name": {
          "min": "Название должно содержать минимум 2 символа",
          "max": "Название не может превышать 30 символов"
        },
        "notify_domain": {
          "url": "Пожалуйста, введите корректный URL"
        },
        "payment": {
          "required": "Пожалуйста, выберите платежный шлюз"
        }
      },
      "buttons": {
        "cancel": "Отмена",
        "submit": "Отправить"
      },
      "sections": {
        "payment_config": "Конфигурация шлюза"
      },
      "messages": {
        "success": "Успешно сохранено"
      }
    }
  },
  "server": {
    "realityScan": {
      "certChain": "Цепочка сертификатов",
      "location": "География IP",
      "pageStatus": "Статус страницы",
      "unknown": "Неизвестно",
      "notProvided": "Нет данных",
      "cdnNotDetected": "Признаки не найдены",
      "detailsUpgrade": "Для CDN и статуса страницы требуется Node v2.14.0 или новее.",
      "page": {
        "normal": "OK", "redirect": "Перенаправление", "unchanged": "Без изменений",
        "authentication": "Нужна авторизация", "forbidden": "Доступ запрещён", "notFound": "Не найдена",
        "rateLimited": "Слишком много запросов", "restricted": "Доступ ограничен", "serverError": "Ошибка сервера",
        "clientError": "Ошибка запроса", "information": "Информация", "timeout": "Тайм-аут ответа",
        "failed": "Ошибка запроса", "not_checked": "Не проверено"
      },
      "close": "Закрыть",
      "scanCurrent": "Проверить текущую цель",
      "scanTargets": "Сканировать цели",
      "title": "Проверка целей Reality",
      "targets": "Цели",
      "placeholder": "Домены, IP или CIDR через запятую или с новой строки. Пустое поле — готовый список.",
      "scan": "Начать проверку",
      "scanning": "Проверка…",
      "pending": "Ожидание узла",
      "running": "Узел выполняет проверку",
      "requestFailed": "Не удалось получить результаты. Повторите попытку.",
      "bindMachine": "Сначала привяжите узел к серверу.",
      "currentRequired": "Укажите домен и допустимый порт.",
      "currentDestinationRequired": "Укажите адрес назначения и домен рукопожатия.",
      "expired": "Результат устарел. Запустите проверку снова.",
      "retry": "Получить снова",
      "applied": "{{target}} подставлен. Сохраните узел.",
      "empty": "Подходящие домены не найдены.",
      "available": "Доступна",
      "unavailable": "Недоступна",
      "use": "Использовать",
      "curve": "Обмен ключами",
      "certificate": "Сертификат",
      "valid": "Действителен",
      "invalid": "Ошибка",
      "expires": "Срок действия",
      "certDomain": "Домен сертификата",
      "reason": {
        "dns_failed": "Ошибка DNS.",
        "private_target": "Локальные, частные и зарезервированные адреса запрещены.",
        "connection_failed": "Не удалось подключиться к порту.",
        "tls_failed": "Ошибка или тайм-аут TLS.",
        "no_certificate": "Сертификат не получен.",
        "no_domain": "В сертификате нет подходящего домена без маски.",
        "discovered": "Домен найден, но цепочка сертификата не прошла проверку.",
        "certificate_invalid": "Сертификат недоверенный, просрочен или не соответствует домену.",
        "tls13_required": "Цель не поддерживает TLS 1.3.",
        "h2_required": "HTTP/2 не согласован.",
        "x25519_required": "Обмен ключами X25519 не использован.",
        "invalid_target": "Неверный формат цели.",
        "invalid_cidr": "Неверный CIDR или более 256 адресов.",
        "too_many_targets": "Допускается не более 512 адресов за проверку.",
        "timeout": "Время ожидания истекло. Уменьшите число целей.",
        "node_restarted": "Узел перезапущен или отключён. Повторите проверку.",
        "unknown": "Проверка не пройдена."
      }
    },
    "visibility": { "hide": "Скрыть", "show": "Показать", "hidden": "Скрыт", "failed": "Не удалось изменить видимость. Повторите попытку.", "refreshFailed": "Видимость изменена. Обновите список." },
    "portConflictWarning": "Возможен конфликт портов",
    "title": "Конфигурация узла",
    "description": "Настройка параметров связи и синхронизации узла, включая ключ связи, интервал опроса, балансировку нагрузки и другие расширенные параметры.",
    "server_token": {
      "title": "Ключ связи",
      "description": "Ключ для связи между Xboard и узлами для предотвращения несанкционированного доступа к данным.",
      "placeholder": "Пожалуйста, введите ключ связи"
    },
    "server_pull_interval": {
      "title": "Интервал опроса Pull-действий",
      "description": "Частота получения данных узлом из панели.",
      "placeholder": "Пожалуйста, введите интервал получения"
    },
    "server_push_interval": {
      "title": "Интервал опроса Push-действий",
      "description": "Частота отправки данных узлом в панель.",
      "placeholder": "Пожалуйста, введите интервал отправки"
    },
    "device_limit_mode": {
      "title": "Режим ограничения устройств",
      "description": "В мягком режиме несколько узлов с одного IP-адреса считаются за одно устройство.",
      "strict": "Строгий режим",
      "relaxed": "Мягкий режим",
      "placeholder": "Пожалуйста, выберите режим ограничения"
    },
    "saving": "Сохранение...",
    "manage": {
      "title": "Управление узлами",
      "description": "Управление всеми узлами, включая добавление, удаление, редактирование и другие операции.",
      "filtered_by_server": "Сейчас показаны узлы сервера {{server}} (SID:{{id}})",
      "filtered_by_server_description": "Новые узлы здесь можно сразу привязать к текущему серверу.",
      "add_node_to_server": "Добавить узел на этот сервер",
      "clear_server_filter": "Сбросить фильтр сервера"
    },
    "columns": {
      "sort": "Сортировка",
      "nodeId": "ID узла",
      "show": "Показ",
      "node": "Узел",
      "address": "Адрес",
      "onlineUsers": {
        "title": "Пользователи онлайн",
        "tooltip": "Количество пользователей онлайн на основе частоты отчетов сервера"
      },
      "rate": {
        "title": "Множитель",
        "tooltip": "Множитель тарификации трафика"
      },
      "usage": {"title":"Использование узлов","tooltip":"Отправленные и полученные данные без множителя. Транзит учитывается у выходного узла, у входного — только прямой трафик."},
      "capacity": {"title":"Трафик / лимит","tooltip":"Прежние правила учёта и сброса, включая пересылку на входном узле. Без множителя."},
      "traffic": {
        "title": "Трафик",
        "tooltip": "Использование трафика узлом",
        "total": "Всего",
        "used": "Использовано",
        "percentage": "Использование"
      },
      "groups": {
        "title": "Группы доступа",
        "tooltip": "Группы, которые могут подписаться на этот узел",
        "empty": "--",
        "more": "Показать все группы доступа ({{total}})"
      },
      "loadStatus": {
        "title": "Загрузка",
        "tooltip": "Использование ресурсов сервера",
        "noData": "Нет данных",
        "details": "Детали загрузки системы",
        "cpu": "Загрузка CPU",
        "memory": "Память",
        "swap": "Swap",
        "disk": "Диск",
        "lastUpdate": "Последнее обновление",
        "metrics": {
          "title": "Метрики",
          "uptime": "Аптайм",
          "conns": "Соединения",
          "speed": "Скорость"
        }
      },
      "customId": "Кастомный ID",
      "originalId": "Оригинальный ID",
      "type": "Тип",
      "actions": "Действия",
      "copyAddress": "Копировать адрес",
      "internalPort": "Внутр. порт",
      "deployment": {
        "title": "Развёртывание",
        "tooltip": "Показывает, работает ли узел автономно или размещён на сервере, и позволяет менять это прямо в списке.",
        "standalone": "Автономно",
        "standalone_row_hint": "Без привязки к серверу",
        "standalone_description": "Этот узел работает независимо и не требует серверного хостинга.",
        "online": "Сервер онлайн",
        "offline": "Сервер офлайн",
        "inactive": "Сервер неактивен",
        "disabled": "Узел выключен",
        "enabled": "Включить на сервере",
        "enabled_description": "Только включённые узлы будут запускаться и синхронизироваться выбранным сервером.",
        "enabled_standalone_description": "Для автономных узлов серверное состояние включения не требуется.",
        "bind_success": "Размещено на {{server}}",
        "standalone_success": "Переключено в автономное развёртывание",
        "update_success": "Развёртывание обновлено",
        "update_error": "Не удалось обновить развёртывание"
      },
      "status": {
        "0": "Не запущен",
        "1": "Не используется или ошибка",
        "2": "Работает нормально"
      },
      "childNode": "Дочерний узел",
      "actions_dropdown": {
        "edit": "Редактировать",
        "copy": "Копировать",
        "delete": {
          "title": "Подтверждение удаления",
          "description": "Это действие навсегда удалит этот узел и не может быть отменено. Вы уверены, что хотите продолжить?",
          "confirm": "Удалить"
        },
        "copy_success": "Скопировано успешно",
        "delete_success": "Удалено успешно"
      }
    },
    "toolbar": {
      "unify_reality": {
        "loading_pools": "Загрузка связанных пулов…",
        "scope_failed": "Не удалось загрузить связанные пулы. Повторите попытку.",
        "reload_pools": "Обновить список пулов",
        "related_pools": "Пулы для синхронизации:",
        "linked_success": "Параметры объединены для {{count}} узлов и {{pools}} пулов",
        "generate_short_failed": "Не удалось создать Short ID. Повторите попытку.",
        "mode": "Способ объединения",
        "node_mode": "Использовать выбранный узел",
        "manual_mode": "Ввести вручную",
        "source": "Образец узла",
        "menu": "Объединить параметры Reality",
        "description": "Установить общие ключи, короткий ID, имя и порт рукопожатия для {{count}} выбранных узлов. Клиентам со старыми параметрами нужно обновить подписку.",
        "server_name": "Имя рукопожатия",
        "server_port": "Порт рукопожатия",
        "cancel": "Отмена",
        "confirm": "Подтвердить",
        "pending": "Применение",
        "success": "Параметры Reality объединены для {{count}} узлов",
        "failed": "Не удалось объединить параметры Reality. Повторите попытку."
      },
      "search": "Поиск узлов...",
      "country": "Регион",
      "country_unknown": "Не определено",
      "type": "Тип",
      "server": "Сервер",
      "server_search": "Поиск серверов...",
      "server_empty": "Серверы не найдены",
      "reset": "Сброс",
      "actions": "Действия",
      "sort": {
        "tip": "Перетаскивайте узлы для сортировки, затем нажмите сохранить",
        "batch": "Групповая сортировка",
        "selected": "Выбрано узлов: {{count}}",
        "top": "В начало",
        "up": "На строку выше",
        "down": "На строку ниже",
        "bottom": "В конец",
        "clear": "Снять выделение",
        "error": "Не удалось сохранить или обновить порядок. Повторите попытку.",
        "edit": "Редактировать порядок",
        "save": "Сохранить порядок",
        "success": "Порядок сортировки сохранён"
      },
      "batch_delete": {
        "menu": "Удалить узлы",
        "button": "Удалить {{count}} шт.",
        "title": "Подтверждение удаления",
        "description": "Вы уверены, что хотите удалить {{count}} узлов? Это действие необратимо.",
        "confirm": "Подтвердить удаление"
      },
      "batch_delete_success": "Успешно удалено {{count}} узлов",
      "batch_delete_error": "Ошибка пакетного удаления",
      "batch_show": {
        "menu": "Показать узлы"
      },
      "batch_show_success": "Успешно показано {{count}} узлов",
      "batch_show_error": "Ошибка пакетного показа",
      "batch_hide": {
        "menu": "Скрыть узлы"
      },
      "batch_hide_success": "Успешно скрыто {{count}} узлов",
      "batch_hide_error": "Ошибка пакетного скрытия",
      "batch_enable": {
        "menu": "Включить узлы"
      },
      "batch_enable_success": "Успешно включено {{count}} узлов",
      "batch_enable_error": "Ошибка пакетного включения",
      "batch_disable": {
        "menu": "Отключить узлы"
      },
      "batch_disable_success": "Успешно отключено {{count}} узлов",
      "batch_disable_error": "Ошибка пакетного отключения",
      "batch_reset_traffic": {
        "menu": "Сбросить трафик",
        "button": "Сбросить {{count}} шт.",
        "title": "Подтверждение сброса трафика",
        "description": "Вы уверены, что хотите сбросить трафик {{count}} узлов? Это обнулит трафик и снимет блокировки.",
        "confirm": "Подтвердить сброс"
      },
      "batch_reset_traffic_success": "Успешно сброшен трафик {{count}} узлов",
      "batch_reset_traffic_error": "Ошибка пакетного сброса трафика"
    },
    "form": {
      "add_node": "Добавить узел",
      "edit_node": "Изменить узел",
      "new_node": "Новый узел",
      "type": {
        "placeholder": "Выберите тип протокола",
        "select_prompt": "Сначала выберите тип протокола",
        "select_error": "Пожалуйста, выберите тип протокола"
      },
      "name": {
        "label": "Название узла",
        "placeholder": "Пожалуйста, введите название узла",
        "error": "Пожалуйста, введите корректное название"
      },
      "rate": {
        "label": "Базовый множитель",
        "effective_label": "Действующий множитель (входной узел)",
        "independent_label": "Независимый множитель",
        "error": "Множитель обязателен",
        "error_numeric": "Множитель должен быть числом",
        "error_gte_zero": "Множитель должен быть больше или равен 0",
        "child_node_tooltip": "Множитель дочернего узла наследуется от родительского и не может быть изменен отдельно",
        "child_node_note": "Множитель наследуется от родителя"
      },
      "dynamic_rate": {
        "section_title": "Конфигурация динамического множителя",
        "enable_label": "Включить дин. множитель",
        "enable_description": "Установите разные множители в зависимости от времени суток",
        "rules_label": "Правила периодов",
        "add_rule": "Добавить правило",
        "rule_title": "Правило {{index}}",
        "start_time": "Время начала",
        "end_time": "Время окончания",
        "multiplier": "Множитель",
        "no_rules": "Правил пока нет, нажмите кнопку выше, чтобы добавить",
        "start_time_error": "Время начала обязательно",
        "end_time_error": "Время окончания обязательно",
        "multiplier_error": "Множитель обязателен",
        "multiplier_error_numeric": "Множитель должен быть числом",
        "multiplier_error_gte_zero": "Множитель должен быть больше или равен 0"
      },
      "code": {
        "label": "Кастомный ID узла",
        "optional": "(Опционально)",
        "placeholder": "Введите кастомный ID узла"
      },
      "tags": {
        "label": "Теги узла",
        "placeholder": "Нажмите Enter для добавления"
      },
      "groups": {
        "label": "Группы доступа",
        "add": "Добавить группу",
        "placeholder": "Пожалуйста, выберите группы",
        "empty": "Ничего не найдено"
      },
      "machine": {
        "label": "Привязка к серверу",
        "placeholder": "Выберите сервер (необязательно)",
        "none": "Автономная",
        "enabled_hint": "Управлять ли этим узлом с сервера"
      },
      "host": {
        "label": "Адрес узла",
        "placeholder": "Введите домен или IP",
        "error": "Адрес узла обязателен"
      },
      "port": {
        "label": "Порт подключения",
        "placeholder": "Порт для пользователей",
        "tooltip": "Порт, к которому фактически подключаются пользователи. Если используется транзит или туннель, этот порт может отличаться от порта, который сервер слушает на самом деле.",
        "sync": "Синхронизировать с портом сервера",
        "error": "Порт подключения обязателен"
      },
      "server_port": {
        "label": "Порт сервера",
        "placeholder": "Введите порт сервера",
        "error": "Порт сервера обязателен",
        "tooltip": "Фактический порт прослушивания на сервере.",
        "sync": "Синхронизировать с портом сервера"
      },
      "parent": {
        "label": "Родительский узел",
        "placeholder": "Выберите родителя",
        "none": "Нет"
      },
      "proxy_protocol": {
        "label": "Принимать PROXY protocol"
      },
      "auto_firewall": {
        "label": "Автоматическое управление межсетевым экраном",
        "disabled_hint": "При отключении восстанавливаются прежние правила. Списки IP больше не применяются системным межсетевым экраном."
      },
      "source_policy": {
        "label": "Ограничения IP источников",
        "disabled": "Отключено",
        "blacklist": "Чёрный список",
        "whitelist": "Белый список",
        "block_ips": "Заблокированные IP",
        "allow_ips": "Разрешённые IP",
        "exceptions": "Исключения для IP Китая",
        "block_cn": "Блокировать IP материкового Китая",
        "placeholder": "Введите IP и нажмите Enter",
        "invalid_ip": "Введите отдельный адрес IPv4 или IPv6",
        "max_ips": "Не более 128 IP в каждом списке",
        "empty_whitelist": "Добавьте хотя бы один IP в белый список",
        "connections": "Подключения",
        "save": "Сохранить"
      },
      "route": {
        "label": "Группы маршрутов",
        "placeholder": "Выберите маршруты",
        "empty": "Ничего не найдено"
      },
      "submit": "Отправить",
      "cancel": "Отмена",
      "success": "Успешно отправлено"
    },
    "dynamic_form": {
      "multiplex": {
        "enabled": {
          "label": "Multiplex",
          "description": "Передача нескольких потоков через одно TCP-соединение"
        },
        "protocol": {
          "label": "Протокол"
        },
        "max_connections": {
          "label": "Макс. соединений"
        },
        "min_streams": {
          "label": "Мин. потоков"
        },
        "padding": {
          "label": "Включить Padding"
        },
        "brutal": {
          "enabled": {
            "label": "TCP Brutal"
          },
          "up_mbps": {
            "label": "Upload Bandwidth"
          },
          "down_mbps": {
            "label": "Download Bandwidth"
          },
          "description": "TCP Brutal — двусторонний алгоритм ускорения. Установите пропускную способность 80%-90% от реальной. BBR будет отключён при включении."
        }
      },
      "ech": {
        "description": "Включает Encrypted Client Hello для поддерживаемых TLS-клиентов. Если конфигурация пуста, будет выполнен DNS-запрос.",
        "generate": "Авто-генерация ECH ключей",
        "config": {
          "label": "ECH Config (PEM)",
          "placeholder": "Вставьте конфигурацию ECH в формате PEM, по одной строке на строку",
          "description": "Если пусто, sing-box попробует загрузить конфигурацию ECH из DNS."
        },
        "config_path": {
          "label": "Путь к конфигу ECH",
          "placeholder": "/etc/sing-box/ech.pem",
          "description": "Путь к файлу конфигурации ECH в формате PEM."
        },
        "query_server_name": {
          "label": "Имя сервера для запроса ECH",
          "placeholder": "Необязательная замена домена для HTTPS-запроса",
          "description": "Переопределяет домен для ECH HTTPS-запросов. По умолчанию используется server_name."
        },
        "key": {
          "label": "ECH Key",
          "placeholder": "Вставьте содержимое ECH key, если это требуется бэкенду",
          "description": "Необязательное содержимое ECH key для бэкенда."
        },
        "key_path": {
          "label": "Путь к ECH key",
          "placeholder": "/etc/sing-box/ech.key",
          "description": "Путь к файлу ECH key, если это требуется бэкенду."
        }
      },
      "anytls": {
        "tls": {
          "server_name": {
            "label": "Server Name Indication (SNI)",
            "placeholder": "Used for certificate verification when domain differs from node address"
          },
          "allow_insecure": "Allow Insecure"
        },
        "padding_scheme": {
          "description": "Each line represents a padding rule, format: stop=8, 0=30-30",
          "label": "Padding Scheme",
          "placeholder": "Enter padding rules",
          "use_default": "Use Default Scheme",
          "edit_btn": "Edit Padding Scheme",
          "configured": "{{count}} rules configured",
          "not_configured": "Not configured"
        }
      },
      "shadowsocks": {
        "cipher": {
          "label": "Encryption Method",
          "placeholder": "Select encryption method",
          "search_placeholder": "Search or enter custom encryption method...",
          "description": "Select preset encryption method or enter custom encryption method",
          "preset_group": "Preset Encryption Methods",
          "custom_group": "Custom Encryption Method",
          "current_value": "Current Value",
          "use_custom": "Use",
          "no_results": "No matching encryption method found",
          "custom_hint": "You can directly enter a custom encryption method, such as: aes-256-cfb",
          "custom_label": "Custom"
        },
        "plugin": {
          "label": "Plugin",
          "placeholder": "Select plugin",
          "obfs_hint": "Hint: Configuration format like obfs=http;obfs-host=www.bing.com;path=/",
          "v2ray_hint": "Hint: WebSocket mode format is mode=websocket;host=mydomain.me;path=/;tls=true, QUIC mode format is mode=quic;host=mydomain.me",
          "gost_hint": "Hint: Configuration format like mode=websocket;host=mydomain.me;path=/;tls=true",
          "shadow_tls_hint": "Hint: Configuration format like host=cloud.tencent.com;password=auth_password;version=3",
          "restls_hint": "Hint: Configuration format like host=www.microsoft.com;password=auth_password;version-hint=tls13;restls-script=300?100<1,400~100",
          "kcptun_hint": "Hint: Configuration format like key=psk;crypt=aes-128-gcm;mode=fast;mtu=1350"
        },
        "plugin_opts": {
          "label": "Plugin Options",
          "description": "Enter plugin options in key=value;key2=value2 format",
          "placeholder": "Example: mode=tls;host=bing.com"
        },
        "client_fingerprint": "Client Fingerprint",
        "client_fingerprint_placeholder": "Select client fingerprint",
        "client_fingerprint_description": "Client spoofing fingerprint to reduce detection risk",
        "obfs": {
          "label": "Obfuscation",
          "placeholder": "Select obfuscation method",
          "none": "None",
          "http": "HTTP"
        },
        "obfs_settings": {
          "path": "Path",
          "host": "Host"
        },
        "cert_config": {
          "tab": "TLS Cert",
          "cert_mode": {
            "label": "Cert Mode",
            "description": "Select how to manage certificates",
            "self_description": "Self-signed: Valid for 10 years, auto-generated by node",
            "http_description": "HTTP-01: Port 80 must be reachable",
            "dns_description": "DNS-01: Authenticate via DNS records, supports wildcard certs",
            "content_description": "Content: Push raw cert files to node"
          },
          "domain": {
            "label": "Domain",
            "placeholder": "example.com"
          },
          "email": {
            "label": "Notification Email",
            "placeholder": "admin@example.com"
          },
          "http_port": {
            "label": "Challenge Port",
            "description": "ACME challenge port (default 80)"
          },
          "dns_provider": {
            "label": "DNS Provider",
            "doc_link": "DNS provider configuration guide"
          },
          "dns_env": {
            "label": "Env Vars (API Keys)",
            "description_short": "One KEY=VALUE per line"
          },
          "cert_content": {
            "label": "Public Key content"
          },
          "key_content": {
            "label": "Private Key content"
          },
          "none_desc": "TLS config disabled"
        }
      },
      "vmess": {
        "tls": {
          "label": "TLS",
          "placeholder": "Please select security",
          "disabled": "Disabled",
          "enabled": "Enabled"
        },
        "tls_settings": {
          "server_name": {
            "label": "Server Name Indication (SNI)",
            "placeholder": "Leave empty if not used"
          },
          "allow_insecure": "Allow Insecure?"
        },
        "network": {
          "label": "Transport Protocol",
          "placeholder": "Select transport protocol"
        }
      },
      "trojan": {
        "server_name": {
          "label": "Server Name Indication (SNI)",
          "placeholder": "Used for certificate verification when node address differs from certificate"
        },
        "allow_insecure": "Allow Insecure?",
        "reality_settings": {
          "server_name": {
            "label": "Destination Site (dest)",
            "placeholder": "e.g., example.com"
          },
          "server_port": {
            "label": "Port",
            "placeholder": "e.g., 443"
          },
          "allow_insecure": "Allow Insecure?",
          "private_key": {
            "label": "Private Key"
          },
          "public_key": {
            "label": "Public Key"
          },
          "short_id": {
            "label": "Short ID",
            "placeholder": "Optional, length must be even, max 16 characters",
            "description": "List of shortIds available to clients, can be used to distinguish different clients, using hexadecimal characters 0-f",
            "generate": "Generate Short ID",
            "success": "Short ID generated successfully"
          },
          "key_pair": {
            "generate": "Generate Key Pair",
            "success": "Key pair generated successfully",
            "error": "Failed to generate key pair"
          }
        },
        "network": {
          "label": "Transport Protocol",
          "placeholder": "Select transport protocol"
        }
      },
      "hysteria": {
        "version": {
          "label": "Protocol Version",
          "placeholder": "Protocol version"
        },
        "alpn": {
          "label": "ALPN",
          "placeholder": "ALPN"
        },
        "obfs": {
          "label": "Obfuscation",
          "type": {
            "label": "Obfuscation Implementation",
            "placeholder": "Select obfuscation implementation",
            "salamander": "Salamander"
          },
          "password": {
            "label": "Obfuscation Password",
            "placeholder": "Please enter obfuscation password",
            "generate_success": "Obfuscation password generated successfully"
          }
        },
        "tls": {
          "server_name": {
            "label": "Server Name Indication (SNI)",
            "placeholder": "Used for certificate verification when node address differs from certificate"
          },
          "allow_insecure": "Allow Insecure?"
        },
        "bandwidth": {
          "up": {
            "label": "Upload Bandwidth",
            "placeholder": "Please enter upload bandwidth",
            "suffix": "Mbps",
            "bbr_tip": ", leave empty to use BBR"
          },
          "down": {
            "label": "Download Bandwidth",
            "placeholder": "Please enter download bandwidth",
            "suffix": "Mbps",
            "bbr_tip": ", leave empty to use BBR"
          }
        }
      },
      "vless": {
        "xhttp": {
          "path": "Путь",
          "host": "Host",
          "mode": "Режим XHTTP",
          "http": "Версия HTTP",
          "default": "По умолчанию",
          "split": "Разделить загрузку и скачивание",
          "address": "Адрес скачивания",
          "port": "Порт скачивания",
          "security": "Защита скачивания",
          "none": "Нет",
          "sni": "Имя сервера скачивания",
          "publicKey": "Публичный ключ Reality скачивания",
          "shortId": "Short ID скачивания",
          "sameInbound": "Оба пути должны вести к одному входящему соединению XHTTP."
        },
        "tls": {
          "label": "Security",
          "placeholder": "Please select security",
          "none": "None",
          "tls": "TLS",
          "reality": "Reality"
        },
        "tls_settings": {
          "server_name": {
            "label": "Server Name Indication (SNI)",
            "placeholder": "Leave empty if not used"
          },
          "allow_insecure": "Allow Insecure?"
        },
        "reality_settings": {
          "anti_abuse": {
            "label": "Защита от злоупотреблений",
            "description": "Маскировочный трафик идёт во внутренний вход на самом узле: пропускаются только TLS-домены маскировочного сайта, остальной трафик блокируется"
          },
          "dest": {
            "label": "Адрес назначения (dest)",
            "placeholder": "Например: 127.0.0.1:8443"
          },
          "server_name": {
            "label": "Домен рукопожатия (SNI)",
            "placeholder": "e.g., example.com"
          },
          "server_port": {
            "label": "Port",
            "placeholder": "e.g., 443"
          },
          "allow_insecure": "Allow Insecure?",
          "private_key": {
            "label": "Private Key"
          },
          "public_key": {
            "label": "Public Key"
          },
          "short_id": {
            "label": "Short ID",
            "placeholder": "Optional, length must be even, max 16 characters",
            "description": "List of shortIds available to clients, can be used to distinguish different clients, using hexadecimal characters 0-f",
            "generate": "Generate Short ID",
            "success": "Short ID generated successfully"
          },
          "key_pair": {
            "generate": "Generate Key Pair",
            "success": "Key pair generated successfully",
            "error": "Failed to generate key pair"
          }
        },
        "network": {
          "label": "Transport Protocol",
          "placeholder": "Select transport protocol"
        },
        "flow": {
          "label": "Flow Control",
          "placeholder": "Select flow control"
        },
        "encryption": {
          "label": "VLESS Encryption",
          "description": "Enable VLESS encryption",
          "server_label": "decryption",
          "server_placeholder": "./xray vlessenc",
          "server_description": "",
          "client_label": "encryption",
          "client_placeholder": "./xray vlessenc",
          "client_description": "",
          "generate_hint": "./xray vlessenc"
        }
      },
      "tuic": {
        "version": {
          "label": "Protocol Version",
          "placeholder": "Select TUIC Version"
        },
        "password": {
          "label": "Password",
          "placeholder": "Enter Password",
          "generate_success": "Password Generated Successfully"
        },
        "congestion_control": {
          "label": "Congestion Control",
          "placeholder": "Select Congestion Control Algorithm"
        },
        "udp_relay_mode": {
          "label": "UDP Relay Mode",
          "placeholder": "Select UDP Relay Mode"
        },
        "tls": {
          "server_name": {
            "label": "Server Name Indication (SNI)",
            "placeholder": "Used for certificate verification when domain differs from node address"
          },
          "allow_insecure": "Allow Insecure?",
          "alpn": {
            "label": "ALPN",
            "placeholder": "Select ALPN Protocols",
            "empty": "No ALPN Protocols Available"
          }
        }
      },
      "socks": {
        "version": {
          "label": "Protocol Version",
          "placeholder": "Select SOCKS Version"
        },
        "tls": {
          "label": "TLS",
          "placeholder": "Please select security",
          "disabled": "Disabled",
          "enabled": "Enabled"
        },
        "tls_settings": {
          "server_name": {
            "label": "Server Name Indication (SNI)",
            "placeholder": "Leave empty if not used"
          },
          "allow_insecure": "Allow Insecure?"
        },
        "network": {
          "label": "Transport Protocol",
          "placeholder": "Select transport protocol"
        }
      },
      "naive": {
        "tls_settings": {
          "server_name": {
            "label": "Server Name Indication (SNI)",
            "placeholder": "Used for certificate verification when domain differs from node address"
          },
          "allow_insecure": "Allow Insecure"
        },
        "tls": {
          "label": "TLS",
          "placeholder": "Please select security",
          "disabled": "Disabled",
          "enabled": "Enabled",
          "server_name": {
            "label": "Server Name Indication (SNI)",
            "placeholder": "Used for certificate verification when domain differs from node address"
          },
          "allow_insecure": "Allow Insecure"
        }
      },
      "http": {
        "tls_settings": {
          "server_name": {
            "label": "Server Name Indication (SNI)",
            "placeholder": "Used for certificate verification when domain differs from node address"
          },
          "allow_insecure": "Allow Insecure"
        },
        "tls": {
          "label": "TLS",
          "placeholder": "Please select security",
          "disabled": "Disabled",
          "enabled": "Enabled",
          "server_name": {
            "label": "Server Name Indication (SNI)",
            "placeholder": "Used for certificate verification when domain differs from node address"
          },
          "allow_insecure": "Allow Insecure"
        }
      },
      "mieru": {
        "transport": {
          "label": "Transport Protocol",
          "placeholder": "Select transport protocol"
        },
        "traffic_pattern": {
          "label": "Traffic Pattern (Base64)",
          "placeholder": "Enter Base64 string for network fine-tuning",
          "success": "Traffic pattern generated"
        }
      },
      "advanced": {
        "trigger_label": "Расширенная конфигурация",
        "dialog_title": "Расширенная конфигурация протокола",
        "tls_tab": "TLS",
        "route_tab": "Маршрутизация",
        "multiplex_tab": "Мультиплексирование"
      }
    },
    "network_settings": {
      "edit_protocol": "Edit Protocol",
      "edit_protocol_config": "Edit Protocol Configuration",
      "use_template": "Use {{template}} Template",
      "json_config_placeholder": "Please enter JSON configuration",
      "json_config_placeholder_with_template": "Please enter JSON configuration or select template above",
      "validation": {
        "must_be_object": "Configuration must be a JSON object",
        "invalid_json": "Invalid JSON format"
      },
      "errors": {
        "save_failed": "Error occurred while saving"
      }
    },
    "common": {
      "cancel": "Cancel",
      "confirm": "Confirm"
    }
  },
  "coupon": {
    "title": "Управление купонами",
    "description": "Здесь вы можете управлять купонами на скидку, включая их добавление, просмотр и удаление.",
    "table": {
      "columns": {
        "id": "ID",
        "show": "Включен",
        "name": "Название",
        "type": "Тип",
        "code": "Код",
        "limitUse": "Осталось исп.",
        "limitUseWithUser": "Исп. на чел.",
        "validity": "Срок действия",
        "actions": "Действия"
      },
      "validity": {
        "expired": "Истек {{days}} дн. назад",
        "notStarted": "Начнется через {{days}} дн.",
        "remaining": "Осталось {{days}} дн.",
        "startTime": "Начало",
        "endTime": "Конец",
        "unlimited": "Бессрочно",
        "noLimit": "Без лимита"
      },
      "actions": {
        "edit": "Изменить",
        "delete": "Удалить",
        "deleteConfirm": {
          "title": "Подтверждение удаления",
          "description": "Это действие навсегда удалит этот купон. Вы уверены, что хотите продолжить?",
          "confirmText": "Удалить"
        }
      },
      "toolbar": {
        "search": "Поиск купонов...",
        "type": "Тип",
        "reset": "Сбросить",
        "types": {
          "1": "Фиксированная сумма",
          "2": "Процент"
        }
      }
    },
    "form": {
      "add": "Добавить купон",
      "edit": "Изменить купон",
      "name": {
        "label": "Название купона",
        "placeholder": "Введите название купона",
        "required": "Пожалуйста, введите название купона"
      },
      "type": {
        "label": "Тип и значение купона",
        "placeholder": "Выберите тип купона"
      },
      "value": {
        "placeholder": "Введите значение"
      },
      "validity": {
        "label": "Срок действия",
        "to": "до",
        "endTimeError": "Время окончания должно быть позже времени начала"
      },
      "limitUse": {
        "label": "Максимальное количество использований",
        "placeholder": "Оставьте пустым для неограниченного использования",
        "description": "Установите общее количество раз, которое этот купон может быть использован"
      },
      "limitUseWithUser": {
        "label": "Лимит на пользователя",
        "placeholder": "Оставьте пустым для неограниченного использования",
        "description": "Ограничьте, сколько раз каждый пользователь может использовать этот купон"
      },
      "limitPeriod": {
        "label": "Периоды подписки",
        "placeholder": "Ограничить конкретными периодами, оставьте пустым для всех",
        "description": "Выберите периоды подписки, для которых применим этот купон",
        "empty": "Периоды не найдены"
      },
      "limitPlan": {
        "label": "Тарифные планы",
        "placeholder": "Ограничить конкретными тарифами, оставьте пустым для всех",
        "description": "Выберите тарифные планы, для которых применим этот купон, оставьте пустым для всех",
        "empty": "Тарифы не найдены"
      },
      "code": {
        "label": "Кастомный код купона",
        "placeholder": "Оставьте пустым для автогенерации",
        "description": "Вы можете задать свой код купона или оставить поле пустым"
      },
      "generateCount": {
        "label": "Количество для генерации",
        "placeholder": "Сколько купонов создать, оставьте пустым для одного",
        "description": "Сгенерировать несколько кодов купонов за один раз"
      },
      "submit": {
        "saving": "Сохранение...",
        "save": "Сохранить"
      },
      "error": {
        "saveFailed": "Не удалось сохранить купон"
      },
      "timeRange": {
        "quickSet": "Быстрая установка",
        "presets": {
          "1week": "1 Неделя",
          "2weeks": "2 Недели",
          "1month": "1 Месяц",
          "3months": "3 Месяца",
          "6months": "6 Месяцев",
          "1year": "1 Год"
        }
      }
    },
    "period": {
      "monthly": "Ежемесячно",
      "quarterly": "Ежеквартально",
      "half_yearly": "Раз в полгода",
      "yearly": "Ежегодно",
      "two_yearly": "Раз в 2 года",
      "three_yearly": "Раз в 3 года",
      "onetime": "Единоразово",
      "reset_traffic": "Сброс трафика"
    }
  },
  "route": {
    "tabs": {"rules": "Правила маршрутов", "blocks": "Блокировки"},
    "title": "Управление маршрутами",
    "description": "Управление группами маршрутов, включая добавление, удаление и редактирование.",
    "columns": {
      "id": "ID группы",
      "enabled": "Включён",
      "remarks": "Примечание",
      "action": "Действие",
      "actions": "Действия",
      "matchRules": "Правил совпадения: {{count}}",
      "portTag": "Порт {{value}}",
      "networkTag": {
        "tcp": "Только TCP",
        "udp": "Только UDP"
      },
      "nodes": "Узлов: {{count}}",
      "applyToNewNodes": "По умолчанию для новых узлов",
      "action_value": {
        "title": "Значение действия",
        "dns": "DNS: {{value}}",
        "proxy": "Прокси ({{value}})",
        "block": "Блокировать доступ",
        "direct": "Прямое соединение"
      }
    },
    "actions": {
      "dns": "Разрешать через DNS",
      "block": "Блокировать",
      "direct": "Напрямую",
      "proxy": "Прокси"
    },
    "form": {
      "add": "Добавить маршрут",
      "edit": "Изменить маршрут",
      "create": "Создать маршрут",
      "enabled": "Включить маршрут",
      "remarks": "Примечание",
      "remarksPlaceholder": "Введите примечание",
      "match": "Совпадение (домен или IP)",
      "matchPlaceholder": "example.com\n*.example.com",
      "protocol": "Протокол",
      "protocolAny": "Любой",
      "port": "Порт назначения",
      "portPlaceholder": "25,465,6881-6889",
      "network": "Сеть",
      "networkAny": "TCP и UDP",
      "networkTcp": "Только TCP",
      "networkUdp": "Только UDP",
      "nodes": "Узлы",
      "nodesPlaceholder": "Выберите узлы",
      "nodesEmpty": "Нет узлов",
      "selectAllNodes": "Выбрать все",
      "clearNodes": "Очистить",
      "applyToNewNodes": "Применять к новым узлам по умолчанию",
      "action": "Действие",
      "actionPlaceholder": "Выберите действие",
      "dns": "DNS Сервер",
      "dnsPlaceholder": "Введите DNS сервер",
      "proxy": "Тег выхода",
      "proxyPlaceholder": "Введите тег выхода (Outbound Tag)",
      "cancel": "Отмена",
      "submit": "Отправить",
      "validation": {
        "remarks": "Введите корректное примечание",
        "condition": "Укажите хотя бы одно условие совпадения",
        "port": "Неверный порт назначения «{{value}}»: укажите порт или диапазон 1-65535"
      }
    },
    "toolbar": {
      "searchPlaceholder": "Поиск маршрутов...",
      "reset": "Сбросить"
    },
    "messages": {
      "deleteConfirm": "Подтверждение удаления",
      "deleteDescription": "Это действие навсегда удалит эту группу маршрутов. Продолжить?",
      "enableRoute": "Включить маршрут: {{name}}",
      "disableRoute": "Отключить маршрут: {{name}}",
      "updateFailed": "Не удалось сохранить состояние маршрута. Повторите попытку.",
      "deleteButton": "Удалить",
      "deleteSuccess": "Удалено успешно",
      "createSuccess": "Создано успешно",
      "updateSuccess": "Обновлено успешно"
    }
  },
  "ticket": {
    "title": "Управление тикетами",
    "description": "Просмотр и управление обращениями пользователей, включая ответы и закрытие тикетов.",
    "columns": {
      "id": "ID тикета",
      "subject": "Тема",
      "level": "Приоритет",
      "status": "Статус",
      "updated_at": "Обновлен",
      "created_at": "Создан",
      "actions": "Действия"
    },
    "status": {
      "closed": "Закрыт",
      "replied": "Отвечен",
      "pending": "Ожидание",
      "processing": "В обработке"
    },
    "level": {
      "low": "Низкий",
      "medium": "Средний",
      "high": "Высокий"
    },
    "filter": {
      "placeholder": "Поиск {field}...",
      "no_results": "Результатов не найдено",
      "selected": "Выбрано: {count}",
      "clear": "Очистить фильтры"
    },
    "actions": {
      "view_details": "Детали",
      "close_ticket": "Закрыть тикет",
      "close_confirm_title": "Подтверждение закрытия",
      "close_confirm_description": "Вы уверены, что хотите закрыть этот тикет? Он переместится в список закрытых, но отвечать в нем все равно можно.",
      "close_confirm_button": "Закрыть тикет",
      "close_success": "Тикет успешно закрыт",
      "view_ticket": "Посмотреть тикет"
    },
    "detail": {
      "no_messages": "Сообщений нет",
      "created_at": "Создан",
      "sender_admin": "Админ",
      "sender_user": "Пользователь",
      "user_info": "Инфо о пользователе",
      "traffic_records": "История трафика",
      "order_records": "История заказов",
      "input": {
        "closed_reply_placeholder": "Тикет закрыт, но вы все еще можете ответить...",
        "closed_hint": "Тикет закрыт, но вы все еще можете отвечать. Новые сообщения будут добавлены в текущий тикет.",
        "reply_placeholder": "Введите ваш ответ...",
        "sending": "Отправка...",
        "send": "Отправить"
      }
    },
    "list": {
      "title": "Список тикетов",
      "search_placeholder": "Поиск по теме или email",
      "no_tickets": "Тикетов нет",
      "no_open_tickets": "Нет открытых тикетов",
      "no_closed_tickets": "Нет закрытых тикетов",
      "no_search_results": "Тикеты не найдены",
      "collapse": "Свернуть список",
      "expand": "Развернуть список"
    }
  },
  "machine": {
    "lite": {
      "binding_pending": "Ожидание совпадения; повтор каждую минуту",
      "binding_conflict": "Конфликт IP; привяжите вручную",
      "binding_matched": "Совпадение найдено; ожидание привязки",
      "binding_paused": "Автопривязка приостановлена",
      "resumeAuto": "Возобновить автопривязку",
      "connect": "Подключить Lite",
      "description": "После включения публичные IP сопоставляются каждую минуту. Конфликты разрешаются вручную.",
      "url": "Адрес Lite",
      "key": "API-ключ сайта",
      "keepKey": "Оставьте пустым, чтобы сохранить ключ",
      "enabled": "Включить Lite",
      "saveRead": "Сохранить и загрузить",
      "read": "Загрузить серверы",
      "autoBind": "Сопоставить по IP",
      "importSelected": "Импортировать ({{count}})",
      "completed": "Обработано серверов: {{count}}",
      "refreshFailed": "Операция выполнена, но список не обновлён. Загрузите его повторно.",
      "empty": "В Lite нет серверов",
      "select": "Выбрать {{name}}",
      "boundTo": "Связан с: {{name}}",
      "unbind": "Отвязать",
      "bindTarget": "Сервер для {{name}}",
      "chooseMachine": "Выберите сервер",
      "bind": "Связать",
      "retry": "Повторить",
      "loading": "Загрузка",
      "readFailed": "Ошибка чтения",
      "historyFailed": "Не удалось загрузить историю",
      "missing": "Сервер удалён",
      "offline": "Не в сети",
      "online": "В сети",
      "stale": "Данные устарели",
      "unknown": "Неизвестно",
      "lastReport": "Последний отчёт",
      "traffic": "Трафик Lite / квота",
      "info": "Информация сервера Lite",
      "name": "Название в Lite",
      "country": "Страна / регион",
      "ip": "Публичный IP",
      "os": "ОС / архитектура",
      "cpu": "Процессор",
      "cores": "Ядра CPU",
      "kernel": "Версия ядра",
      "virtualization": "Виртуализация",
      "group": "Группа",
      "tags": "Метки",
      "bandwidth": "Пропускная способность",
      "expires": "Истекает",
      "resetDay": "День сброса трафика",
      "resetTime": "Время сброса / часовой пояс",
      "nextReset": "Следующий сброс",
      "mode": "Способ учёта трафика",
      "remark": "Публичное примечание",
      "noReset": "Без автоматического сброса",
      "monthlyDay": "{{day}} числа каждого месяца",
      "mode_up": "Только отдача",
      "mode_down": "Только загрузка",
      "mode_sum": "Отдача + загрузка",
      "mode_max": "Большее из отдачи и загрузки",
      "mode_min": "Меньшее из отдачи и загрузки"
    },
    "traffic": {
      "title": "Трафик / лимит",
      "limit": "Лимит трафика (ГБ, 0 без лимита)",
      "resetDay": "День ежемесячного сброса",
      "mode": "Способ учёта",
      "outbound": "Только исходящий",
      "both": "Входящий + исходящий",
      "proxy": "Только трафик прокси",
      "interfaces": "Сетевые интерфейсы",
      "interfacesPlaceholder": "Автоматически, если пусто; имена через запятую",
      "unlimitedPlaceholder": "0 — без лимита",
      "unlimited": "Без лимита",
      "invalidLimit": "Введите значение от 0 до 8388607",
      "invalidMode": "Выберите способ учёта",
      "invalidDay": "Введите целое число от 1 до 31",
      "invalidInterfaces": "Введите допустимые имена интерфейсов через запятую",
      "exceeded": "Лимит исчерпан",
      "waiting": "Ожидание учёта",
      "stale": "Нет отчёта о трафике",
      "errors": {
        "interfaces_unavailable": "Сетевые интерфейсы недоступны",
        "state_lost": "Данные учёта потеряны; пауза до следующего периода",
        "state_write_failed": "Не удалось сохранить данные учёта"
      }
    },
    "agent": {
      "more": "Другие действия",
      "confirm": "Подтвердить",
      "cancel": "Отмена",
      "submission": "Отправка",
      "version": "Запущенная версия",
      "publicIp": "Публичный IP",
      "operation": "Операция",
      "upgrade": "Обновить agent",
      "restart": "Перезапустить agent",
      "batch_upgrade": "Обновить выбранные",
      "batch_restart": "Перезапустить выбранные",
      "upgradeConfirm": "Обновить выбранные серверы ({{count}})?",
      "restartConfirm": "Перезапустить выбранные серверы ({{count}})?",
      "interruption": "Узлы yz-agent на этих серверах будут кратковременно прерваны. Обновление до последнего стабильного выпуска.",
      "selectPage": "Выбрать текущую страницу",
      "selectServer": "Выбрать сервер {{name}}",
      "clearSelection": "Снять выбор ({{count}})",
      "queued": "Отправлено: {{count}}; не отправлено: {{failed}}",
      "inProgress": {
        "upgrade": "Обновление",
        "restart": "Перезапуск"
      },
      "results": {
        "updated": "Обновлено и перезапущено",
        "up_to_date": "Уже установлена последняя версия",
        "current_newer": "Текущая версия новее; автоматическое понижение отменено"
      },
      "states": {
        "pending": "Ожидание",
        "running": "Выполняется",
        "succeeded": "Успешно",
        "failed": "Ошибка",
        "timeout": "Время ожидания истекло"
      },
      "errors": {
        "disabled": "Сервер отключён",
        "offline": "Сервер недоступен",
        "unsupported": "Удалённые операции недоступны",
        "busy": "Операция уже выполняется",
        "not_found": "Сервер не найден",
        "launch_failed": "Не удалось запустить обработчик",
        "execution_failed": "Ошибка выполнения",
        "release_query_failed": "Не удалось проверить последний стабильный выпуск; обновление остановлено",
        "current_version_failed": "Не удалось прочитать установленную версию; обновление остановлено",
        "current_version_invalid": "Установленная версия не распознана; обновление остановлено",
        "latest_version_invalid": "Последняя стабильная версия не распознана; обновление остановлено",
        "timeout": "Время ожидания истекло; проверьте службу",
        "request_failed": "Отправка не подтверждена; обновите список"
      }
    },
    "title": "Управление серверами",
    "description": "Просматривайте состояние сервера, нагрузку и размещённые узлы, а также запускайте операции с узлами из операционного представления.",
    "columns": {
      "id": "ID",
      "name": "Имя сервера",
      "status": "Статус",
      "nodes": "Узлы",
      "nodesHosted": "размещено узлов",
      "nodesIdle": "нет узлов",
      "proxyTraffic": "Использование серверов",
      "proxyTrafficTooltip": "Сумма отправленных и полученных данных. Транзит внутри сервера учитывается один раз. Другие программы не учитываются.",
      "load": "Нагрузка",
      "lastSeen": "Последний отклик",
      "actions": "Действия",
      "online": "Онлайн",
      "offline": "Оффлайн",
      "inactive": "Отключён",
      "noData": "Нет данных о нагрузке",
      "cpu": "CPU",
      "memory": "Память",
      "disk": "Диск",
      "never": "Никогда",
      "lastReport": "Отчёт о нагрузке"
    },
    "toolbar": {
      "search": "Поиск по имени сервера, заметкам или SID...",
      "status": "Статус",
      "nodes": "Узлы",
      "nodesHosted": "размещено узлов",
      "nodesIdle": "нет узлов",
      "with_nodes": "С размещёнными узлами",
      "idle_nodes": "Свободные серверы",
      "high_load": "Высокая нагрузка",
      "online_ratio": "Онлайн",
      "high_load_count": "Высокая нагрузка",
      "reset": "Сбросить"
    },
    "overview": {
      "total": "Всего серверов",
      "total_hint": "Всего размещено узлов: {{count}}",
      "online": "Серверы онлайн",
      "online_hint": "Есть heartbeat за последние 5 минут",
      "offline": "Оффлайн / Потеряны",
      "offline_hint": "Требуется проверить heartbeat или агент",
      "high_load": "Высокая нагрузка",
      "high_load_hint": "CPU, память или диск близки к порогу",
      "nodes_suffix": "узлов",
      "attention": "Внимание",
      "stable": "Стабильно",
      "needs_review": "Проверить",
      "normal": "Норма"
    },
    "form": {
      "add": "Добавить сервер",
      "create": "Новый сервер",
      "edit": "Редактировать сервер",
      "createDescription": "Создайте новый сервер для управления несколькими узлами.",
      "editDescription": "Изменить имя, заметки или статус сервера.",
      "name": "Имя сервера",
      "namePlaceholder": "Например HK-01",
      "nameError": "Введите имя сервера",
      "notes": "Заметки",
      "notesPlaceholder": "Необязательные заметки о сервере",
      "isActive": "Включить сервер",
      "isActiveDescription": "Отключённые серверы не используются xboard-node.",
      "disableLogs": "Режим защиты конфиденциальности",
      "disableLogsDescription": "Шифрует конфиденциальные данные и отключает журналы. При отключении режима данные и журналы восстанавливаются.",
      "cancel": "Отмена",
      "submit": "Сохранить",
      "update": "Обновить"
    },
    "token": {
      "title": "Токен сервера",
      "description": "Этот токен используется xboard-node для аутентификации. Храните его в безопасности.",
      "show": "Показать токен",
      "hide": "Скрыть токен",
      "reset": "Сбросить токен",
      "resetConfirm": "Сбросить токен?",
      "resetDescription": "Старый токен будет немедленно аннулирован. xboard-node потребует перенастройки.",
      "copy": "Копировать",
      "copied": "Токен скопирован",
      "copiedInline": "Скопировано!",
      "copyFailed": "Ошибка копирования",
      "autoHide": "Скроется через {{time}}",
      "resetSuccess": "Токен сброшен",
      "createdHint": "Токен создан. Вы можете просмотреть его в любое время на странице сервера."
    },
    "install": {
      "title": "Установить xboard-node",
      "description": "Выполните эту команду на целевом сервере, чтобы установить xboard-node в режиме machine mode и подключить его к текущей записи сервера.",
      "copy": "Копировать команду установки",
      "copied": "Команда установки скопирована",
      "copiedInline": "Скопировано!",
      "copyFailed": "Ошибка копирования",
      "loading": "Генерация команды...",
      "hint": "Требуются root или sudo, а также Linux-сервер с systemd."
    },
    "detail": {
      "title": "Детали сервера",
      "info": "Информация",
      "associatedNodes": "Связанные узлы",
      "noNodes": "К этому серверу не привязаны узлы.",
      "nodeId": "ID",
      "nodeName": "Имя",
      "nodeType": "Тип",
      "nodeHost": "Адрес",
      "nodePort": "Порт",
      "nodeShow": "Видимый",
      "nodeEnabled": "Активен",
      "loadTrend": "Тренд нагрузки",
      "networkTrend": "Скорость сети",
      "noHistory": "История нагрузки пока отсутствует.",
      "openNodeManage": "Открыть управление узлами",
      "addNodeToServer": "Добавить узел на этот сервер",
      "nodeCount": "{{count}} узлов",
      "nodeEnabledCount": "{{count}} активных",
      "toggleEnabledError": "Не удалось переключить состояние узла",
      "bindExistingButton": "Привязать существующие",
      "bindExistingTitle": "Привязать существующие узлы",
      "bindExistingDescription": "Выберите узлы для привязки к «{{name}}»",
      "bindSearchPlaceholder": "Поиск по имени, адресу, типу...",
      "noUnboundNodes": "Нет свободных узлов",
      "noSearchResults": "Нет совпадений",
      "selectAll": "Выбрать все ({{count}})",
      "selectedCount": "{{count}} выбрано",
      "bindConfirm": "Привязать {{count}} узлов",
      "binding": "Привязка...",
      "bindSuccess": "Успешно привязано {{count}} узлов к «{{name}}»",
      "bindFailed": "Ошибка привязки",
      "unbindNode": "Отвязать",
      "unbindSuccess": "«{{name}}» отвязан",
      "unbindFailed": "Ошибка отвязки",
      "cancel": "Отмена"
    },
    "messages": {
      "createSuccess": "Сервер успешно создан",
      "updateSuccess": "Сервер успешно обновлён",
      "deleteConfirm": "Удалить сервер?",
      "deleteDescription": "Связанные узлы будут отвязаны (не удалены). Это действие необратимо.",
      "deleteButton": "Удалить",
      "deleteSuccess": "Сервер успешно удалён",
      "deleteFailed": "Не удалось удалить сервер",
      "saveFailed": "Не удалось сохранить сервер",
      "tokenFetchFailed": "Не удалось получить токен",
      "tokenResetFailed": "Не удалось сбросить токен"
    },
    "nodeForm": {
      "machineId": "Привязать к серверу",
      "machineIdPlaceholder": "Выберите сервер (необязательно)",
      "machineIdNone": "Автономное развёртывание",
      "enabled": "Активен на сервере",
      "enabledDescription": "Запускать ли узел на привязанном сервере"
    }
  },
  "search": {
    "placeholder": "Поиск меню и функций...",
    "title": "Навигация по меню",
    "noResults": "Результатов не найдено",
    "shortcut": {
      "label": "Поиск",
      "key": "⌘K"
    }
  },
  "knowledge": {
    "title": "База знаний",
    "description": "Здесь вы можете управлять статьями базы знаний, включая их добавление, удаление и редактирование.",
    "columns": {
      "id": "ID",
      "status": "Статус",
      "title": "Заголовок",
      "category": "Категория",
      "actions": "Действия"
    },
    "form": {
      "add": "Добавить статью",
      "edit": "Изменить статью",
      "title": "Заголовок",
      "titlePlaceholder": "Введите заголовок статьи",
      "category": "Категория",
      "categoryPlaceholder": "Введите категорию для автоматической группировки",
      "language": "Язык",
      "languagePlaceholder": "Выберите язык",
      "content": "Содержимое",
      "show": "Показывать",
      "cancel": "Отмена",
      "submit": "Отправить"
    },
    "languages": {
      "en-US": "English",
      "ja-JP": "日本語",
      "ko-KR": "한국어",
      "vi-VN": "Tiếng Việt",
      "zh-CN": "简体中文",
      "zh-TW": "繁體中文",
      "ru-RU": "Русский"
    },
    "messages": {
      "deleteConfirm": "Подтверждение удаления",
      "deleteDescription": "Это действие навсегда удалит статью из базы знаний. Вы уверены, что хотите продолжить?",
      "deleteButton": "Удалить",
      "operationSuccess": "Операция выполнена успешно"
    },
    "toolbar": {
      "searchPlaceholder": "Поиск по базе знаний...",
      "reset": "Сбросить",
      "sortModeHint": "Перетаскивайте элементы для сортировки, затем нажмите сохранить",
      "editSort": "Изменить порядок",
      "saveSort": "Сохранить порядок"
    }
  },
  "common": {
    "loading": "Загрузка...",
    "error": "Ошибка",
    "success": "Успех",
    "save": "Сохранить",
    "cancel": "Отмена",
    "confirm": "Подтвердить",
    "close": "Закрыть",
    "delete": {
      "success": "Удалено успешно",
      "failed": "Не удалось удалить"
    },
    "edit": "Редактировать",
    "view": "Просмотр",
    "toggleNavigation": "Переключить навигацию",
    "toggleSidebar": "Переключить боковую панель",
    "search": "Поиск...",
    "theme": {
      "light": "Светлая",
      "dark": "Темная",
      "system": "Системная"
    },
    "user": "Пользователь",
    "defaultEmail": "user@example.com",
    "settings": "Настройки",
    "logout": "Выйти",
    "copy": {
      "success": "Скопировано успешно",
      "failed": "Не удалось скопировать",
      "error": "Ошибка копирования",
      "errorLog": "Ошибка при копировании в буфер обмена"
    },
    "submit": "Отправить",
    "saving": "Сохранение...",
    "table": {
      "noData": "Нет данных",
      "pagination": {
        "selected": "Выбрано {{selected}} из {{total}}",
        "itemsPerPage": "На странице",
        "page": "Страница",
        "pageOf": "из {{total}}",
        "firstPage": "На первую страницу",
        "previousPage": "Предыдущая страница",
        "nextPage": "Следующая страница",
        "lastPage": "На последнюю страницу"
      },
      "viewOptions": {
        "button": "Столбцы",
        "label": "Переключить видимость столбцов"
      }
    },
    "update": {
      "title": "System Update",
      "newVersion": "New Version Available",
      "currentVersion": "Current Version",
      "latestVersion": "Latest Version",
      "updateLater": "Update Later",
      "updateNow": "Update Now",
      "updating": "Updating...",
      "updateSuccess": "Update successful, system will restart shortly",
      "updateFailed": "Update failed, please try again later"
    },
    "time": {
      "day": "day",
      "hour": " hour(s)"
    },
    "reset": "Reset",
    "export": "Export",
    "currency": {
      "yuan": "Yuan"
    },
    "http": {
      "notLoggedIn": "Not logged in",
      "unknownError": "Unknown error",
      "loginExpired": "Login expired",
      "noPermission": "No permission",
      "notFound": "Resource or API not found",
      "unknownException": "Unknown exception"
    }
  },
  "sidebar": {
    "dashboard": "Панель управления",
    "systemManagement": "Управление системой",
    "systemConfig": "Конфигурация системы",
    "themeConfig": "Конфигурация тем",
    "noticeManagement": "Объявления",
    "paymentConfig": "Платежные методы",
    "knowledgeManagement": "База знаний",
    "nodeManagement": "Узлы",
    "permissionGroupManagement": "Группы прав",
    "routeManagement": "Маршруты",
    "subscriptionManagement": "Управление подписками",
    "planManagement": "Тарифы",
    "orderManagement": "Заказы",
    "couponManagement": "Купоны",
    "userManagement": "Пользователи",
    "ticketManagement": "Тикеты"
  },
  "plugin": {
    "title": "Управление плагинами",
    "description": "Управление и настройка системных плагинов",
    "search": {
      "placeholder": "Поиск по названию или описанию..."
    },
    "type": {
      "placeholder": "Выберите тип плагина",
      "all": "Все типы"
    },
    "tabs": {
      "all": "Все плагины",
      "installed": "Установленные",
      "available": "Доступные"
    },
    "status": {
      "enabled": "Включено",
      "disabled": "Отключено",
      "not_installed": "Не установлено",
      "protected": "Защищено",
      "filter_placeholder": "Статус управления",
      "all": "Все статусы",
      "installed": "Установленные",
      "available": "Доступные"
    },
    "button": {
      "install": "Установить",
      "upgrade": "Обновить",
      "config": "Настроить",
      "enable": "Включить",
      "disable": "Отключить",
      "uninstall": "Удалить",
      "readme": "Документация",
      "menuDemo": "Демо меню"
    },
    "upload": {
      "button": "Загрузить плагин",
      "title": "Загрузить плагин",
      "description": "Загрузите пакет плагина (.zip)",
      "dragText": "Перетащите пакет плагина сюда или",
      "clickText": "выберите файл",
      "supportText": "Поддерживаются только .zip файлы",
      "uploading": "Загрузка...",
      "error": {
        "format": "Поддерживаются только .zip файлы"
      }
    },
    "delete": {
      "title": "Удалить плагин",
      "description": "Вы уверены, что хотите удалить этот плагин? Это действие нельзя отменить.",
      "button": "Удалить"
    },
    "uninstall": {
      "title": "Удалить плагин из системы",
      "description": "Вы уверены, что хотите удалить этот плагин? Все данные плагина будут стерты.",
      "button": "Удалить"
    },
    "upgrade": {
      "title": "Обновить плагин",
      "description": "Вы уверены, что хотите обновить этот плагин? Он будет временно недоступен в процессе.",
      "button": "Обновить"
    },
    "config": {
      "title": "Конфигурация",
      "description": "Изменение настроек плагина",
      "save": "Сохранить",
      "cancel": "Отмена"
    },
    "readme": {
      "title": "Документация плагина"
    },
    "author": "Автор",
    "messages": {
      "installSuccess": "Плагин успешно установлен",
      "installError": "Ошибка при установке плагина",
      "upgradeSuccess": "Плагин успешно обновлен",
      "upgradeError": "Ошибка при обновлении плагина",
      "uninstallSuccess": "Плагин успешно удален",
      "uninstallError": "Ошибка при удалении плагина",
      "enableSuccess": "Плагин включен",
      "enableError": "Ошибка включения плагина",
      "disableSuccess": "Плагин отключен",
      "disableError": "Ошибка отключения плагина",
      "configLoadError": "Ошибка загрузки конфигурации плагина",
      "configSaveSuccess": "Конфигурация сохранена",
      "configSaveError": "Ошибка сохранения конфигурации",
      "uploadSuccess": "Плагин загружен",
      "uploadError": "Ошибка загрузки плагина",
      "deleteSuccess": "Плагин удален",
      "deleteError": "Ошибка удаления плагина"
    }
  },
  "dashboard": {
    "title": "Панель управления",
    "stats": {
      "newUsers": "Новые пользователи",
      "totalScore": "Общий балл",
      "monthlyUpload": "Загружено за месяц",
      "vsLastMonth": "к прошлому месяцу",
      "vsYesterday": "со вчера",
      "todayIncome": "Доход за сегодня",
      "monthlyIncome": "Доход за месяц",
      "totalIncome": "Общий доход",
      "totalUsers": "Всего пользователей",
      "activeUsers": "Активных: {{count}}",
      "totalOrders": "Всего заказов",
      "revenue": "Выручка",
      "todayRegistered": "Зарегистрировано сегодня",
      "monthlyRegistered": "Зарегистрировано за месяц",
      "onlineUsers": "Онлайн",
      "pendingTickets": "Открытых тикетов",
      "hasPendingTickets": "Есть тикеты, требующие ответа",
      "noPendingTickets": "Нет открытых тикетов",
      "pendingCommission": "Комиссии на выплату",
      "hasPendingCommission": "Есть комиссии, требующие подтверждения",
      "noPendingCommission": "Нет комиссий на выплату",
      "monthlyNewUsers": "Новых за месяц",
      "monthlyDownload": "Скачано за месяц",
      "todayTraffic": "Сегодня: {{value}}",
      "activeUserTrend": "Тренды активности",
      "realtimeUsers": "Пользователи в реальном времени",
      "todayPeak": "Пик за сегодня",
      "vsLastWeek": "к прошлой неделе"
    },
    "trafficRank": {
      "nodeTrafficRank": "Рейтинг узлов",
      "userTrafficRank": "Рейтинг пользователей",
      "today": "Сегодня",
      "last7days": "7 дней",
      "last30days": "30 дней",
      "customRange": "Свой диапазон",
      "selectTimeRange": "Выбрать период",
      "selectDateRange": "Выбрать даты",
      "currentTraffic": "Трафик за период",
      "previousTraffic": "Трафик ранее",
      "changeRate": "Изменение",
      "recordTime": "Время записи"
    },
    "overview": {
      "title": "Обзор доходов",
      "thisMonth": "Этот месяц",
      "lastMonth": "Прошлый месяц",
      "to": "по",
      "selectTimeRange": "Выбрать диапазон",
      "selectDate": "Выбрать дату",
      "last7Days": "7 дней",
      "last30Days": "30 дней",
      "last90Days": "90 дней",
      "last180Days": "180 дней",
      "lastYear": "Год",
      "customRange": "Свой диапазон",
      "amount": "Сумма",
      "count": "Количество",
      "transactions": "Транзакций: {{count}}",
      "orderAmount": "Сумма заказов",
      "commissionAmount": "Сумма комиссий",
      "orderCount": "Заказов",
      "commissionCount": "Комиссий",
      "totalIncome": "Прибыль",
      "totalCommission": "Всего комиссий",
      "totalTransactions": "Транзакций: {{count}}",
      "avgOrderAmount": "Средний чек:",
      "commissionRate": "Доля комиссий:"
    },
    "traffic": {
      "title": "Рейтинг трафика",
      "rank": "Место",
      "domain": "Домен",
      "todayTraffic": "Трафик сегодня",
      "monthlyTraffic": "Трафик за месяц"
    },
    "queue": {
      "title": "Очереди",
      "jobDetails": "Детали задачи",
      "status": {
        "description": "Текущий статус выполнения очередей",
        "running": "Статус",
        "normal": "Норма",
        "abnormal": "Ошибка",
        "waitTime": "Ожидание: {{seconds}} сек.",
        "pending": "В очереди",
        "processing": "В процессе",
        "completed": "Завершено",
        "failed": "Ошибка",
        "cancelled": "Отменено"
      },
      "details": {
        "description": "Технические детали очередей",
        "recentJobs": "Последние задачи",
        "statisticsPeriod": "Период статистики: {{hours}} ч.",
        "jobsPerMinute": "Задач в минуту",
        "maxThroughput": "Пиковая нагрузка: {{value}}",
        "failedJobs7Days": "Ошибки (7 дней)",
        "retentionPeriod": "Период хранения: {{hours}} ч.",
        "longestRunningQueue": "Самая длинная очередь",
        "activeProcesses": "Активные процессы",
        "id": "ID задачи",
        "type": "Тип задачи",
        "status": "Статус",
        "progress": "Прогресс",
        "createdAt": "Создано",
        "updatedAt": "Обновлено",
        "error": "Ошибка",
        "data": "Данные задачи",
        "result": "Результат",
        "duration": "Длительность",
        "attempts": "Попыток",
        "nextRetry": "Минут до повтора",
        "failedJobsDetailTitle": "Ошибки очередей",
        "viewFailedJobs": "Ошибки",
        "jobDetailTitle": "Детали выполнения",
        "time": "Время",
        "queue": "Очередь",
        "name": "Имя задачи",
        "exception": "Исключение",
        "noFailedJobs": "Ошибок не найдено",
        "connection": "Соединение",
        "payload": "Payload",
        "viewDetail": "Детали",
        "action": "Действие"
      },
      "actions": {
        "retry": "Повтор",
        "cancel": "Отмена",
        "delete": "Удалить",
        "viewDetails": "Подробнее"
      },
      "empty": "Задач не найдено",
      "loading": "Загрузка статуса очередей...",
      "error": "Ошибка загрузки статуса"
    },
    "common": {
      "refresh": "Обновить",
      "close": "Закрыть",
      "pagination": "Страница {{current}}/{{total}}, всего {{count}}"
    },
    "search": {
      "placeholder": "Поиск меню и функций...",
      "title": "Навигация",
      "noResults": "Ничего не найдено",
      "loading": "Поиск..."
    }
  },
  "order": {
    "title": "Управление заказами",
    "description": "Здесь вы можете просматривать заказы пользователей, включая назначение, просмотр, удаление и другие операции.",
    "table": {
      "columns": {
        "tradeNo": "№ Заказа",
        "type": "Тип",
        "plan": "Тарифный план",
        "period": "Период",
        "amount": "Сумма оплаты",
        "status": "Статус заказа",
        "commission": "Сумма комиссии",
        "commissionStatus": "Статус комиссии",
        "createdAt": "Создан"
      }
    },
    "type": {
      "NEW": "Новая покупка",
      "RENEWAL": "Продление",
      "UPGRADE": "Апгрейд (Переход)",
      "RESET_FLOW": "Сброс трафика"
    },
    "period": {
      "month_price": "Ежемесячно",
      "quarter_price": "Ежеквартально",
      "half_year_price": "Раз в полгода",
      "year_price": "Ежегодно",
      "two_year_price": "Раз в 2 года",
      "three_year_price": "Раз в 3 года",
      "onetime_price": "Единоразово",
      "reset_price": "Пакет сброса"
    },
    "status": {
      "PENDING": "Ожидание",
      "PROCESSING": "В обработке",
      "CANCELLED": "Отменен",
      "COMPLETED": "Завершен",
      "DISCOUNTED": "Скидка",
      "tooltip": "После пометки [Оплачено] система выполнит активацию и завершит заказ"
    },
    "commission": {
      "PENDING": "Ожидание",
      "PROCESSING": "В обработке",
      "VALID": "Действительна",
      "INVALID": "Недействительна"
    },
    "actions": {
      "markAsPaid": "Пометить как оплаченный",
      "cancel": "Отменить заказ",
      "openMenu": "Открыть меню",
      "reset": "Сбросить"
    },
    "search": {
      "placeholder": "Поиск заказов..."
    },
    "dialog": {
      "title": "Информация о заказе",
      "basicInfo": "Основная информация",
      "amountInfo": "Информация о стоимости",
      "timeInfo": "Временные метки",
      "commissionInfo": "Информация о комиссии",
      "commissionStatusActive": "Активна",
      "addOrder": "Добавить заказ",
      "assignOrder": "Назначить заказ",
      "fields": {
        "userEmail": "Email пользователя",
        "userPhone": "Телефон пользователя",
        "orderPeriod": "Период заказа",
        "subscriptionPlan": "Тарифный план",
        "callbackNo": "№ Транзакции (Callback)",
        "paymentAmount": "Сумма к оплате",
        "balancePayment": "Оплата с баланса",
        "discountAmount": "Сумма скидки",
        "refundAmount": "Сумма возврата",
        "deductionAmount": "Сумма вычета",
        "createdAt": "Дата создания",
        "updatedAt": "Дата обновления",
        "commissionStatus": "Статус комиссии",
        "commissionAmount": "Заработок комиссии",
        "actualCommissionAmount": "Фактическая комиссия",
        "inviteUser": "Пригласитель",
        "inviteUserId": "ID пригласителя"
      },
      "placeholders": {
        "email": "Введите email пользователя",
        "plan": "Выберите тарифный план",
        "period": "Выберите период подписки",
        "amount": "Введите сумму оплаты"
      },
      "actions": {
        "cancel": "Отмена",
        "confirm": "Подтвердить"
      },
      "messages": {
        "addOrder": "Заказ успешно добавлен",
        "addSuccess": "Успешно добавлено"
      }
    }
  },
  "theme": {
    "title": "Конфигурация тем",
    "description": "Конфигурация тем, включая цвета, размеры шрифтов и т.д. Если вы развернули Xboard с раздельным фронтендом и бэкендом, конфигурация тем не вступит в силу.",
    "upload": {
      "button": "Загрузить тему",
      "title": "Загрузить тему",
      "description": "Пожалуйста, загрузите корректный пакет темы (формат .zip). Пакет должен содержать полную структуру файлов темы.",
      "dragText": "Перетащите файл темы сюда или",
      "clickText": "нажмите для выбора",
      "supportText": "Поддерживаются пакеты тем в формате .zip",
      "uploading": "Загрузка...",
      "error": {
        "format": "Поддерживаются только файлы тем в формате ZIP"
      }
    },
    "preview": {
      "title": "Предпросмотр темы",
      "imageCount": "{{current}} / {{total}}"
    },
    "card": {
      "version": "Версия: {{version}}",
      "currentTheme": "Текущая тема",
      "activateTheme": "Активировать тему",
      "configureTheme": "Настройки темы",
      "preview": "Предпросмотр",
      "delete": {
        "title": "Удалить тему",
        "description": "Вы уверены, что хотите удалить эту тему? Это действие нельзя отменить.",
        "button": "Удалить",
        "error": {
          "active": "Нельзя удалить активную тему"
        }
      }
    },
    "config": {
      "title": "Настройка темы {{name}}",
      "description": "Изменение стилей темы, макетов и других параметров отображения.",
      "cancel": "Отмена",
      "save": "Сохранить",
      "success": "Настройки успешно сохранены"
    }
  }
};

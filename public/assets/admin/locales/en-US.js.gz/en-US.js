window.XBOARD_TRANSLATIONS = window.XBOARD_TRANSLATIONS || {};
window.XBOARD_TRANSLATIONS['en-US'] = {
  "ddns": {
    "selfHosted": "Self-hosted",
    "serverId": "Server ID",
    "apiUrl": "PowerDNS API URL",
    "provider": "DNS provider",
    "ttl": "DNS TTL (seconds)",
    "followUserStatus": "Follow user status",
    "personalEnabled": "Per-user domain",
    "expected": "Expected usage",
    "title": "DDNS settings",
    "enabled": "Enable DDNS",
    "preset": "Domain preset",
    "prefix": "Node prefix",
    "choose": "Select",
    "manualIp": "Gateway connection IP",
    "baseDomain": "Base domain",
    "inherited": "Domain settings follow the selected entry",
    "synced": "Synced",
    "pending": "Preparing",
    "error": "Sync failed",
    "name": "Name",
    "domain": "Allowed domain",
    "zoneId": "Zone ID",
    "token": "API Token",
    "keepToken": "Leave blank to keep the current credential",
    "addPreset": "Add domain preset",
    "save": "Save",
    "cancel": "Cancel",
    "edit": "Edit",
    "delete": "Delete",
    "deleteConfirm": "Delete this domain preset? Presets in use cannot be deleted.",
    "refresh": "Refresh",
    "failed": "Operation failed. Please retry.",
    "loading": "Loading",
    "capacity": "Records used / quota",
    "accountQuota": "Account quota",
    "unchecked": "Not checked",
    "check": "Check DNS",
    "actions": "Actions",
    "bindings": "Node domains",
    "node": "Node or pool",
    "records": "Managed records",
    "status": "Status",
    "deletedNode": "Deleted node",
    "cleaning": "Cleaning up",
    "retained": "Old records retained",
    "sync": "Sync again",
    "cleanup": "Remove records",
    "cleanupConfirm": "Clients using these old domains will lose access after cleanup. Continue?"
  },
  "balancer": {
    "dynamicLoad": "Dynamic load allocation",
    "bandwidthThreshold": "Bandwidth utilization threshold (%)",
    "connectionThreshold": "Active connection threshold",
    "loadConfirm": "Confirmation period (seconds)",
    "loadCooldown": "Reassignment cooldown (seconds)",
    "carrierRouting": "Carrier DNS routing",
    "carrierLines": "Carrier routes",
    "availableBandwidth": "Available bandwidth (Mbps)",
    "useConnections": "Blank: use connections",
    "carrierNotReady": "Authoritative DNS is not configured for carrier routing",
    "carrierDataUnavailable": "Carrier IP data is missing or expired",
    "bandwidthLoad": "Bandwidth utilization {{value}}%",
    "connectionLoad": "Active connections {{value}}",
    "loadUnavailable": "Load unavailable; assignments retained",
    "linkStates": "Landing link status",
    "dynamicLoadRule": "Use smoothed load within the same priority. Blank bandwidth uses connections. Reassign gradually after sustained overload; retain assignments when measurements are missing.",
    "carriers": {"default": "Default", "telecom": "China Telecom", "unicom": "China Unicom", "mobile": "China Mobile"},
    "trafficLite": "Lite traffic",
    "trafficLocal": "Local traffic",
    "trafficUnavailable": "Data unavailable",
    "trafficUnlimited": "Unlimited traffic",
    "trafficRemaining": "{{percent}}% remaining",
    "quotaLow": "Remaining quota is low",
    "scheduling": "Automatic scheduling",
    "healthCheck": "Link health checks",
    "quotaScheduling": "Schedule by remaining quota",
    "selectionStrategy": "Frontend selection",
    "manualPriority": "Weighted allocation within priority",
    "lowestLatency": "Prefer a single lowest-latency frontend",
    "quotaPercent": "Remaining quota threshold (%)",
    "latencyTarget": "Landing probe target",
    "bindLatencyTarget": "Bind a TCP landing to this pool in node management first.",
    "landings": "Landing failover",
    "events": "Switch history",
    "createLandingPool": "Create landing pool",
    "editLandingPool": "Edit landing pool",
    "subscriptionLine": "Subscription line",
    "landingPoolHelp": "Keep the original subscription line. Select the first available landing and return to the primary after stable recovery.",
    "primaryLanding": "Primary",
    "backupLanding": "Backup {{index}}",
    "moveUp": "Move up",
    "moveDown": "Move down",
    "searchLandings": "Search landing name or IP",
    "activeLanding": "Current landing",
    "noActiveLanding": "No available landing",
    "deleteLandingPoolHelp": "Remove failover settings and restore the original landing? Nodes will be kept.",
    "noLandingPools": "No landing pools",
    "eventTime": "Time",
    "eventReason": "Reason",
    "previousSelection": "Before",
    "currentSelection": "After",
    "noAvailableMembers": "No available members",
    "noEvents": "No switch history",
    "reason": {
      "link_failed": "Link failed",
      "probe_stale": "Probe expired",
      "healthy": "Available",
      "offline": "Offline or quota protection",
      "disabled": "Disabled",
      "incompatible": "Incompatible settings",
      "no_address": "No valid address",
      "port_failed": "Port unreachable",
      "probe_pending": "Waiting for probes",
      "latency_failed": "Probe target unreachable",
      "agent_required": "Agent upgrade required",
      "heartbeat_only": "Using node status"
    },
    "event": {
      "selection_changed": "Frontend candidates changed",
      "landing_changed": "Landing switched",
      "dns_failed": "DNS sync failed",
      "dns_recovered": "DNS sync recovered"
    },
    "dnsPriorityRule": "Lower numbers have higher priority. Users are assigned consistently by weight among eligible members.",
    "dnsMode": "DNS scheduling",
    "serverId": "Server ID",
    "apiUrl": "PowerDNS API URL",
    "provider": "DNS provider",
    "endpoint": "Connection address",
    "poolSwitch": "Enable {{name}}",
    "advanced": "Advanced",
    "title": "Frontend allocation",
    "pools": "Entry pools",
    "presets": "DNS settings",
    "createPool": "Create pool",
    "editPool": "Edit pool",
    "createPreset": "Add DNS settings",
    "editPreset": "Edit DNS settings",
    "name": "Name",
    "domain": "Entry hostname",
    "baseDomain": "PowerDNS zone / CF domain",
    "dnsPreset": "DNS settings",
    "chooseDnsPreset": "Choose a DNS configuration",
    "members": "Frontend nodes",
    "realitySyncEnabled": "Unify Reality settings automatically",
    "realitySyncRule": "Saving applies these settings to all frontend nodes in the pool. Direct subscriptions using previous settings must be updated.",
    "realityServerName": "Reality server name",
    "realityServerPort": "Reality handshake port",
    "realityPrivateKey": "Reality private key",
    "realityPublicKey": "Reality public key",
    "realityShortId": "Reality short ID",
    "realityKeepPrivateKey": "Leave blank to keep the current private key",
    "realityDerivedPublicKey": "Derived from the private key when saved",
    "realityGenerate": "Generate keys and short ID",
    "realityGenerateFailed": "Failed to generate Reality keys. Please retry.",
    "syncReality": "Sync to frontend nodes",
    "priority": "Priority",
    "selectFirst": "Select the first node to set protocol and public port",
    "protocol": "Protocol",
    "state": "Status",
    "actions": "Actions",
    "enabled": "Enabled",
    "disabled": "Disabled",
    "online": "Online",
    "offline": "Offline",
    "choose": "Select",
    "save": "Save",
    "saving": "Saving",
    "cancel": "Cancel",
    "edit": "Edit",
    "delete": "Delete",
    "refresh": "Refresh",
    "retry": "Retry",
    "loading": "Loading",
    "syncDns": "Sync DNS",
    "failed": "Request failed. Try again.",
    "confirmDelete": "Delete this item? Referenced profiles and pools cannot be deleted.",
    "noPools": "No entry pools",
    "noPresets": "No DNS settings",
    "noMembers": "No available VLESS Reality TCP nodes",
    "keepToken": "Leave blank to keep the saved token",
    "poolOption": "Pool: {{name}}",
    "poolReadFailed": "Could not load entry pools. Try again.",
    "searchNodes": "Search name or IP",
    "noSearchResults": "No matching nodes",
    "compatibility": {
      "machine": "No server assigned",
      "parent": "Select the parent node that runs the service",
      "entry": "Select an independent entry node",
      "protocol": "Requires VLESS Reality",
      "tls": "Requires Reality TLS mode",
      "network": "Requires TCP transport",
      "settings": "Entry settings are incomplete or unsupported by the core",
      "invalidPort": "Public port must be a single port from 1 to 65535",
      "missingPublicKey": "Missing Reality public key",
      "missingServerName": "Missing Reality handshake domain",
      "port": "Public port differs from the first node",
      "public_key": "Reality public key differs from the first node",
      "short_id": "Reality short ID differs from the first node",
      "server_name": "Reality handshake domain differs from the first node",
      "server_port": "Reality handshake port differs from the first node",
      "flow": "VLESS flow differs from the first node",
      "encryptionEnabled": "VLESS Encryption switch differs from the first node",
      "encryption": "VLESS client encryption differs from the first node",
      "decryption": "VLESS server decryption differs from the first node",
      "sameMachine": "Select one entry node per server",
      "sameHost": "Member addresses must differ"
    },
    "latencyBalanced": "Allocate across low-latency frontends",
    "cyclePriority": "Prefer the nearest quota reset",
    "weight": "Weight",
    "assignedUsers": "{{count}} users assigned",
    "resetDate": "Quota reset"
  },
  "logs": {
    "blockUsers": "By user",
    "blockCount": "Blocked requests",
    "lastBlocked": "Last blocked",
    "blockDetails": "View details",
    "backToUsers": "Back to users",
    "actions": "Actions",

    "blockRetention": "Retention",
    "block": "Routing blocks",
    "rule": "Matched rule",
    "ruleFilter": "Rule name or ID",
    "target": "Destination domain / IP",
    "port": "Destination port",
    "network": "Network",
    "unknownUser": "Unknown user",

    "settings": {
      "title": "Log settings",
      "description": "Choose which logs the panel records and how many days to keep them.",
      "modules": { "system": "Panel system logs", "audit": "Admin activity logs", "agent": "Agent logs", "user": "User logs", "access": "Proxy access records" },
      "enabled": "Recording", "disabled": "Off", "retention": "Keep for", "days": "days",
      "daysLabel": "{{module}} retention days",
      "expiry": "Keep logs for 1–365 days. Expired records are deleted automatically, including when recording is off. Shortening retention permanently deletes older records. Machine settings control local Agent logs.",
      "invalidDays": "Enter a whole number from 1 to 365.", "loadFailed": "Unable to load log settings. Try again.",
      "saveFailed": "Unable to save log settings. Try again.", "save": "Save settings", "saving": "Saving…", "saved": "Saved"
    },
    "userName": "User",
    "userFilter": "User email or ID",
    "navigation": "Logs",
    "system": "System logs",
    "agent": "Agent logs",
    "user": "User logs",
    "time": "Time",
    "machine": "Machine",
    "node": "Node",
    "machine_id": "Machine ID",
    "node_id": "Node ID",
    "allNodes": "All nodes",
    "loadingNodes": "Loading nodes",
    "nodesLoadFailed": "Failed to load nodes. Retry or enter a node ID.",
    "source": "Source",
    "level": "Level",
    "message": "Message",
    "ip": "Source IP",
    "event": "Event",
    "result": "Result",
    "count": "Occurrences",
    "limit": "Limit at the time",
    "keyword": "Search logs",
    "start_at": "Start time",
    "end_at": "End time",
    "date": "Date",
    "all": "All",
    "refresh": "Refresh",
    "search": "Search",
    "clear": "Clear filters",
    "retry": "Retry",
    "loading": "Loading logs",
    "empty": "No matching logs",
    "loadFailed": "Failed to load logs. Please retry.",
    "limited": "Large log files: showing records from the last 2 MB of each file for the selected date.",
    "seconds": "{{count}} seconds",
    "sources": {
      "panel": "Panel runtime",
      "audit": "Admin actions",
      "agent": "Agent",
      "xray": "Xray",
      "singbox": "sing-box"
    },
    "levels": {
      "debug": "Debug",
      "info": "Info",
      "warn": "Warning",
      "error": "Error",
      "fatal": "Critical"
    },
    "events": {
      "login": "Login",
      "password_change": "Password change",
      "password_reset": "Password reset",
      "connection_limit": "Connection limit exceeded",
      "connection_rate": "New connection rate exceeded",
      "device_limit": "Device limit exceeded",
      "speed_limit": "Bandwidth throttled"
    },
    "results": {
      "success": "Succeeded",
      "wrong_password": "Incorrect password",
      "wrong_code": "Incorrect code",
      "banned": "Account disabled",
      "rate_limited": "Login limited",
      "rejected": "Rejected",
      "throttled": "Throttled"
    }
  },
  "database": {
    "title": "Database",
    "refresh": "Refresh",
    "loading": "Loading database storage…",
    "loadFailed": "Could not load database storage. Please retry.",
    "retry": "Retry",
    "databaseSize": "Main database file",
    "allocatedSize": "Tables and indexes",
    "tableCount": "Tables",
    "databaseType": "Database type",
    "reusableSize": "Reusable free space",
    "tables": "Table storage",
    "search": "Search tables",
    "sort": "Sort by",
    "sortSize": "Storage size",
    "sortName": "Table name",
    "sortRows": "Estimated rows",
    "tableName": "Table",
    "usage": "Total",
    "dataSize": "Data",
    "indexSize": "Indexes",
    "estimatedRows": "Estimated rows",
    "empty": "No matching tables",
    "sqliteSizeNote": "Main file pages only; write-ahead logs are excluded. Row estimates are unavailable in SQLite.",
    "sqliteUnavailable": "Per-table sizes are unavailable in this SQLite build. Total storage and history cleanup remain available.",
    "cleanup": "History cleanup",
    "preview": "View records to clean up",
    "preparing": "Loading records…",
    "unavailable": "Table unavailable",
    "completed": "Deleted {{count}} records in this run",
    "deletedRows": "Deleted {{count}}",
    "moreRemaining": "Expired records remain. View them again to continue cleanup.",
    "confirmTitle": "Confirm history cleanup",
    "confirmNote": "There are {{count}} expired records. This run deletes up to {{limit}} per category.",
    "eligible": "{{count}} expired",
    "before": "Delete records before {{time}}",
    "irreversible": "Deletion cannot be undone. Confirm you have any required backup. These query results expire in 10 minutes.",
    "cancel": "Cancel",
    "confirm": "Confirm cleanup",
    "cleaning": "Cleaning…",
    "requestFailed": "Request failed. Please retry.",
    "targets": {
      "access": {
        "name": "Access records",
        "retention": "Keep the last 7 days"
      },
      "machine": {
        "name": "Machine monitoring history",
        "retention": "Keep the last 24 hours"
      },
      "audit": {
        "name": "Administrator audit logs",
        "retention": "Keep the last 3 months"
      },
      "telegram": {
        "name": "Telegram message deduplication",
        "retention": "Keep the last 7 days; account bindings are preserved"
      }
    },
    "unknownTable": "No description available",
    "tableDescriptions": {
      "v2_user_event_log": "User login, password and limit events",
      "v2_agent_log": "Agent and kernel runtime logs",
      "v2_node_report_batch": "Node report batches and settlement deduplication",
      "v2_proxy_access_log": "Access records",
      "v2_stat_route_minute": "Per-minute user route traffic",
      "v2_stat_route_hour": "Hourly user route traffic",
      "v2_stat_proxy_traffic": "Node and machine proxy traffic",
      "v2_admin_audit_log": "Administrator audit logs",
      "v2_server_machine_load_history": "Machine monitoring history",
      "v2_stat_user_route_source": "User route sources and billed traffic",
      "failed_jobs": "Failed queue jobs",
      "v2_stat_user_server": "User traffic by node",
      "v2_inbound_ip": "Inbound IP location and property cache",
      "v2_stat_server": "Daily node traffic",
      "v2_stat_user": "Daily user traffic",
      "v2_stat_user_inbound_ip": "User inbound IP usage",
      "v2_subscription_hub_sources": "Subscription aggregation sources",
      "v2_mail_log": "Mail delivery records",
      "v2_subscribe_templates": "Subscription configuration templates",
      "v2_subscription_stat": "Subscription request summaries",
      "v2_server": "Proxy node configuration",
      "personal_access_tokens": "API access tokens",
      "v2_order": "User orders",
      "v2_gift_card_code": "Gift card redemption codes",
      "v2_gift_card_usage": "Gift card usage",
      "v2_subscription_hub_chain_rules": "Subscription aggregation chain rules",
      "v2_user": "User accounts and plans",
      "v2_subscription_block": "Individual subscription request times",
      "v2_telegram_node_incidents": "Telegram node incident deduplication",
      "v2_server_machine": "Machine configuration and current status",
      "v2_subscription_batch": "Subscription statistics batch deduplication",
      "v2_telegram_admin_notifications": "Telegram administrator notifications",
      "v2_telegram_business_notifications": "Telegram business notifications",
      "v2_traffic_reset_logs": "User traffic reset history",
      "v2_commission_log": "Commission records",
      "v2_gift_card_template": "Gift card templates",
      "v2_plugins": "Plugin configuration and enabled status",
      "v2_server_route": "Node routing rules",
      "v2_settings": "Panel settings",
      "v2_subscription_restrictions": "Subscription client restrictions",
      "v2_telegram_bot_bindings": "Telegram account bindings",
      "v2_telegram_bot_reminders": "Telegram expiry and traffic reminders",
      "v2_telegram_bot_updates": "Telegram message deduplication",
      "v2_ticket": "User support tickets",
      "v2_mail_templates": "Mail templates",
      "v2_notice": "Panel announcements",
      "v2_plan": "Plans and pricing",
      "v2_server_group": "Node permission groups",
      "v2_stat": "Order, commission and registration statistics",
      "v2_stat_server_name": "Node name history",
      "migrations": "Database migration history",
      "v2_coupon": "Coupon configuration",
      "v2_invite_code": "User invitation codes",
      "v2_knowledge": "Knowledge base articles",
      "v2_log": "Legacy system logs",
      "v2_payment": "Payment provider configuration",
      "v2_telegram_bot_configs": "Telegram bot configuration",
      "v2_telegram_node_states": "Telegram node online status",
      "v2_ticket_message": "Support ticket messages",
      "v2_server_hysteria": "Legacy Hysteria nodes",
      "v2_server_shadowsocks": "Legacy Shadowsocks nodes",
      "v2_server_trojan": "Legacy Trojan nodes",
      "v2_server_vless": "Legacy VLESS nodes",
      "v2_server_vmess": "Legacy VMess nodes",
      "v2_server_log": "Legacy node logs",
      "v2_server_stat": "Legacy node statistics",
      "v2_stat_traffic_hour": "Legacy hourly user traffic",
      "v2_stat_node_hour": "Legacy hourly node traffic totals",
      "v2_stat_node_hour_detail": "Legacy hourly node traffic details",
      "v2_stat_node_minute_detail": "Legacy per-minute node traffic details"
    }
  },
  "statistics": {
    "subscription": { "title": "Subscription statistics", "users": "Subscriptions by user", "last90": "Last 90 days", "client": "Client and version", "clients": "Clients", "requests": "Requests", "results": "Success / Failed", "resultCounts": "{{success}} / {{failure}}", "first": "First request", "last": "Last request", "time": "Request time", "status": "Response status", "format": "Subscription format", "date": "Date", "daily": "Daily totals", "recent": "Requests (7 days)", "history": "View records", "historyType": "Record type", "back": "Back to users", "close": "Close records", "refresh": "Refresh", "searchUser": "User email or ID", "searchClient": "Search clients" },
    "accessBack": "Back",
    "accessLogs": "Access records", "destination": "Domain / IP", "targetPort": "Target port", "connectedAt": "Connection time",
    "accessUsers": "Access by user", "accessCount": "Connections", "lastAccess": "Last access", "accessSort": "Sort by", "accessSortCount": "Most connections", "accessSortTime": "Most recent",
    "refreshRecords": "Refresh", "nodeSearchPlaceholder": "Node name or ID", "targetSearchPlaceholder": "Full or partial domain / IP",
    "lastYear": "Last year", "dailyHeatmap": "Daily usage", "trafficIntensity": "Usage intensity", "less": "Less", "more": "More",
    "noRecord": "No record", "wholeDays": "Only daily totals are available before the last 30 days. Select complete days.",
    "nodeUsage": "Node usage",
    "machineStatistics": "Server usage",
    "machine": "Server",
    "machineName": "Server name",
    "searchMachine": "Search servers",
    "machineRank": "Server usage ranking",
    "operator": "Provider",
    "ipProperties": {
      "fraudScore": "Fraud risk score",
      "asDomain": "AS domain",
      "connectionType": "Connection type",
      "mobileBrand": "Mobile carrier brand",
      "district": "District",
      "connections": {"DIAL": "Dial-up", "DSL": "Broadband / cable / fiber / mobile", "COMP": "Corporate", "T1": "Data center / transit", "SAT": "Satellite"},
      "title": "IP properties",
      "view": "View IP properties for {ip}",
      "close": "Close IP properties",
      "networkType": "Network type",
      "networkName": "Network name",
      "proxyTitle": "Proxy detection",
      "riskTitle": "Risk and crawler detection",
      "yes": "Yes",
      "no": "No",
      "unknown": "Unavailable",
      "is_proxy": "Proxy",
      "is_vpn": "VPN",
      "is_tor": "Tor exit",
      "is_data_center": "Data center",
      "is_public_proxy": "Public proxy",
      "is_web_proxy": "Web proxy",
      "is_residential_proxy": "Residential proxy",
      "is_consumer_privacy_network": "Consumer privacy network",
      "is_enterprise_private_network": "Enterprise private network",
      "is_spammer": "Spammer",
      "is_scanner": "Scanner",
      "is_botnet": "Botnet",
      "is_bogon": "Bogon",
      "is_web_crawler": "Search crawler",
      "is_ai_crawler": "AI crawler",
      "types": {
        "COM": "Commercial",
        "ORG": "Organization",
        "GOV": "Government",
        "MIL": "Military",
        "EDU": "Education",
        "LIB": "Library",
        "CDN": "Content delivery network",
        "ISP": "Fixed-line ISP",
        "MOB": "Mobile ISP",
        "ISP/MOB": "Fixed-line / mobile ISP",
        "DCH": "Data center",
        "SES": "Search crawler",
        "AIC": "AI crawler",
        "RSV": "Reserved"
      }
    },
    "minimumTraffic": "Hide traffic below (MB)", "trafficFilter": "Traffic filter", "hideTrafficBelow": "Hide below",
    "trafficMinimumSuffix": "MB", "trafficFilterApplied": "Hide records below {{value}} MB",
    "showAllTraffic": "Show all", "applyTrafficFilter": "Apply",
    "observedProvinces": "Observed provinces",
    "inboundIp": "Inbound IPs", "inboundUsers": "User inbound IPs", "ipCount": "IP count", "firstSeen": "First seen", "lastSeen": "Last seen",
    "backToInbound": "Back to inbound IPs", "filterProvince": "Filter province", "allProvinces": "All provinces / regions",
    "ipAddress": "IP address", "location": "Location", "asn": "ASN", "unknown": "Unknown", "inboundCount": "{{count}} IPs",
    "last24": "Last 24 hours", "last14": "Last 14 days", "all": "All", "startTime": "Start time", "endTime": "End time",
    "confirm": "Confirm", "cancel": "Cancel", "previousMonth": "Prev", "nextMonth": "Next",
    "wholeHours": "Use whole hours for past dates or ranges spanning multiple days.", "searchNode": "Search nodes", "nodeName": "Node name", "asc": "Ascending", "desc": "Descending",
    "direct": "Direct", "effectiveRate": "Applied rate",
    "hour": "Hourly", "perPage": "Rows per page", "backToUsers": "Back to user ranking",
    "navigation": "Statistics", "overview": "Traffic statistics", "nodeStatistics": "Node usage", "userStatistics": "User statistics",
    "trend": "Total traffic trend", "nodeRank": "Node usage ranking", "userRank": "User traffic ranking", "userDetails": "Traffic by user and node",
    "period": "Date range", "last30": "Last 30 days", "last7": "Last 7 days", "today": "Today", "custom": "Custom",
    "unit": "Group by", "day": "Day", "week": "Week", "month": "Month", "metric": "Traffic measure", "actual": "Actual traffic", "billed": "Billed traffic",
    "startDate": "Start date", "endDate": "End date", "to": "to", "apply": "Apply", "invalidRange": "Select a valid start and end date.",
    "total": "Total traffic", "upload": "Upload", "download": "Download", "rank": "Rank", "node": "Node", "user": "User", "actions": "Actions",
    "viewDetails": "View details", "loading": "Loading", "empty": "No data", "loadFailed": "Could not load data. Try again.", "retry": "Retry",
    "page": "Page {{page}} / {{pages}}, {{count}} records", "previous": "Previous", "next": "Next",
    "searchUser": "Search users", "searchPlaceholder": "User email or ID", "search": "Search", "clear": "Clear",
    "inboundSearchPlaceholder": "User email, ID or IP", "searchIp": "Search IPs", "ipSearchPlaceholder": "Full or partial IP address",
    "chooseUser": "Search for a user or select one from the ranking.", "filterNode": "Filter nodes", "allNodes": "All nodes",
    "entryTotal": "Entry total", "relayTotal": "Relay total", "date": "Date", "position": "Traffic type", "entry": "Entry", "relay": "Relay"
  },
  "telegramBot": {
    "userReminders": "User reminders", "nodeNotifications": "Node notifications", "nodeNotificationSaved": "Node notification settings saved",
    "groupLink": "Telegram group link", "groupLinkInvalid": "Enter a complete HTTP or HTTPS group link.",
    "groupNodeSettings": "Group settings", "groupNodeSaved": "Group settings saved",
    "auto_approve_join": "Review join requests automatically", "notify_node_offline": "Node offline alerts",
    "notify_xray_crash": "Xray core crash alerts",
    "joinGroups": "Group IDs to review", "joinGroupsPlaceholder": "One group ID per line, e.g. -1001234567890",
    "joinGroupsInvalid": "Enter up to 20 valid negative group IDs; at least one is required when review is enabled.",
    "joinGroupRequirement": "The bot needs group administrator and invite permissions. The invite link must require approval.",
    "nodeOfflineMinutes": "Notify after no heartbeat for (minutes)",
    "nodeOfflineRecipients": "Sent to administrators linked to the Telegram Bot.",
    "businessNotifications": "Tickets & payments", "businessNotificationSaved": "Ticket and payment settings saved",
    "businessNotificationTypes": { "notify_ticket": "Ticket notifications", "allow_ticket_reply": "Ticket replies", "notify_payment": "Payment notifications" },
    "adminNotifications": "Admin notifications", "adminNotificationSaved": "Admin notification settings saved",
    "adminNotificationTypes": { "device": "Device limit alerts", "connection": "Connection limit alerts" },
    "adminRecipients": "Admin recipients (Telegram numeric IDs)",
    "adminRecipientsPlaceholder": "One ID per line; each recipient must first send /start to the bot privately",
    "adminRecipientsInvalid": "Enter up to 20 distinct valid Telegram numeric IDs; at least one is required when alerts are enabled",
    "adminNotificationInterval": "Repeat alert interval (minutes)",
    "reminders": "Reminders", "reminderSaved": "Reminder settings saved",
    "reminderTypes": { "expiring": "Upcoming expiry", "expired": "Expired subscription", "device": "Device limit exceeded", "connection": "Connection limit exceeded" },
    "reminderDays": "Days before expiry", "reminderInterval": "Limit reminder interval (minutes)",
    "reminderRange": "Enter an integer from 1 to {{max}}",
    "operationFailed": "The operation failed. Check the settings and retry.",
    "title": "Telegram Bot", "settings": "Bot settings", "bindings": "User management",
    "actions": "Actions", "unbind": "Unlink", "unbindConfirm": "Unlink this user?",
    "unbindDescription": "Remove the link between this Telegram user and the panel account. The account, plan and subscription are kept. The user can send their subscription link to bind again.",
    "unbindSuccess": "User unlinked", "unbindFailed": "Could not unlink the user. Please retry.",
    "loading": "Loading", "loadFailed": "Could not load data. Please retry.", "retry": "Retry",
    "enabledState": "Status", "enabled": "Enabled", "disabled": "Disabled",
    "connectionState": "Message connection", "username": "Bot account", "notChecked": "Not checked",
    "lastReceived": "Last message received", "neverReceived": "No messages received yet",
    "pendingMessages": "Messages awaiting delivery", "checkWarning": "The check found a message connection issue",
    "testMessage": "Send test message", "testRecipient": "Test recipient (numeric Telegram ID)",
    "recipientPlaceholder": "The recipient must first send /start in a private chat with the bot",
    "recipientRequired": "Enter a valid numeric Telegram ID; usernames and groups are not supported",
    "token": "Bot token", "tokenRequired": "Enter a bot token",
    "showToken": "Show bot token", "hideToken": "Hide bot token",
    "tokenPlaceholder": "Enter the bot token", "tokenInvalid": "Enter a valid bot token",
    "urlInvalid": "Enter a valid HTTPS base URL without the receiver path, credentials or query parameters",
    "saveConfirm": "Disable the bot and save the new settings?", "saveDescription": "The current bot will be disabled before the new settings are saved. Existing account links are kept. Enable the bot again after saving.",
    "stopFailed": "The bot could not be fully disabled. The new settings were not saved. Please retry.",
    "webhookUrl": "Message receiver URL", "webhookBaseUrl": "Webhook Base URL",
    "webhookDocs": "View Telegram Webhook documentation", "urlRequired": "Enter the Webhook Base URL",
    "save": "Save", "processing": "Processing", "check": "Check connection", "refresh": "Refresh status",
    "enable": "Enable", "disable": "Disable", "cancel": "Cancel", "confirm": "Confirm",
    "enableConfirm": "Enable Telegram Bot?", "enableDescription": "The bot will start receiving messages and linking accounts.",
    "disableConfirm": "Disable Telegram Bot?", "disableDescription": "Message processing stops. Existing account links are kept.",
    "email": "Account email", "telegramId": "Telegram ID", "telegramUsername": "Telegram username", "boundAt": "Linked at",
    "searchPlaceholder": "Search email, Telegram ID or username", "search": "Search",
    "total": "{{count}} linked accounts", "previous": "Previous", "next": "Next", "page": "Page {{current}} / {{total}}",
    "status": { "unconfigured": "Not configured", "unchecked": "Not checked", "error": "Connection error", "connected": "Receiver URL registered", "disconnected": "Receiver URL not registered" },
    "success": { "saveApplied": "Settings saved and bot re-enabled", "save": "Settings saved", "saveStopped": "Settings saved. Enable the bot again.", "check": "Telegram API check completed", "enable": "Bot enabled", "disable": "Bot disabled", "testMessage": "Test message sent. Check Telegram." }
  },
  "giftCard": {
    "title": "Gift Card Management",
    "description": "Manage gift card templates, redemption codes, and usage records.",
    "tabs": {
      "templates": "Template Management",
      "codes": "Redemption Code Management",
      "usages": "Usage Records",
      "statistics": "Statistics"
    },
    "template": {
      "title": "Template Management",
      "description": "Manage gift card templates, including creating, editing, and deleting templates.",
      "table": {
        "title": "Template List",
        "columns": {
          "id": "ID",
          "name": "Name",
          "type": "Type",
          "status": "Status",
          "sort": "Sort",
          "rewards": "Rewards",
          "created_at": "Created At",
          "actions": "Actions",
          "no_rewards": "No Rewards"
        }
      },
      "form": {
        "add": "Add Template",
        "edit": "Edit Template",
        "name": {
          "label": "Template Name",
          "placeholder": "Please enter template name",
          "required": "Please enter template name"
        },
        "sort": {
          "label": "Sort",
          "placeholder": "Smaller numbers appear first"
        },
        "type": {
          "label": "Type",
          "placeholder": "Please select gift card type"
        },
        "description": {
          "label": "Description",
          "placeholder": "Please enter gift card description"
        },
        "status": {
          "label": "Status",
          "description": "When disabled, this template cannot generate or redeem new gift cards."
        },
        "display": {
          "title": "Display Effect"
        },
        "theme_color": {
          "label": "Theme Color"
        },
        "icon": {
          "label": "Icon",
          "placeholder": "Please enter icon URL"
        },
        "background_image": {
          "label": "Background Image",
          "placeholder": "Please enter background image URL"
        },
        "conditions": {
          "title": "Usage Conditions",
          "new_user_max_days": {
            "label": "New User Registration Days Limit",
            "placeholder": "Example: 7 (Only for users registered within 7 days)"
          },
          "new_user_only": {
            "label": "New Users Only"
          },
          "paid_user_only": {
            "label": "Paid Users Only"
          },
          "require_invite": {
            "label": "Require Invitation Relationship"
          },
          "allowed_plans": {
            "label": "Allowed Plans",
            "placeholder": "Select plans allowed for redemption (leave empty for no restriction)"
          },
          "disallowed_plans": {
            "label": "Disallowed Plans",
            "placeholder": "Select plans forbidden for redemption (leave empty for no restriction)"
          }
        },
        "limits": {
          "title": "Usage Limits",
          "max_use_per_user": {
            "label": "Max Uses Per User",
            "placeholder": "Leave empty for no limit"
          },
          "cooldown_hours": {
            "label": "Cooldown Hours for Same Type",
            "placeholder": "Leave empty for no limit"
          },
          "invite_reward_rate": {
            "label": "Inviter Reward Rate",
            "placeholder": "Example: 0.2 (represents 20%)",
            "description": "When user has an inviter, inviter reward = balance reward × this rate"
          }
        },
        "rewards": {
          "title": "Rewards",
          "balance": {
            "label": "Reward Balance (Yuan)",
            "short_label": "Balance",
            "placeholder": "Please enter reward amount (Yuan)"
          },
          "transfer_enable": {
            "label": "Reward Traffic (GB)",
            "short_label": "Traffic",
            "placeholder": "Please enter reward traffic (GB)"
          },
          "expire_days": {
            "label": "Extend Validity (Days)",
            "short_label": "Validity",
            "placeholder": "Please enter extension days"
          },
          "transfer": {
            "label": "Reward Traffic (Bytes)",
            "placeholder": "Please enter reward traffic (bytes)"
          },
          "days": {
            "label": "Extend Validity (Days)",
            "placeholder": "Please enter extension days"
          },
          "device_limit": {
            "label": "Increase Device Count",
            "short_label": "Devices",
            "placeholder": "Please enter increased device count"
          },
          "reset_package": {
            "label": "Reset Monthly Traffic",
            "description": "When enabled, redemption will clear the user's current plan's used traffic."
          },
          "reset_count": {
            "description": "This type of card will reset the user's monthly traffic usage."
          },
          "task_card": {
            "description": "Specific rewards for task gift cards will be configured in the task system."
          },
          "plan_id": {
            "label": "Specified Plan",
            "short_label": "Plan",
            "placeholder": "Please select a plan"
          },
          "plan_validity_days": {
            "label": "Plan Validity (Days)",
            "short_label": "Plan Validity",
            "placeholder": "Leave empty to use plan default validity"
          },
          "random_rewards": {
            "label": "Random Reward Pool",
            "add": "Add Random Reward Item",
            "weight": "Weight"
          }
        },
        "special_config": {
          "title": "Special Configuration",
          "start_time": {
            "label": "Event Start Time",
            "placeholder": "Please select start date"
          },
          "end_time": {
            "label": "Event End Time",
            "placeholder": "Please select end date"
          },
          "festival_bonus": {
            "label": "Festival Reward Multiplier",
            "placeholder": "Example: 1.5 (represents 1.5x)"
          }
        },
        "submit": {
          "saving": "Saving...",
          "save": "Save"
        }
      },
      "actions": {
        "edit": "Edit",
        "delete": "Delete",
        "deleteConfirm": {
          "title": "Confirm Delete",
          "description": "This action will permanently delete this template. Are you sure you want to continue?",
          "confirmText": "Delete"
        }
      }
    },
    "code": {
      "title": "Redemption Code Management",
      "form": {
        "generate": "Generate Redemption Codes",
        "template_id": {
          "label": "Select Template",
          "placeholder": "Please select a template to generate redemption codes"
        },
        "count": {
          "label": "Generation Count"
        },
        "prefix": {
          "label": "Custom Prefix (Optional)"
        },
        "expires_hours": {
          "label": "Validity (Hours)"
        },
        "max_usage": {
          "label": "Max Usage Count"
        },
        "download_csv": "Export CSV",
        "submit": {
          "generating": "Generating...",
          "generate": "Generate Now"
        }
      },
      "description": "Manage gift card redemption codes, including generation, viewing, and exporting codes.",
      "generate": {
        "title": "Generate Redemption Codes",
        "template": "Select Template",
        "count": "Generation Count",
        "prefix": "Custom Prefix",
        "expires_hours": "Validity (Hours)",
        "max_usage": "Max Usage Count",
        "submit": "Generate"
      },
      "table": {
        "title": "Redemption Code List",
        "columns": {
          "id": "ID",
          "code": "Redemption Code",
          "template_name": "Template Name",
          "status": "Status",
          "expires_at": "Expires At",
          "usage_count": "Used Count",
          "max_usage": "Available Count",
          "created_at": "Created At"
        }
      },
      "actions": {
        "enable": "Enable",
        "disable": "Disable",
        "export": "Export",
        "exportConfirm": {
          "title": "Confirm Export",
          "description": "This will export all redemption codes from the selected batch as a text file. Are you sure you want to continue?",
          "confirmText": "Export"
        }
      },
      "status": {
        "0": "Unused",
        "1": "Used",
        "2": "Disabled",
        "3": "Expired"
      }
    },
    "usage": {
      "title": "Usage Records",
      "description": "View gift card usage records and detailed information.",
      "table": {
        "columns": {
          "id": "ID",
          "code": "Redemption Code",
          "template_name": "Template Name",
          "user_email": "User Email",
          "rewards_given": "Rewards Given",
          "invite_rewards": "Invitation Rewards",
          "multiplier_applied": "Multiplier Applied",
          "ip_address": "IP Address",
          "created_at": "Usage Time",
          "actions": "Actions"
        }
      },
      "actions": {
        "view": "View Details"
      }
    },
    "statistics": {
      "title": "Statistics",
      "description": "View gift card statistics and usage analysis.",
      "total": {
        "title": "Overall Statistics",
        "templates_count": "Total Templates",
        "active_templates_count": "Active Templates",
        "codes_count": "Total Redemption Codes",
        "used_codes_count": "Used Redemption Codes",
        "usages_count": "Usage Records"
      },
      "daily": {
        "title": "Daily Usage",
        "chart": "Usage Trend Chart"
      },
      "type": {
        "title": "Type Statistics",
        "chart": "Type Distribution Chart"
      },
      "dateRange": {
        "label": "Date Range",
        "start": "Start Date",
        "end": "End Date"
      }
    },
    "types": {
      "1": "General Gift Card",
      "2": "Plan Gift Card",
      "3": "Mystery Gift Card",
      "4": "Task Gift Card"
    },
    "common": {
      "search": "Search gift cards...",
      "reset": "Reset",
      "filter": "Filter",
      "export": "Export",
      "refresh": "Refresh",
      "back": "Back",
      "close": "Close",
      "confirm": "Confirm",
      "cancel": "Cancel",
      "enabled": "Enabled",
      "disabled": "Disabled",
      "loading": "Loading...",
      "noData": "No Data",
      "success": "Operation Successful",
      "error": "Operation Failed"
    },
    "messages": {
      "formInvalid": "Please check if the form input is correct",
      "templateCreated": "Template created successfully",
      "templateUpdated": "Template updated successfully",
      "templateDeleted": "Template deleted successfully",
      "codeGenerated": "Redemption codes generated successfully",
      "generateCodeFailed": "Failed to generate redemption codes",
      "codeStatusUpdated": "Redemption code status updated successfully",
      "updateCodeStatusFailed": "Failed to update redemption code status",
      "codesExported": "Redemption codes exported successfully",
      "createTemplateFailed": "Failed to create template",
      "updateTemplateFailed": "Failed to update template",
      "deleteTemplateFailed": "Failed to delete template",
      "loadDataFailed": "Failed to load data",
      "codesGenerated": "Redemption codes generated successfully"
    }
  },
  "user": {
    "column_settings": "Columns",
    "extend_duration": {
      "title": "Extend duration",
      "selected": "{{count}} users selected",
      "days": "Days to add",
      "cancel": "Cancel",
      "confirm": "Confirm extension",
      "pending": "Processing",
      "result": "Extended {{updated}} users, skipped {{skipped}}",
      "failed": "Extension failed. Refresh and check before retrying"
    },
    "manage": {
      "title": "User Management",
      "description": "Here you can manage users, including adding, deleting, editing, and querying operations."
    },
    "columns": {
      "is_admin": "Admin",
      "is_staff": "Staff",
      "id": "ID",
      "email": "Email",
      "online_count": "Online Devices",
      "connection_count": "Connections",
      "upload_speed": "Upload Speed",
      "download_speed": "Download Speed",
      "speed_unknown": "Unknown",
      "speed_partial": "Some nodes are unavailable; showing confirmed speed only",
      "connections_unknown": "No recent connection report",
      "connections_partial": "Some nodes have not reported; showing confirmed connections only",
      "status": "Status",
      "subscription": "Subscription",
      "group": "Group",
      "used_traffic": "Used Traffic",
      "total_traffic": "Total Traffic",
      "expire_time": "Expire Time",
      "balance": "Balance",
      "commission": "Commission",
      "register_time": "Register Time",
      "actions": "Actions",
      "next_reset_at": "Next Reset At",
      "device_limit": {
        "unlimited": "No device limit",
        "limited": "Maximum {{count}} devices allowed"
      },
      "status_text": {
        "normal": "Normal",
        "banned": "Banned"
      },
      "online_status": {
        "online": "Currently Online",
        "never": "Never Online",
        "last_online": "Last Online: {{time}}",
        "offline_duration": {
          "days": "Offline Duration: {{count}}d",
          "hours": "Offline Duration: {{count}}h",
          "minutes": "Offline Duration: {{count}}m",
          "seconds": "Offline Duration: {{count}}s"
        }
      },
      "expire_status": {
        "permanent": "Permanent",
        "expired": "Expired {{days}} days ago",
        "remaining": "{{days}} days remaining"
      },
      "actions_menu": {
        "edit": "Edit",
        "view_details": "View Details",
        "assign_order": "Assign Order",
        "copy_url": "Copy Subscribe URL",
        "reset_secret": "Reset UUID & URL",
        "orders": "Orders",
        "invites": "Invites",
        "traffic_records": "Traffic Records",
        "reset_traffic": "Reset Traffic",
        "delete": "Delete",
        "delete_confirm_title": "Confirm Delete User",
        "delete_confirm_description": "This action will permanently delete user {{email}} and all associated data, including orders, coupons, traffic records, and support tickets. This action cannot be undone. Do you want to continue?"
      }
    },
    "filter": {
      "selected": "{{count}} selected",
      "no_results": "No results found.",
      "clear": "Clear filters",
      "search_placeholder": "Search...",
      "email_search": "Search user email...",
      "plan": "Plan",
      "advanced": "Advanced Filter",
      "reset": "Reset Filter",
      "sheet": {
        "title": "Advanced Filter",
        "description": "Add one or more filter conditions to find users precisely",
        "conditions": "Filter Conditions",
        "add": "Add Condition",
        "condition": "Condition {{number}}",
        "field": "Select Field",
        "operator": "Select Operator",
        "value": "Enter Value",
        "value_number": "Enter Value ({{unit}})",
        "reset": "Reset",
        "apply": "Apply Filter"
      },
      "fields": {
        "email": "Email",
        "phone": "Phone Number",
        "id": "User ID",
        "plan_id": "Subscription",
        "transfer_enable": "Traffic",
        "total_used": "Used Traffic",
        "online_count": "Online Devices",
        "expired_at": "Expire Time",
        "uuid": "UUID",
        "token": "Token",
        "banned": "Account Status",
        "remark": "Remark",
        "inviter_email": "Inviter Email",
        "invite_user_id": "Inviter ID",
        "is_admin": "Admin",
        "is_staff": "Staff"
      },
      "operators": {
        "contains": "Contains",
        "eq": "Equals",
        "gt": "Greater Than",
        "lt": "Less Than"
      },
      "status": {
        "normal": "Normal",
        "banned": "Banned"
      },
      "boolean": {
        "true": "Yes",
        "false": "No"
      }
    },
    "generate": {
      "button": "Create User",
      "title": "Create User",
      "form": {
        "email": "Email",
        "email_prefix": "Account (leave empty for batch generation)",
        "email_domain": "Domain",
        "password": "Password",
        "password_placeholder": "Leave empty to generate a random password",
        "random_password": "Random",
        "expire_time": "Expire Time",
        "expire_time_placeholder": "Select user expire date, leave empty for permanent",
        "permanent": "Permanent",
        "subscription": "Subscription Plan",
        "subscription_none": "None",
        "generate_count": "Generate Count",
        "generate_count_placeholder": "Enter count for batch generation",
        "cancel": "Cancel",
        "submit": "Generate",
        "success": "Generated successfully",
        "download_csv": "Export as CSV file"
      },
      "result": {
        "title": "Accounts created",
        "copy": "Copy",
        "copy_all": "Copy all",
        "copied": "Copied",
        "copy_failed": "Copy failed, please select and copy manually",
        "close": "Close"
      }
    },
    "edit": {
      "button": "Edit User Info",
      "title": "User Management",
      "form": {
        "email": "Email",
        "phone_country": "Country/Region",
        "phone": "Phone Number",
        "phone_placeholder": "Please enter phone number",
        "email_placeholder": "Please enter email",
        "inviter_email": "Inviter Email",
        "inviter_email_placeholder": "Please enter email",
        "password": "Password",
        "password_placeholder": "Enter new password if you want to change it",
        "random_password": "Random",
        "copy_password": "Copy password",
        "password_copied": "Password copied",
        "copy_failed": "Copy failed, please select and copy manually",
        "balance": "Balance",
        "balance_placeholder": "Please enter balance",
        "commission_balance": "Commission Balance",
        "commission_balance_placeholder": "Please enter commission balance",
        "upload": "Upload Traffic",
        "upload_placeholder": "Upload traffic",
        "download": "Download Traffic",
        "download_placeholder": "Download traffic",
        "total_traffic": "Total Traffic",
        "total_traffic_placeholder": "Please enter traffic",
        "expire_time": "Expire Time",
        "expire_time_placeholder": "Select user expire date, leave empty for permanent",
        "expire_time_specific": "Specific Time",
        "expire_time_today": "Set to end of today",
        "expire_time_permanent": "Permanent",
        "expire_time_1hour": "One Hour",
        "expire_time_1month": "One Month",
        "expire_time_3months": "Three Months",
        "expire_time_confirm": "Confirm",
        "subscription": "Subscription Plan",
        "subscription_none": "None",
        "account_status": "Account Status",
        "commission_type": "Commission Type",
        "commission_type_system": "Follow System Settings",
        "commission_type_cycle": "Cycle Commission",
        "commission_type_onetime": "One-time Commission",
        "commission_rate": "Commission Rate",
        "commission_rate_placeholder": "Leave empty to follow site commission rate",
        "discount": "Exclusive Discount",
        "discount_placeholder": "Leave empty for no exclusive discount",
        "speed_limit": "Speed Limit",
        "speed_limit_placeholder": "Leave empty for no speed limit",
        "device_limit": "Device Limit",
        "device_limit_placeholder": "Leave empty for no device limit",
        "conn_limit": "Concurrent Connections",
        "conn_limit_placeholder": "Leave empty for no limit",
        "conn_rate_limit": "New Connection Rate",
        "conn_rate_limit_placeholder": "Leave empty for no limit",
        "is_admin": "Is Admin",
        "is_staff": "Is Staff",
        "remarks": "Remarks",
        "remarks_placeholder": "Please enter remarks here",
        "cancel": "Cancel",
        "submit": "Submit",
        "success": "Modified successfully"
      }
    },
    "actions": {
      "title": "Actions",
      "send_email": "Send Email",
      "export_csv": "Export CSV",
      "traffic_reset_stats": "Traffic Reset Stats",
      "batch_ban": "Batch Ban",
      "confirm_ban": {
        "title": "Confirm Batch Ban",
        "filtered_description": "This action will ban all users that match your current filters. This action cannot be undone.",
        "all_description": "This action will ban all users in the system. This action cannot be undone.",
        "cancel": "Cancel",
        "confirm": "Confirm Ban",
        "banning": "Banning..."
      }
    },
    "messages": {
      "success": "Success",
      "error": "Error",
      "export": {
        "success": "Export successful",
        "failed": "Export failed"
      },
      "batch_ban": {
        "success": "Batch ban successful",
        "failed": "Batch ban failed"
      },
      "send_mail": {
        "success": "Email sent successfully",
        "failed": "Failed to send email",
        "required_fields": "Please fill in all required fields"
      }
    },
    "traffic_reset": {
      "title": "Traffic Reset",
      "description": "Reset traffic usage for user {{email}}",
      "tabs": {
        "reset": "Reset Traffic",
        "history": "Reset History"
      },
      "user_info": "User Information",
      "warning": {
        "title": "Important Notice",
        "irreversible": "Traffic reset operation is irreversible, please proceed with caution",
        "reset_to_zero": "After reset, user's upload and download traffic will be cleared to zero",
        "logged": "All reset operations will be logged in the system"
      },
      "reason": {
        "label": "Reset Reason",
        "placeholder": "Please enter the reason for traffic reset (optional)",
        "optional": "This field is optional and used to record the reason for reset"
      },
      "confirm_reset": "Confirm Reset",
      "resetting": "Resetting...",
      "reset_success": "Traffic reset successful",
      "reset_failed": "Traffic reset failed",
      "history": {
        "summary": "Reset Overview",
        "reset_count": "Reset Count",
        "last_reset": "Last Reset",
        "next_reset": "Next Reset",
        "never": "Never Reset",
        "no_schedule": "No Scheduled Reset",
        "records": "Reset Records",
        "recent_records": "Recent 10 Reset Records",
        "no_records": "No reset records",
        "reset_time": "Reset Time",
        "traffic_cleared": "Traffic Cleared"
      },
      "stats": {
        "title": "Traffic Reset Statistics",
        "description": "View system traffic reset statistics",
        "time_range": "Statistics Time Range",
        "total_resets": "Total Resets",
        "auto_resets": "Auto Resets",
        "manual_resets": "Manual Resets",
        "cron_resets": "Cron Resets",
        "in_period": "In the last {{days}} days",
        "breakdown": "Reset Type Breakdown",
        "breakdown_description": "Percentage breakdown of different reset operation types",
        "auto_percentage": "Auto Reset Percentage",
        "manual_percentage": "Manual Reset Percentage",
        "cron_percentage": "Cron Reset Percentage",
        "days_options": {
          "week": "Last Week",
          "month": "Last Month",
          "quarter": "Last Quarter",
          "year": "Last Year"
        }
      }
    },
    "traffic_reset_logs": {
      "title": "Traffic Reset Logs",
      "description": "View detailed records of all traffic reset operations in the system",
      "columns": {
        "id": "Log ID",
        "user": "User",
        "reset_type": "Reset Type",
        "trigger_source": "Trigger Source",
        "cleared_traffic": "Cleared Traffic",
        "cleared": "Cleared",
        "upload": "Upload",
        "download": "Download",
        "reset_time": "Reset Time",
        "log_time": "Log Time"
      },
      "filters": {
        "search_user": "Search user email...",
        "reset_type": "Reset Type",
        "trigger_source": "Trigger Source",
        "all_types": "All Types",
        "all_sources": "All Sources",
        "start_date": "Start Date",
        "end_date": "End Date",
        "apply_date": "Apply Filter",
        "reset": "Reset Filter",
        "filter_title": "Filter Options",
        "filter_description": "Set filter conditions to find specific traffic reset records",
        "reset_types": {
          "monthly": "Monthly Reset",
          "first_day_month": "First Day of Month Reset",
          "yearly": "Yearly Reset",
          "first_day_year": "First Day of Year Reset",
          "manual": "Manual Reset"
        },
        "trigger_sources": {
          "auto": "Auto Trigger",
          "manual": "Manual Trigger",
          "cron": "Cron Job"
        }
      },
      "actions": {
        "export": "Export Logs",
        "exporting": "Exporting...",
        "export_success": "Export successful",
        "export_failed": "Export failed"
      },
      "trigger_descriptions": {
        "manual": "Manually executed traffic reset by administrator",
        "cron": "Automatically executed by system scheduled task",
        "auto": "Automatically triggered by system based on conditions",
        "other": "Triggered by other methods"
      }
    },
    "send_mail": {
      "title": "Send Email",
      "description": "Send email to selected or filtered users",
      "subject": "Subject",
      "content": "Content",
      "sending": "Sending...",
      "send": "Send"
    },
    "dialog": {
      "title": "User Details",
      "basicInfo": "Basic Information",
      "subscriptionInfo": "Subscription Information",
      "trafficInfo": "Traffic Information",
      "financialInfo": "Financial Information",
      "activityInfo": "Activity Information",
      "inviteInfo": "Invitation Information",
      "timeInfo": "Time Information",
      "subscriptionUrl": "Subscription URL",
      "fields": {
        "userId": "User ID",
        "email": "Email",
        "phone": "Phone Number",
        "uuid": "UUID",
        "token": "Token",
        "remarks": "Remarks",
        "subscriptionPlan": "Subscription Plan",
        "permissionGroup": "Permission Group",
        "expiredAt": "Expired At",
        "deviceLimit": "Device Limit",
        "speedLimit": "Speed Limit",
        "transferEnable": "Total Traffic",
        "uploadUsed": "Upload Used",
        "downloadUsed": "Download Used",
        "totalUsed": "Total Used",
        "lastResetAt": "Last Reset",
        "nextResetAt": "Next Reset",
        "resetCount": "Reset Count",
        "balance": "Balance",
        "commissionBalance": "Commission Balance",
        "commissionType": "Commission Type",
        "commissionRate": "Commission Rate",
        "lastLoginAt": "Last Login",
        "lastLoginIp": "Last Login IP",
        "lastOnlineAt": "Last Online",
        "onlineCount": "Online Devices",
        "inviteUser": "Inviter",
        "inviteUserId": "Inviter ID",
        "createdAt": "Created At",
        "updatedAt": "Updated At",
        "subscribeUrl": "Subscription URL",
        "telegramId": "Telegram ID"
      }
    },
    "status": {
      "normal": "Normal",
      "banned": "Banned",
      "admin": "Admin",
      "staff": "Staff"
    }
  },
  "nav": {
    "telegramBot": "Telegram Bot",
    "dashboard": "Dashboard",
    "systemManagement": "System Management",
    "systemConfig": "System Configuration",
    "themeConfig": "Theme Configuration",
    "noticeManagement": "Notice Management",
    "pluginManagement": "Plugin Management",
    "paymentConfig": "Payment Configuration",
    "knowledgeManagement": "Knowledge Management",
    "nodeManagement": "Node Management",
    "machineManagement": "Server Management",
    "permissionGroupManagement": "Permission Group",
    "routeManagement": "Route Management",
    "subscriptionManagement": "Subscription",
    "planManagement": "Plan Management",
    "planSettings": "Plan Settings",
    "orderManagement": "Order Management",
    "couponManagement": "Coupon Management",
    "giftCardManagement": "Gift Card Management",
    "userManagement": "User Management",
    "trafficResetLogs": "Traffic Reset Logs",
    "ticketManagement": "Ticket Management",
    "pluginApps": "Plugin Apps"
  },
  "subscribe": {
    "plan": {
      "title": "Subscription Plans",
      "add": "Add Plan",
      "search": "Search plans...",
      "sort": {
        "edit": "Edit Sort",
        "save": "Save Sort"
      },
      "columns": {
        "id": "ID",
        "show": "Show",
        "sell": "Sell",
        "renew": "Renew",
        "renew_tooltip": "Whether existing users can renew when the subscription stops selling",
        "name": "Name",
        "stats": "Statistics",
        "group": "Permission Group",
        "price": "Price",
        "actions": "Actions",
        "edit": "Edit",
        "delete": "Delete",
        "delete_confirm": {
          "title": "Confirm Delete",
          "description": "This action will permanently delete this subscription and cannot be undone. Are you sure you want to continue?",
          "success": "Successfully deleted"
        },
        "price_period": {
          "monthly": "Monthly",
          "quarterly": "Quarterly",
          "half_yearly": "Half Yearly",
          "yearly": "Yearly",
          "two_yearly": "Two Years",
          "three_yearly": "Three Years",
          "onetime": "One Time",
          "reset_traffic": "Reset Traffic",
          "no_price": "No Price",
          "unit": {
            "month": "/month",
            "quarter": "/quarter",
            "half_year": "/half year",
            "year": "/year",
            "two_year": "/2 years",
            "three_year": "/3 years",
            "times": "/time"
          }
        }
      },
      "form": {
        "add_title": "Add Plan",
        "edit_title": "Edit Plan",
        "name": {
          "label": "Plan Name",
          "placeholder": "Enter plan name"
        },
        "group": {
          "label": "Permission Groups",
          "add": "Add Group",
          "placeholder": "Select permission groups"
        },
        "transfer": {
          "label": "Traffic",
          "placeholder": "Enter traffic limit",
          "unit": "GB"
        },
        "speed": {
          "label": "Speed Limit",
          "placeholder": "Enter speed limit",
          "unit": "Mbps"
        },
        "price": {
          "title": "Price Settings",
          "base_price": "Base Price",
          "clear": {
            "button": "Clear",
            "tooltip": "Clear all prices"
          },
          "period": {
            "monthly": "Monthly",
            "months": "{{count}} Months"
          },
          "onetime_desc": "One-time traffic package, no time limit",
          "reset_desc": "Reset traffic package, can be used multiple times"
        },
        "device": {
          "label": "Device Limit",
          "placeholder": "Enter device limit",
          "unit": "Devices"
        },
        "conn": {
          "label": "Concurrent Connections",
          "placeholder": "Leave empty for no limit",
          "unit": "Conns"
        },
        "conn_rate": {
          "label": "New Connection Rate",
          "placeholder": "Leave empty for no limit",
          "unit": "Conns/s"
        },
        "capacity": {
          "label": "Capacity Limit",
          "placeholder": "Enter capacity limit",
          "unit": "Users"
        },
        "tags": {
          "label": "Tags",
          "placeholder": "Enter a tag and press Enter to confirm"
        },
        "reset_method": {
          "label": "Traffic Reset Method",
          "placeholder": "Select reset method",
          "description": "Traffic reset method will determine how the traffic is reset",
          "options": {
            "follow_system": "Follow System Settings",
            "monthly_first": "Monthly First Day",
            "monthly_reset": "Monthly Purchase Day",
            "no_reset": "No Reset",
            "yearly_first": "Yearly First Day",
            "yearly_reset": "Yearly Purchase Day"
          }
        },
        "content": {
          "label": "Plan Description",
          "placeholder": "Enter plan description",
          "description": "Support Markdown format",
          "preview": "Preview",
          "preview_button": {
            "show": "Show Preview",
            "hide": "Hide Preview"
          },
          "template": {
            "button": "Use Template",
            "tooltip": "Use default template",
            "content": "## Plan Details\n\n- Data: {{transfer}} GB\n- Speed Limit: {{speed}} Mbps\n- Concurrent Devices: {{devices}}\n\n## Service Information\n\n1. Data {{reset_method}}\n2. Multi-platform Support\n3. 24/7 Technical Support"
          }
        },
        "force_update": {
          "label": "Force Update User Plans"
        },
        "submit": {
          "cancel": "Cancel",
          "submit": "Submit",
          "submitting": "Submitting...",
          "success": {
            "add": "Plan added successfully",
            "update": "Plan updated successfully"
          },
          "error": {
            "validation": "Form validation failed. Please check for errors and try again."
          }
        }
      },
      "page": {
        "description": "Here you can configure subscription plans, including adding, deleting, and editing operations."
      }
    }
  },
  "settings": {
    "node_health": {
      "title": "Link health",
      "enabled": "Enable health checks by default",
      "url": "HTTPS check URL",
      "interval": "Check interval (seconds)",
      "save": "Save global settings",
      "saving": "Saving…",
      "save_error": "Save failed. Please retry.",
      "load_error": "Failed to load",
      "retry": "Retry"
    },
    "appearance": {"title":"Appearance","sidebar":"Sidebar","restore":"Show all","restore_order":"Reset order","sort_help":"Drag to reorder menus within their group. Use switches to show or hide them.","move":"Reorder {{name}}","saving":"Saving","retry":"Retry","load_error":"Failed to load appearance settings","save_error":"Could not save. Please retry.","loading":"Loading"},
    "title": "System Settings",
    "description": "Manage core system configurations, including site, security, subscription, invite commission, nodes, email, and notifications",
    "server": {
      "title": "Server Configuration",
      "description": "Configure node communication and synchronization settings, including communication keys, polling intervals, load balancing and other advanced options.",
      "server_token": {
        "title": "Communication Token",
        "placeholder": "Enter communication token",
        "description": "Used for authentication between servers",
        "generate_tooltip": "Click to generate random token"
      },
      "server_pull_interval": {
        "title": "Node Pull Action Polling Interval",
        "description": "The frequency at which nodes retrieve data from the panel.",
        "placeholder": "Enter pull interval"
      },
      "server_push_interval": {
        "title": "Node Push Action Polling Interval",
        "description": "The frequency at which nodes push data to the panel.",
        "placeholder": "Enter push interval"
      },
      "device_limit_mode": {
        "title": "Device Limit Mode",
        "description": "In relaxed mode, using multiple nodes from the same IP address counts as one device.",
        "strict": "Strict Mode",
        "relaxed": "Relaxed Mode",
        "placeholder": "Select device limit mode"
      },
      "server_auto_sort_enable": {
        "title": "Automatic server sorting",
        "description": "After a new server first reports and its country or region is recognized, place it after the last server in the same group and region. If all servers are ungrouped, match by region. Keep its creation position when no match exists. Enabling this leaves existing servers in place."
      },
      "server_ws_enable": {
        "title": "Enable WebSocket Communication",
        "description": "When enabled, nodes will communicate with the panel via WebSocket for lower latency and more timely pushes.",
        "supported_clients": "Node clients that currently support WebSocket communication: Xboard Node"
      },
      "server_ws_url": {
        "title": "WebSocket URL",
        "description": "The WebSocket address nodes use to connect to the panel. Leave empty to use the site URL.",
        "placeholder": "Leave empty to use site URL"
      },
      "reality_scan_targets": {
        "title": "Preset scan targets",
        "description": "One domain, IP or network per line, with an optional port. Up to 64 entries and 512 addresses. Saved when you leave the field; leave empty to restore defaults.",
        "placeholder": "www.microsoft.com:443\naws.amazon.com:443"
      },
      "device_ip_exclude": {
        "title": "Front server IPs",
        "description": "Only enter the exit addresses of your own forwarders or proxy chain front servers. These addresses do not count as devices; Xray TCP connections carrying a real client IP count that IP instead.",
        "placeholder": "One IP or CIDR per line, e.g. 203.0.113.10 or 203.0.113.0/24",
        "errors": {
          "invalid": "Line {{line}} is not a valid IP address or CIDR",
          "too_broad": "Line {{line}} is too broad: IPv4 must be at least /16, IPv6 at least /48",
          "too_many": "At most {{max}} entries"
        }
      },
      "saving": "Saving..."
    },
    "invite": {
      "title": "Invitation & Commission Settings",
      "description": "Configure invitation registration and commission related settings.",
      "invite_force": {
        "title": "Enable Forced Invitation",
        "description": "When enabled, only invited users can register."
      },
      "invite_commission": {
        "title": "Invitation Commission Percentage",
        "description": "Default global commission distribution ratio, you can configure individual ratios in user management.",
        "placeholder": "Enter commission percentage"
      },
      "invite_gen_limit": {
        "title": "Invitation Code Generation Limit",
        "description": "Maximum number of invitation codes a user can create",
        "placeholder": "Enter generation limit"
      },
      "invite_never_expire": {
        "title": "Never Expire Invitation Code",
        "description": "When enabled, invitation codes will not expire after use, otherwise they will expire after being used."
      },
      "commission_first_time": {
        "title": "First-time Commission Only",
        "description": "When enabled, commission will only be generated on the first payment of the invitee, can be configured individually in user management."
      },
      "commission_auto_check": {
        "title": "Automatic Commission Confirmation",
        "description": "When enabled, commission will be automatically confirmed 3 days after order completion."
      },
      "commission_withdraw_limit": {
        "title": "Withdrawal Threshold (Yuan)",
        "description": "Withdrawal requests below this threshold will not be submitted.",
        "placeholder": "Enter withdrawal threshold"
      },
      "commission_withdraw_method": {
        "title": "Withdrawal Methods",
        "description": "Supported withdrawal methods, separate multiple methods with commas.",
        "placeholder": "Enter withdrawal methods, separate with commas"
      },
      "withdraw_close": {
        "title": "Disable Withdrawals",
        "description": "When enabled, users will be prohibited from requesting withdrawals, and invitation commissions will go directly to user balance."
      },
      "commission_distribution": {
        "title": "Three-level Distribution",
        "description": "When enabled, commission will be split according to the three set ratios, total should not exceed 100%.",
        "l1": "Level 1 Inviter Ratio",
        "l2": "Level 2 Inviter Ratio",
        "l3": "Level 3 Inviter Ratio",
        "placeholder": "Enter ratio e.g. 50"
      },
      "saving": "Saving..."
    },
    "site": {
      "title": "Site Settings",
      "description": "Configure basic site information, including site name, description, currency unit, and other core settings.",
      "form": {
        "siteName": {
          "label": "Site Name",
          "placeholder": "Please enter site name",
          "description": "Used where site name needs to be displayed."
        },
        "siteDescription": {
          "label": "Site Description",
          "placeholder": "Please enter site description",
          "description": "Used where site description needs to be displayed."
        },
        "siteUrl": {
          "label": "Site URL",
          "placeholder": "Please enter site URL, without trailing /",
          "description": "Current website URL, will be used in emails and other places where URL is needed."
        },
        "forceHttps": {
          "label": "Force HTTPS",
          "description": "Need to enable when the site is not using HTTPS but CDN or reverse proxy has forced HTTPS."
        },
        "logo": {
          "label": "LOGO",
          "placeholder": "Please enter LOGO URL, without trailing /",
          "description": "Used where LOGO needs to be displayed."
        },
        "subscribeUrl": {
          "label": "Subscribe URL",
          "placeholder": "One subscription URL per line, e.g. https://sub.example.com",
          "description": "The first URL is used by default. Leave empty to use the site URL."
        },
        "tosUrl": {
          "label": "Terms of Service (TOS) URL",
          "placeholder": "Please enter TOS URL, without trailing /",
          "description": "Used to link to Terms of Service (TOS)"
        },
        "stopRegister": {
          "label": "Stop New User Registration",
          "description": "When enabled, no one will be able to register."
        },
        "ticketMustWaitReply": {
          "label": "Reply Wait Restriction",
          "description": "When enabled, users cannot continue sending messages in the same ticket until an administrator replies."
        },
        "tryOut": {
          "label": "Registration Trial",
          "placeholder": "Disabled",
          "description": "Select the subscription for trial, if no options please add in subscription management first.",
          "duration": {
            "label": "Trial Duration",
            "placeholder": "0",
            "description": "Trial duration in hours."
          }
        },
        "currency": {
          "label": "Currency Unit",
          "placeholder": "CNY",
          "description": "For display only, changing this will affect all currency units in the system."
        },
        "currencySymbol": {
          "label": "Currency Symbol",
          "placeholder": "¥",
          "description": "For display only, changing this will affect all currency symbols in the system."
        }
      }
    },
    "totp": {
      "title": "Two-Factor Authentication",
      "description": "Require a time-based code from an authenticator app when signing in to this admin account.",
      "loading": "Loading",
      "statusOn": "Status: enabled",
      "statusOff": "Status: not enabled",
      "recoveryRemaining": "{{count}} recovery codes left",
      "enable": "Enable two-factor authentication",
      "confirm": "Confirm and enable",
      "cancel": "Cancel",
      "disable": "Disable two-factor authentication",
      "regenerate": "Regenerate recovery codes",
      "scanHint": "Scan the QR code with your authenticator app, or enter the key below manually.",
      "qrAlt": "Two-factor authentication QR code",
      "manualKey": "Manual entry key",
      "codeLabel": "Verification code",
      "codePlaceholder": "Enter the 6-digit code or a recovery code",
      "recoveryTitle": "Recovery codes",
      "recoveryHint": "Save these somewhere safe now. They are shown only once and each code works only once.",
      "copyRecovery": "Copy all recovery codes",
      "copied": "Copied",
      "enabledToast": "Two-factor authentication enabled",
      "disabledToast": "Two-factor authentication disabled"
    },
    "safe": {
      "title": "Security Settings",
      "description": "Configure system security options, including login verification, password policies, and API access settings.",
      "form": {
        "emailVerify": {
          "label": "Email Verification",
          "description": "When enabled, users will be required to verify their email."
        },
        "gmailLimit": {
          "label": "Disable Gmail Aliases",
          "description": "When enabled, Gmail aliases will not be allowed to register."
        },
        "safeMode": {
          "label": "Safe Mode",
          "description": "When enabled, accessing the site through domains other than the site URL will be blocked with 403."
        },
        "securePath": {
          "label": "Admin Path",
          "placeholder": "admin",
          "description": "Admin management path, changing this will modify the original admin path"
        },
        "emailWhitelist": {
          "label": "Email Suffix Whitelist",
          "description": "When enabled, only email suffixes in the list will be allowed to register.",
          "suffixes": {
            "label": "Email Suffixes",
            "placeholder": "Enter email suffixes, one per line",
            "description": "Enter the allowed email suffixes, one per line"
          }
        },
        "captcha": {
          "enable": {
            "label": "Enable Captcha",
            "description": "When enabled, users will need to pass captcha verification when registering."
          },
          "type": {
            "label": "Captcha Type",
            "description": "Select the captcha service type to use",
            "options": {
              "recaptcha": "Google reCAPTCHA v2",
              "recaptcha-v3": "Google reCAPTCHA v3",
              "turnstile": "Cloudflare Turnstile"
            }
          },
          "recaptcha": {
            "key": {
              "label": "reCAPTCHA Key",
              "placeholder": "Enter reCAPTCHA key",
              "description": "Enter your reCAPTCHA key"
            },
            "siteKey": {
              "label": "reCAPTCHA Site Key",
              "placeholder": "Enter reCAPTCHA site key",
              "description": "Enter your reCAPTCHA site key"
            }
          },
          "recaptcha_v3": {
            "secretKey": {
              "label": "reCAPTCHA v3 Key",
              "placeholder": "Enter reCAPTCHA v3 key",
              "description": "Enter your reCAPTCHA v3 server key"
            },
            "siteKey": {
              "label": "reCAPTCHA v3 Site Key",
              "placeholder": "Enter reCAPTCHA v3 site key",
              "description": "Enter your reCAPTCHA v3 site key"
            },
            "scoreThreshold": {
              "label": "Score Threshold",
              "placeholder": "0.5",
              "description": "Set verification score threshold (0-1), higher scores indicate more likely human behavior"
            }
          },
          "turnstile": {
            "secretKey": {
              "label": "Turnstile Key",
              "placeholder": "Enter Turnstile key",
              "description": "Enter your Cloudflare Turnstile key"
            },
            "siteKey": {
              "label": "Turnstile Site Key",
              "placeholder": "Enter Turnstile site key",
              "description": "Enter your Cloudflare Turnstile site key"
            }
          }
        },
        "registerLimit": {
          "enable": {
            "label": "IP Registration Limit",
            "description": "When enabled, the number of registrations from the same IP will be limited."
          },
          "count": {
            "label": "Registration Count",
            "placeholder": "Enter maximum registration count",
            "description": "Maximum number of registrations allowed from the same IP"
          },
          "expire": {
            "label": "Limit Duration",
            "placeholder": "Enter limit duration in minutes",
            "description": "Duration of the registration limit in minutes"
          }
        },
        "passwordLimit": {
          "enable": {
            "label": "Password Attempt Limit",
            "description": "When enabled, the number of password attempts will be limited."
          },
          "count": {
            "label": "Attempt Count",
            "placeholder": "Enter maximum attempt count",
            "description": "Maximum number of password attempts allowed"
          },
          "expire": {
            "label": "Lock Duration",
            "placeholder": "Enter lock duration in minutes",
            "description": "Duration of the account lock in minutes"
          }
        }
      }
    },
    "subscribe": {
      "protection": {
        "title": "Subscription protection",
        "block_browser": "Block browser access",
        "browser_hint": "Block browser page requests. Proxy clients remain subject to client restrictions.",
        "brute_force_enabled": "Brute-force protection",
        "brute_hint": "Temporarily block subscription access after repeated invalid links from the same IP.",
        "brute_force_max_failures": "Maximum failures",
        "brute_force_window_minutes": "Failure window (minutes)",
        "brute_force_block_minutes": "Block duration (minutes)",
        "rate_limit_enabled": "Subscription rate limit",
        "rate_hint": "Limit requests per IP. All subscription endpoints share the allowance.",
        "rate_limit_max_requests": "Maximum requests",
        "rate_limit_window_minutes": "Request window (minutes)",
        "whitelist_ips": "IP allowlist",
        "ips_placeholder": "One IPv4, IPv6 or CIDR per line; commas also work",
        "whitelist_users": "User allowlist",
        "users_placeholder": "Search email or user ID",
        "whitelist_hint": "Either whitelist bypasses subscription protection. Account eligibility and client rules still apply.",
        "add_user": "Add {{email}}",
        "remove_user": "Remove {{email}}",
        "missing_user": "Deleted user #{{id}}",
        "remove": "Remove",
        "searching": "Searching…",
        "no_users": "No users found",
        "search_error": "Search failed. Try again.",
        "loading": "Loading…",
        "retry": "Retry",
        "load_error": "Failed to load. Try again.",
        "save": "Save",
        "saving": "Saving…",
        "saved": "Saved",
        "save_error": "Save failed. Your changes are kept. Try again.",
        "errors": {
          "number": "{{field}} must be an integer from 1 to {{max}}.",
          "ips": "Use up to 256 IP entries, each at most 64 characters.",
          "users": "Select up to 1000 valid users."
        },
        "user_rate_limit_enabled": "Limit subscriptions per user",
        "user_rate_hint": "Count requests for the same account across IP addresses and subscription endpoints.",
        "user_rate_limit_max_requests": "Maximum requests per user",
        "user_rate_limit_window_minutes": "User window (minutes)",
        "notify_telegram": "Subscription protection alerts",
        "notify_hint": "Use the Telegram Bot administrator recipients and cooldown. Notify only when a new restriction starts.",
        "restrictions": "Active restrictions",
        "refresh": "Refresh",
        "no_restrictions": "No active restrictions",
        "restrictions_load_error": "Could not load restrictions. Refresh to retry.",
        "save_before_release": "Wait for settings to save automatically before managing restrictions.",
        "kind_ip_ban": "IP ban",
        "kind_ip_rate": "IP rate limit",
        "kind_user_rate": "User rate limit",
        "restriction_count": "Requests in window",
        "triggered_at": "Triggered at",
        "expires_at": "Ends at",
        "release_once": "Release this restriction",
        "whitelist_permanently": "Whitelist permanently",
        "confirm_release": "Release this restriction for {{target}} and reset its counter?",
        "confirm_whitelist": "Permanently whitelist {{target}} and reset its counters? This target will bypass subscription protection.",
        "confirm": "Confirm",
        "cancel": "Cancel",
        "processing": "Processing…",
        "release_error": "The action failed. Retry or refresh the list.",
        "load_more": "Load more"
      },
      "client_control": {
        "title": "Client restrictions",
        "clients": "Clients",
        "rules": "Subscription download rules",
        "mode": "Restriction mode",
        "modes": {
          "off": "Off",
          "whitelist": "Allowlist: allow selected clients only",
          "blacklist": "Blocklist: block selected clients"
        },
        "name": "Client name",
        "keywords": "Matching keywords",
        "keywords_placeholder": "One per line; any contained keyword matches",
        "selected": "Include in list",
        "select_named": "Include {{name}} in the list",
        "remove": "Delete",
        "remove_named": "Delete {{name}}",
        "add": "Add client",
        "empty": "No client rules",
        "groups": "Exempt permission groups",
        "groups_placeholder": "Select exempt permission groups",
        "missing_group": "Deleted permission group #{{id}}",
        "empty_whitelist": "The allowlist is empty. Non-exempt users cannot download subscriptions.",
        "loading": "Loading…",
        "retry": "Retry",
        "load_error": "Could not load the rules. Please retry.",
        "saving": "Saving…",
        "save_error": "Could not save. Your input has been kept; please retry.",
        "errors": {
          "mode": "Select a valid restriction mode.",
          "too_many": "Add up to 64 clients.",
          "name": "Row {{row}} needs a client name of up to 80 characters.",
          "keywords": "Row {{row}} needs 1–32 keywords, each up to 128 characters."
        }
      },
      "title": "Subscription Settings",
      "description": "Manage subscription-related configurations, including subscription link format, update frequency, traffic statistics, and other settings.",
      "plan_change_enable": {
        "title": "Allow Subscription Changes",
        "description": "When enabled, users will be able to change their subscription plans."
      },
      "reset_traffic_method": {
        "title": "Monthly Traffic Reset Method",
        "description": "Global traffic reset method, defaults to the 1st of each month. Can be set individually for subscriptions in subscription management.",
        "options": {
          "monthly_first": "1st of Each Month",
          "monthly_reset": "Monthly Reset",
          "no_reset": "No Reset",
          "yearly_first": "January 1st",
          "yearly_reset": "Yearly Reset"
        }
      },
      "surplus_enable": {
        "title": "Enable Deduction Plan",
        "description": "When enabled, the system will deduct from the original subscription when users change subscriptions, refer to documentation for details."
      },
      "new_order_event": {
        "title": "Trigger Event on New Subscription",
        "description": "This task will be triggered when a new subscription is completed.",
        "options": {
          "no_action": "No Action",
          "reset_traffic": "Reset User Traffic"
        }
      },
      "renew_order_event": {
        "title": "Trigger Event on Subscription Renewal",
        "description": "This task will be triggered when a subscription renewal is completed.",
        "options": {
          "no_action": "No Action",
          "reset_traffic": "Reset User Traffic"
        }
      },
      "change_order_event": {
        "title": "Trigger Event on Subscription Change",
        "description": "This task will be triggered when a subscription change is completed.",
        "options": {
          "no_action": "No Action",
          "reset_traffic": "Reset User Traffic"
        }
      },
      "subscribe_path": {
        "title": "Subscription Path",
        "description": "Subscription path, modifying will change the original subscribe path",
        "current_format": "Current subscription path format: {path}/xxxxxxxxxx",
        "restart_tip": "You may need to restart the service for the new subscribe path to take effect."
      },
      "basic_settings": "Basic settings",
      "output_settings": "Output settings",
      "loading": "Loading…",
      "load_failed": "Failed to load. Please retry.",
      "save_failed": "Failed to save. Please retry.",
      "retry": "Retry",
      "show_flag_to_server": {"title":"Add country flags","description":"Detect the country or region from each node name and prepend its flag. Keep existing flags; leave unknown names unchanged."},
      "show_rate_to_server": {"title":"Append traffic multiplier","description":"Append the effective multiplier, such as “｜0.8×”. Hide it for 1×."},
      "show_info_to_server": {
        "title": "Show Subscription Info in Nodes",
        "description": "When enabled, subscription information will be output when users subscribe to nodes."
      },
      "show_protocol_to_server": {
        "title": "Show Protocol in Node Names",
        "description": "When enabled, subscription lines will include protocol names (e.g., [Hy2]Hong Kong)"
      },
      "saving": "Saving...",
      "plan": {
        "title": "Subscription Plans",
        "add": "Add Plan",
        "search": "Search plans...",
        "sort": {
          "edit": "Edit Sort",
          "save": "Save Sort"
        },
        "columns": {
          "id": "ID",
          "show": "Show",
          "sell": "Sell",
          "renew": "Renew",
          "renew_tooltip": "Whether existing users can renew when the subscription stops selling",
          "name": "Name",
          "stats": "Statistics",
          "group": "Permission Group",
          "price": "Price",
          "actions": "Actions",
          "edit": "Edit",
          "delete": "Delete",
          "delete_confirm": {
            "title": "Confirm Delete",
            "description": "This action will permanently delete this subscription and cannot be undone. Are you sure you want to continue?",
            "success": "Successfully deleted"
          },
          "price_period": {
            "monthly": "Monthly",
            "quarterly": "Quarterly",
            "half_yearly": "Half Yearly",
            "yearly": "Yearly",
            "two_yearly": "Two Years",
            "three_yearly": "Three Years",
            "onetime": "One Time",
            "reset_traffic": "Reset Traffic",
            "unit": {
              "month": "/month",
              "quarter": "/quarter",
              "half_year": "/half year",
              "year": "/year",
              "two_year": "/2 years",
              "three_year": "/3 years",
              "times": "/time"
            }
          }
        },
        "form": {
          "add_title": "Add Plan",
          "edit_title": "Edit Plan",
          "name": {
            "label": "Plan Name",
            "placeholder": "Enter plan name"
          },
          "group": {
            "label": "Permission Group",
            "placeholder": "Select permission group",
            "add": "Add Group"
          },
          "transfer": {
            "label": "Traffic",
            "placeholder": "Enter traffic size",
            "unit": "GB"
          },
          "speed": {
            "label": "Speed Limit",
            "placeholder": "Enter speed limit",
            "unit": "Mbps"
          },
          "price": {
            "title": "Price Settings",
            "base_price": "Base monthly price",
            "clear": {
              "button": "Clear Prices",
              "tooltip": "Clear all period price settings"
            }
          },
          "device": {
            "label": "Device Limit",
            "placeholder": "Leave empty for no limit",
            "unit": "devices"
          },
          "capacity": {
            "label": "Capacity Limit",
            "placeholder": "Leave empty for no limit",
            "unit": "users"
          },
          "reset_method": {
            "label": "Traffic Reset Method",
            "placeholder": "Select traffic reset method",
            "description": "Set how subscription traffic is reset, different methods affect how user traffic is calculated",
            "options": {
              "follow_system": "Follow System Settings",
              "monthly_first": "1st of Each Month",
              "monthly_reset": "Monthly Reset",
              "no_reset": "No Reset",
              "yearly_first": "January 1st",
              "yearly_reset": "Yearly Reset"
            }
          },
          "content": {
            "label": "Plan Description",
            "placeholder": "Write plan description here...",
            "description": "Supports Markdown format, you can use headings, lists, bold, italic and other styles to beautify the content",
            "preview": "Preview",
            "preview_button": {
              "show": "Show Preview",
              "hide": "Hide Preview"
            },
            "template": {
              "button": "Use Template",
              "tooltip": "Click to use preset plan description template",
              "content": "## Plan Features\n• High-speed and stable global network access\n• Support multiple devices online simultaneously\n• Unlimited traffic reset\n\n## Usage Instructions\n1. Supported devices: iOS, Android, Windows, macOS\n2. 24/7 technical support\n3. Automatic periodic traffic reset\n\n## Notes\n- No abuse allowed\n- Comply with local laws and regulations\n- Support plan changes anytime"
            }
          },
          "force_update": {
            "label": "Force Update to Users"
          },
          "submit": {
            "submitting": "Submitting...",
            "submit": "Submit",
            "cancel": "Cancel",
            "success": {
              "add": "Plan added successfully",
              "update": "Plan updated successfully"
            }
          }
        },
        "page": {
          "description": "Here you can configure subscription plans, including adding, deleting, and editing operations."
        }
      }
    },
    "email": {
      "title": "Email Settings",
      "description": "Configure system email service for sending verification codes, password resets, and notifications, supporting various SMTP providers.",
      "tab_settings": "Settings",
      "tab_templates": "Templates",
      "email_host": {
        "title": "SMTP Host",
        "description": "SMTP server address, e.g., smtp.gmail.com"
      },
      "email_port": {
        "title": "SMTP Port",
        "description": "SMTP server port, common ports: 25, 465, 587"
      },
      "email_username": {
        "title": "SMTP Username",
        "description": "SMTP authentication username"
      },
      "email_password": {
        "title": "SMTP Password",
        "description": "SMTP authentication password or application-specific password"
      },
      "email_encryption": {
        "title": "Encryption Method",
        "description": "Email encryption method",
        "none": "None",
        "ssl": "SSL/TLS",
        "tls": "STARTTLS"
      },
      "email_from": {
        "title": "From Address",
        "description": "Sender's email address"
      },
      "email_from_name": {
        "title": "From Name",
        "description": "Sender's display name"
      },
      "email_template": {
        "title": "Email Template",
        "description": "You can check the documentation for how to customize email templates",
        "placeholder": "Select email template"
      },
      "remind_mail": {
        "title": "Email Reminders",
        "description": "When enabled, users will receive email notifications when their subscription is about to expire or when traffic is running low."
      },
      "test": {
        "title": "Send Test Email",
        "sending": "Sending...",
        "description": "Send a test email to verify the configuration",
        "success": "Test email sent successfully",
        "error": "Failed to send test email"
      }
    },
    "telegram": {
      "title": "Telegram Settings",
      "description": "Configure Telegram bot functionality for user notifications, account binding, and command interactions.",
      "bot_token": {
        "title": "Bot Token",
        "description": "Please enter the token provided by Botfather.",
        "placeholder": "0000000000:xxxxxxxxx_xxxxxxxxxxxxxxx"
      },
      "webhook_url": {
        "title": "Webhook Base URL",
        "description": "Only provide the base URL here. The system will append the full Telegram webhook callback path automatically. Leave blank to use the site URL.",
        "docs": "View Telegram Webhook Docs",
        "placeholder": "https://example.com"
      },
      "webhook": {
        "title": "Set Webhook",
        "description": "Set up webhook for the bot. Without setting it, you won't receive Telegram notifications.",
        "button": "One-Click Setup",
        "setting": "Setting Webhook...",
        "success": "Webhook set successfully",
        "target_default": "The site URL will be used as the Webhook Base URL.",
        "target_custom": "The custom Webhook Base URL currently in use is: {{url}}",
        "debug": {
          "title": "Webhook Debug Info",
          "success": "Success",
          "url": "Webhook URL",
          "baseUrl": "Base URL"
        }
      },
      "bot_enable": {
        "title": "Enable Telegram Binding Guide",
        "description": "When enabled, a Telegram binding guide will be displayed on the user side to help users bind their Telegram accounts for notifications."
      },
      "discuss_link": {
        "title": "Group Link",
        "description": "Once filled in, it will be displayed on the user side or used where needed.",
        "placeholder": "https://t.me/xxxxxx"
      }
    },
    "app": {
      "title": "APP Settings",
      "description": "Manage mobile application configurations, including API interfaces, version control, and push notifications.",
      "common": {
        "placeholder": "Please input"
      },
      "windows": {
        "version": {
          "title": "Windows Version",
          "description": "Current version number of Windows client"
        },
        "download": {
          "title": "Windows Download URL",
          "description": "Download link for Windows client"
        }
      },
      "macos": {
        "version": {
          "title": "macOS Version",
          "description": "Current version number of macOS client"
        },
        "download": {
          "title": "macOS Download URL",
          "description": "Download link for macOS client"
        }
      },
      "android": {
        "version": {
          "title": "Android Version",
          "description": "Current version number of Android client"
        },
        "download": {
          "title": "Android Download URL",
          "description": "Download link for Android client"
        }
      }
    },
    "common": {
      "saving": "Saving...",
      "save_success": "Saved automatically",
      "placeholder": "Please input",
      "autoSaved": "Saved automatically"
    },
    "subscribe_template": {
      "title": "Subscribe Templates",
      "description": "Configure subscription templates for different clients",
      "singbox": {
        "title": "Sing-box Template",
        "description": "Configure subscription template format for Sing-box"
      },
      "clash": {
        "title": "Clash Template",
        "description": "Configure subscription template format for Clash"
      },
      "clashmeta": {
        "title": "Clash Meta Template",
        "description": "Configure subscription template format for Clash Meta"
      },
      "stash": {
        "title": "Stash Template",
        "description": "Configure subscription template format for Stash"
      },
      "surge": {
        "title": "Surge Template",
        "description": "Configure subscription template format for Surge"
      },
      "surfboard": {
        "title": "Surfboard Template",
        "description": "Configure subscription template format for Surfboard"
      }
    },
    "email_template": {
      "title": "Email Templates",
      "description": "Customize the content of system email templates",
      "customized": "Customized",
      "subject": "Subject",
      "subject_placeholder": "Enter email subject, supports {{name}} placeholders",
      "content": "Template Content (HTML)",
      "preview": "Live Preview",
      "override_hint": "Saving will override the default system template. Click \"Reset to Default\" to restore the theme's default template at any time.",
      "placeholders": "Available Placeholders",
      "var_name": "Variable",
      "var_desc": "Description",
      "var_sample": "Sample Value",
      "required": "Required",
      "insert": "Insert",
      "placeholder_hint": "* marks required placeholders. Click to insert at the end of the content.",
      "click_to_insert": "Click to insert",
      "save": "Save",
      "save_success": "Template saved successfully",
      "save_before_test": "Please save changes before sending a test email",
      "send_test": "Send Test",
      "test_dialog_title": "Send Test Email",
      "test_dialog_description": "Enter recipient email address. Leave empty to send to your admin email.",
      "test_email_placeholder": "Recipient email (leave empty for current account)",
      "sending": "Sending...",
      "test_success": "Test email sent successfully",
      "reset": "Reset to Default",
      "reset_title": "Reset Template",
      "reset_description": "Are you sure you want to reset this template to default? Your customizations will be deleted.",
      "reset_confirm": "Confirm Reset",
      "reset_success": "Template reset to default",
      "unsaved": "Unsaved changes",
      "discard_title": "Unsaved Changes",
      "discard_description": "This template has unsaved changes. Switching tabs will discard them.",
      "discard_confirm": "Discard",
      "cancel": "Cancel"
    }
  },
  "notice": {
    "title": "Notice Management",
    "description": "Here you can configure notices, including adding, deleting, editing and other operations.",
    "table": {
      "columns": {
        "id": "ID",
        "show": "Display Status",
        "title": "Title",
        "actions": "Actions"
      },
      "toolbar": {
        "search": "Search notice title...",
        "reset": "Reset",
        "sort": {
          "edit": "Edit Order",
          "save": "Save Order"
        }
      },
      "actions": {
        "edit": "Edit",
        "delete": {
          "title": "Delete Confirmation",
          "description": "Are you sure you want to delete this notice? This action cannot be undone.",
          "success": "Successfully deleted"
        }
      }
    },
    "form": {
      "add": {
        "title": "Add Notice",
        "button": "Add Notice"
      },
      "edit": {
        "title": "Edit Notice"
      },
      "fields": {
        "title": {
          "label": "Title",
          "placeholder": "Please enter notice title"
        },
        "content": {
          "label": "Content"
        },
        "img_url": {
          "label": "Background Image",
          "placeholder": "Please enter notice background image URL"
        },
        "show": {
          "label": "Display"
        },
        "tags": {
          "label": "Tags",
          "placeholder": "Press Enter to add tags"
        }
      },
      "buttons": {
        "cancel": "Cancel",
        "submit": "Submit",
        "success": "Successfully submitted"
      }
    }
  },
  "group": {
    "title": "Permission Groups",
    "description": "Manage all permission groups, including adding, deleting, and editing operations.",
    "columns": {
      "id": "Group ID",
      "name": "Group Name",
      "usersCount": "Users Count",
      "serverCount": "Nodes Count",
      "actions": "Actions"
    },
    "form": {
      "add": "Add Group",
      "edit": "Edit Group",
      "create": "Create Group",
      "update": "Update",
      "name": "Group Name",
      "namePlaceholder": "Please enter group name",
      "nameDescription": "Group name is used to identify different user groups, it's recommended to use meaningful names.",
      "cancel": "Cancel",
      "editDescription": "Modify group information, changes will take effect immediately.",
      "createDescription": "Create a new permission group to assign different permissions to different users."
    },
    "toolbar": {
      "searchPlaceholder": "Search groups...",
      "reset": "Reset",
      "sort": {
        "tip": "Drag groups to sort, then click save",
        "edit": "Edit Sort",
        "save": "Save Sort",
        "success": "Sort order saved"
      }
    },
    "messages": {
      "deleteConfirm": "Confirm Delete",
      "deleteDescription": "This action will permanently delete this permission group and cannot be recovered. Are you sure you want to continue?",
      "deleteButton": "Delete",
      "createSuccess": "Created Successfully",
      "updateSuccess": "Updated Successfully",
      "nameValidation": {
        "min": "Group name must be at least 2 characters",
        "max": "Group name cannot exceed 50 characters",
        "pattern": "Group name can only contain letters, numbers, Chinese characters, underscores and hyphens"
      }
    }
  },
  "auth": {
    "signIn": {
      "title": "Sign In",
      "description": "Enter your email and password to sign in",
      "email": "Email",
      "emailPlaceholder": "name@example.com",
      "password": "Password",
      "passwordPlaceholder": "Enter your password",
      "forgotPassword": "Forgot Password?",
      "submit": "Sign In",
      "rememberMe": "Remember me",
      "resetPassword": {
        "title": "Reset Password",
        "description": "Execute the following command in the site directory to reset your password",
        "command": "php artisan reset:password admin-email"
      },
      "totp": {
        "title": "Two-Factor Authentication",
        "description": "Enter the code from your authenticator app, or use one of your recovery codes.",
        "code": "Verification code",
        "codePlaceholder": "Enter the 6-digit code or a recovery code",
        "submit": "Verify and sign in",
        "back": "Back to sign in",
        "failed": "Verification failed, please try again"
      },
      "validation": {
        "emailRequired": "Please enter your email address",
        "emailInvalid": "Please enter a valid email address",
        "passwordRequired": "Please enter your password",
        "passwordLength": "Password must be at least 7 characters"
      }
    }
  },
  "traffic": {
    "trafficRecord": {
      "title": "Traffic Usage Records",
      "time": "Time",
      "upload": "Upload",
      "download": "Download",
      "rate": "Rate",
      "total": "Total",
      "noRecords": "No records found",
      "perPage": "Show per page",
      "records": "records",
      "page": "Page {{current}} / {{total}}",
      "multiplier": "{{value}}x"
    }
  },
  "payment": {
    "title": "Payment Configuration",
    "description": "Configure payment methods including Alipay, WeChat Pay, etc.",
    "table": {
      "columns": {
        "id": "ID",
        "enable": "Enable",
        "name": "Display Name",
        "payment": "Payment Gateway",
        "notify_url": "Notify URL",
        "notify_url_tooltip": "The payment gateway will send notifications to this address. Please ensure it's accessible through your firewall.",
        "actions": "Actions"
      },
      "actions": {
        "edit": "Edit",
        "delete": {
          "title": "Confirm Delete",
          "description": "Are you sure you want to delete this payment method? This action cannot be undone.",
          "success": "Successfully deleted"
        }
      },
      "toolbar": {
        "search": "Search payment methods...",
        "reset": "Reset",
        "sort": {
          "hint": "Drag payment methods to sort, click save when finished",
          "save": "Save Order",
          "edit": "Edit Order"
        }
      }
    },
    "form": {
      "add": {
        "button": "Add Payment Method",
        "title": "Add Payment Method"
      },
      "edit": {
        "title": "Edit Payment Method"
      },
      "fields": {
        "name": {
          "label": "Display Name",
          "placeholder": "Enter payment name",
          "description": "Used for frontend display"
        },
        "icon": {
          "label": "Icon URL",
          "placeholder": "https://example.com/icon.svg",
          "description": "Icon URL for frontend display"
        },
        "notify_domain": {
          "label": "Notify Domain",
          "placeholder": "https://example.com",
          "description": "Domain for gateway notifications"
        },
        "handling_fee_percent": {
          "label": "Percentage Fee (%)",
          "placeholder": "0-100"
        },
        "handling_fee_fixed": {
          "label": "Fixed Fee",
          "placeholder": "0"
        },
        "payment": {
          "label": "Payment Gateway",
          "placeholder": "Select payment gateway",
          "description": "Choose the payment gateway to use"
        }
      },
      "validation": {
        "name": {
          "min": "Name must be at least 2 characters",
          "max": "Name cannot exceed 30 characters"
        },
        "notify_domain": {
          "url": "Please enter a valid URL"
        },
        "payment": {
          "required": "Please select a payment gateway"
        }
      },
      "buttons": {
        "cancel": "Cancel",
        "submit": "Submit"
      },
      "sections": {
        "payment_config": "Payment Configuration"
      },
      "messages": {
        "success": "Saved successfully"
      }
    }
  },
  "server": {
    "realityScan": {
      "certChain": "Certificate chain",
      "location": "IP location",
      "pageStatus": "Page status",
      "unknown": "Unknown",
      "notProvided": "Not provided",
      "cdnNotDetected": "No signatures found",
      "detailsUpgrade": "CDN and page status require Node v2.14.0 or later.",
      "page": {
        "normal": "OK", "redirect": "Redirect", "unchanged": "Not modified",
        "authentication": "Authentication required", "forbidden": "Forbidden", "notFound": "Not found",
        "rateLimited": "Too many requests", "restricted": "Restricted", "serverError": "Server error",
        "clientError": "Request error", "information": "Informational", "timeout": "Response timed out",
        "failed": "Request failed", "not_checked": "Not checked"
      },
      "close": "Close",
      "scanCurrent": "Test current target",
      "scanTargets": "Scan targets",
      "title": "Reality target scanner",
      "targets": "Targets",
      "placeholder": "Domains, IPs or CIDRs, separated by commas or new lines. Leave empty for presets.",
      "scan": "Start scan",
      "scanning": "Scanning…",
      "pending": "Waiting for node",
      "running": "Node is scanning",
      "requestFailed": "Unable to read scan results. Please retry.",
      "bindMachine": "Bind this node to a server first.",
      "currentRequired": "Enter a target domain and valid port first.",
      "currentDestinationRequired": "Enter a destination address and handshake domain first.",
      "expired": "Scan record expired. Start a new scan.",
      "retry": "Read again",
      "applied": "{{target}} applied. Save the node to keep this change.",
      "empty": "No usable domains found.",
      "available": "Available",
      "unavailable": "Unavailable",
      "use": "Use",
      "curve": "Key exchange",
      "certificate": "Certificate",
      "valid": "Valid",
      "invalid": "Failed",
      "expires": "Expires",
      "certDomain": "Certificate domain",
      "reason": {
        "dns_failed": "DNS lookup failed.",
        "private_target": "Private, local and reserved addresses are blocked.",
        "connection_failed": "Unable to connect to the target port.",
        "tls_failed": "TLS handshake failed or timed out.",
        "no_certificate": "No certificate returned.",
        "no_domain": "No usable non-wildcard domain in certificate.",
        "discovered": "Domain discovered, but certificate chain verification failed.",
        "certificate_invalid": "Certificate is untrusted, expired or does not match the domain.",
        "tls13_required": "Target does not support TLS 1.3.",
        "h2_required": "Target did not negotiate HTTP/2.",
        "x25519_required": "Target did not use X25519 key exchange.",
        "invalid_target": "Invalid target format.",
        "invalid_cidr": "Invalid CIDR or more than 256 addresses.",
        "too_many_targets": "A scan supports at most 512 addresses.",
        "timeout": "Scan timed out. Reduce the number of targets and retry.",
        "node_restarted": "Node restarted or was disabled during scan. Please retry.",
        "unknown": "Scan failed."
      }
    },
    "visibility": { "hide": "Hide", "show": "Show", "hidden": "Hidden", "failed": "Failed to update visibility. Please try again.", "refreshFailed": "Visibility updated. Refresh the list to confirm." },
    "portConflictWarning": "Possible port conflict",
    "title": "Node Configuration",
    "description": "Configure node communication and synchronization settings, including communication key, polling interval, load balancing and other advanced options.",
    "server_token": {
      "title": "Communication Key",
      "description": "The key for communication between Xboard and nodes to prevent unauthorized data access.",
      "placeholder": "Please enter communication key"
    },
    "server_pull_interval": {
      "title": "Node Pull Action Polling Interval",
      "description": "The frequency at which nodes retrieve data from the panel.",
      "placeholder": "Please enter pull interval"
    },
    "server_push_interval": {
      "title": "Node Push Action Polling Interval",
      "description": "The frequency at which nodes push data to the panel.",
      "placeholder": "Please enter push interval"
    },
    "device_limit_mode": {
      "title": "Device Limit Mode",
      "description": "In relaxed mode, multiple nodes from the same IP address count as one device.",
      "strict": "Strict Mode",
      "relaxed": "Relaxed Mode",
      "placeholder": "Please select device limit mode"
    },
    "saving": "Saving...",
    "manage": {
      "title": "Node Management",
      "description": "Manage all nodes, including adding, deleting, editing and other operations.",
      "filtered_by_server": "Viewing nodes hosted by {{server}} (SID:{{id}})",
      "filtered_by_server_description": "New nodes created here can directly reuse the current server as their deployment target.",
      "add_node_to_server": "Add node to this server",
      "clear_server_filter": "Clear server filter"
    },
    "columns": {
      "sort": "Sort",
      "nodeId": "Node ID",
      "show": "Show",
      "node": "Node",
      "address": "Address",
      "onlineUsers": {
        "title": "Online Users",
        "tooltip": "Online users count based on server reporting frequency"
      },
      "rate": {
        "title": "Rate",
        "tooltip": "Traffic billing rate"
      },
      "usage": {"title":"Node usage","tooltip":"Raw upload plus download on the route used. Relay belongs to the landing node; entries count direct traffic only. No multiplier."},
      "capacity": {"title":"Carried / limit","tooltip":"Existing carried traffic and reset rules, including entry forwarding. No multiplier."},
      "traffic": {
        "title": "Traffic Usage",
        "tooltip": "Node traffic usage, showing used traffic and limit",
        "total": "Total",
        "used": "Used",
        "percentage": "Usage"
      },
      "groups": {
        "title": "Permission Groups",
        "tooltip": "Groups that can subscribe to this node",
        "empty": "--",
        "more": "Show all {{total}} permission groups"
      },
      "loadStatus": {
        "title": "Load Status",
        "tooltip": "Server resource usage",
        "noData": "No Data",
        "details": "System Load Details",
        "cpu": "CPU Usage",
        "memory": "Memory Usage",
        "swap": "Swap Usage",
        "disk": "Disk Usage",
        "lastUpdate": "Last Updated",
        "metrics": {
          "title": "Metrics",
          "uptime": "Uptime",
          "conns": "Connections",
          "speed": "Speed"
        }
      },
      "customId": "Custom ID",
      "originalId": "Original ID",
      "type": "Type",
      "actions": "Actions",
      "copyAddress": "Copy Connection Address",
      "internalPort": "Internal Port",
      "deployment": {
        "title": "Deployment",
        "tooltip": "Show whether a node runs standalone or is hosted by a server, and adjust it directly from the list.",
        "standalone": "Standalone",
        "standalone_row_hint": "Not bound to a server",
        "standalone_description": "This node runs independently without server hosting.",
        "online": "Server online",
        "offline": "Server offline",
        "inactive": "Server inactive",
        "disabled": "Node disabled",
        "enabled": "Enable on server",
        "enabled_description": "Only enabled nodes will be started and synced by the selected server.",
        "enabled_standalone_description": "Standalone nodes do not need a server-side enabled state.",
        "bind_success": "Hosted by {{server}}",
        "standalone_success": "Switched to standalone deployment",
        "update_success": "Deployment updated",
        "update_error": "Failed to update deployment"
      },
      "status": {
        "0": "Not Running",
        "1": "Unused or Abnormal",
        "2": "Running Normal"
      },
      "childNode": "Child Node",
      "actions_dropdown": {
        "edit": "Edit",
        "copy": "Copy",
        "reset_traffic": {
          "title": "Confirm Reset Traffic",
          "description": "This will reset the upload and download traffic to zero and unban the node. Are you sure you want to continue?",
          "confirm": "Reset Traffic"
        },
        "reset_traffic_success": "Traffic reset successfully",
        "delete": {
          "title": "Confirm Delete",
          "description": "This action will permanently delete this node and cannot be undone. Are you sure you want to continue?",
          "confirm": "Delete"
        },
        "copy_success": "Copied successfully",
        "delete_success": "Deleted successfully"
      }
    },
    "toolbar": {
      "unify_reality": {
        "loading_pools": "Loading related front pools…",
        "scope_failed": "Failed to load related pools. Please retry.",
        "reload_pools": "Reload related pools",
        "related_pools": "Related pools to update:",
        "linked_success": "Unified {{count}} nodes and updated {{pools}} front pools",
        "generate_short_failed": "Failed to generate a Short ID. Please retry.",
        "mode": "Unification method",
        "node_mode": "Use a selected node",
        "manual_mode": "Enter manually",
        "source": "Reference node",
        "menu": "Unify Reality parameters",
        "description": "Unify the key pair, short ID, handshake hostname and port for {{count}} selected nodes. Clients using the previous parameters must update their subscriptions.",
        "server_name": "Handshake hostname",
        "server_port": "Handshake port",
        "cancel": "Cancel",
        "confirm": "Confirm",
        "pending": "Applying",
        "success": "Unified Reality parameters for {{count}} nodes",
        "failed": "Failed to unify Reality parameters. Please retry."
      },
      "search": "Search nodes...",
      "country": "Region",
      "country_unknown": "Unrecognized",
      "type": "Type",
      "server": "Server",
      "server_search": "Search servers...",
      "server_empty": "No servers found",
      "reset": "Reset",
      "actions": "Actions",
      "sort": {
        "tip": "Drag nodes to sort, then click save",
        "batch": "Batch sorting",
        "selected": "{{count}} nodes selected",
        "top": "Move to top",
        "up": "Move up",
        "down": "Move down",
        "bottom": "Move to bottom",
        "clear": "Clear selection",
        "error": "Failed to save or refresh the order. Please retry.",
        "edit": "Edit Sort",
        "save": "Save Sort",
        "success": "Sort order saved"
      },
      "batch_delete": {
        "menu": "Delete nodes",
        "button": "Delete {{count}} items",
        "title": "Confirm Batch Delete",
        "description": "Are you sure you want to delete the selected {{count}} nodes? This action cannot be undone.",
        "confirm": "Confirm Delete"
      },
      "batch_delete_success": "Successfully deleted {{count}} nodes",
      "batch_delete_error": "Batch delete failed",
      "batch_show": {
        "menu": "Show Nodes"
      },
      "batch_show_success": "Successfully shown {{count}} nodes",
      "batch_show_error": "Batch show failed",
      "batch_hide": {
        "menu": "Hide Nodes"
      },
      "batch_hide_success": "Successfully hidden {{count}} nodes",
      "batch_hide_error": "Batch hide failed",
      "batch_enable": {
        "menu": "Enable Nodes"
      },
      "batch_enable_success": "Successfully enabled {{count}} nodes",
      "batch_enable_error": "Batch enable failed",
      "batch_disable": {
        "menu": "Disable Nodes"
      },
      "batch_disable_success": "Successfully disabled {{count}} nodes",
      "batch_disable_error": "Batch disable failed",
      "batch_reset_traffic": {
        "menu": "Reset traffic",
        "button": "Reset {{count}} traffic",
        "title": "Confirm Batch Reset Traffic",
        "description": "Are you sure you want to reset traffic for the selected {{count}} nodes? This will clear traffic and unban the nodes.",
        "confirm": "Confirm Reset"
      },
      "batch_reset_traffic_success": "Successfully reset traffic for {{count}} nodes",
      "batch_reset_traffic_error": "Batch reset traffic failed"
    },
    "form": {
      "add_node": "Add Node",
      "edit_node": "Edit Node",
      "new_node": "New Node",
      "type": {
        "placeholder": "Select Protocol Type",
        "select_prompt": "Please select a protocol type first",
        "select_error": "Please select a protocol type"
      },
      "name": {
        "label": "Node Name",
        "placeholder": "Please enter node name",
        "error": "Please enter a valid name"
      },
      "rate": {
        "label": "Base Rate",
        "effective_label": "Entry rate",
        "independent_label": "Independent rate",
        "error": "Base rate is required",
        "error_numeric": "Base rate must be a number",
        "error_gte_zero": "Base rate must be greater than or equal to 0",
        "child_node_tooltip": "Child node's base rate is inherited from parent node and cannot be set separately",
        "child_node_note": "Child node rate inherited from parent"
      },
      "traffic_limit": {
        "label": "Traffic Limit",
        "placeholder": "0 means no limit",
        "hint": "Set node traffic limit (unit: GB), 0 means no limit",
        "error_numeric": "Traffic limit must be a number",
        "error_gte_zero": "Traffic limit must be greater than or equal to 0"
      },
      "banned": {
        "label": "Disable Node",
        "description": "Node will be unavailable when disabled"
      },
      "dynamic_rate": {
        "section_title": "Dynamic Rate Configuration",
        "enable_label": "Enable Dynamic Rate",
        "enable_description": "Set different rate multipliers based on time periods",
        "rules_label": "Time Period Rules",
        "add_rule": "Add Rule",
        "rule_title": "Rule {{index}}",
        "start_time": "Start Time",
        "end_time": "End Time",
        "multiplier": "Rate Multiplier",
        "no_rules": "No rules yet, click the button above to add",
        "start_time_error": "Start time is required",
        "end_time_error": "End time is required",
        "multiplier_error": "Rate multiplier is required",
        "multiplier_error_numeric": "Rate multiplier must be a number",
        "multiplier_error_gte_zero": "Rate multiplier must be greater than or equal to 0"
      },
      "code": {
        "label": "Custom Node ID",
        "optional": "(Optional)",
        "placeholder": "Please enter custom node ID"
      },
      "tags": {
        "label": "Node Tags",
        "placeholder": "Press Enter to add tags"
      },
      "groups": {
        "label": "Permission Groups",
        "add": "Add Group",
        "placeholder": "Please select permission groups",
        "empty": "No results found"
      },
      "machine": {
        "label": "Bind to Machine",
        "placeholder": "Select a machine (optional)",
        "none": "Standalone",
        "enabled_hint": "Whether this machine manages the node"
      },
      "host": {
        "label": "Node Address",
        "placeholder": "Please enter domain or IP",
        "error": "Node address is required"
      },
      "port": {
        "label": "Connection Port",
        "placeholder": "User connection port",
        "tooltip": "The port that users actually connect to, this is the port number that needs to be filled in the client configuration. If using transit or tunnel, this port may be different from the port that the server actually listens on.",
        "sync": "Sync to server port",
        "error": "Connection port is required"
      },
      "server_port": {
        "label": "Server Port",
        "placeholder": "Enter server port",
        "error": "Server port is required",
        "tooltip": "The actual listening port on the server.",
        "sync": "Sync to server port"
      },
      "parent": {
        "label": "Parent Node",
        "placeholder": "Select parent node",
        "none": "None"
      },
      "proxy_protocol": {
        "label": "Receive PROXY protocol"
      },
      "auto_firewall": {
        "label": "Manage firewall automatically",
        "disabled_hint": "Turning this off restores existing rules. Source lists will no longer be enforced by the system firewall."
      },
      "source_policy": {
        "label": "Source IP restrictions",
        "disabled": "Disabled",
        "blacklist": "Blacklist",
        "whitelist": "Whitelist",
        "block_ips": "Blocked source IPs",
        "allow_ips": "Allowed source IPs",
        "exceptions": "Mainland China IP exceptions",
        "block_cn": "Block mainland China source IPs",
        "placeholder": "Enter an IP and press Enter",
        "invalid_ip": "Enter an individual IPv4 or IPv6 address",
        "max_ips": "Up to 128 IPs per list",
        "empty_whitelist": "Add at least one IP to the whitelist",
        "connections": "Connections",
        "save": "Save"
      },
      "route": {
        "label": "Route Groups",
        "placeholder": "Select route groups",
        "empty": "No results found"
      },
      "submit": "Submit",
      "cancel": "Cancel",
      "success": "Submitted successfully"
    },
    "dynamic_form": {
      "multiplex": {
        "enabled": {
          "label": "Multiplex",
          "description": "Transport multiple streams via a single TCP connection"
        },
        "protocol": {
          "label": "Protocol"
        },
        "max_connections": {
          "label": "Max Connections"
        },
        "min_streams": {
          "label": "Min Streams"
        },
        "padding": {
          "label": "Enable Padding"
        },
        "brutal": {
          "enabled": {
            "label": "TCP Brutal"
          },
          "up_mbps": {
            "label": "Upload Bandwidth"
          },
          "down_mbps": {
            "label": "Download Bandwidth"
          },
          "description": "TCP Brutal is a bilateral acceleration algorithm. Set bandwidth to 80%-90% of actual capacity. BBR will be disabled when enabled."
        }
      },
      "ech": {
        "description": "Encrypted Client Hello for supported TLS clients. Leave config empty to query DNS automatically.",
        "generate": "Auto-generate ECH Key Pair",
        "config": {
          "label": "ECH Config (PEM)",
          "placeholder": "Paste the ECH configuration in PEM format, one line per row",
          "description": "If empty, sing-box will attempt to load ECH configuration from DNS."
        },
        "config_path": {
          "label": "ECH Config Path",
          "placeholder": "/etc/sing-box/ech.pem",
          "description": "Path to an ECH configuration file in PEM format."
        },
        "query_server_name": {
          "label": "ECH Query Server Name",
          "placeholder": "Optional override for HTTPS record lookup",
          "description": "Overrides the domain used for ECH HTTPS record queries. Defaults to server_name."
        },
        "key": {
          "label": "ECH Key",
          "placeholder": "Paste ECH key content when backend requires it",
          "description": "Optional ECH key payload used by the backend."
        },
        "key_path": {
          "label": "ECH Key Path",
          "placeholder": "/etc/sing-box/ech.key",
          "description": "Path to the ECH key file when the backend requires it."
        }
      },
      "anytls": {
        "tls": {
          "server_name": {
            "label": "Server Name Indication (SNI)",
            "placeholder": "Used for certificate verification when domain differs from node address"
          },
          "allow_insecure": "Allow Insecure"
        },
        "padding_scheme": {
          "description": "Each line represents a padding rule, format: stop=8, 0=30-30",
          "label": "Padding Scheme",
          "placeholder": "Enter padding rules",
          "use_default": "Use Default Scheme",
          "edit_btn": "Edit Padding Scheme",
          "configured": "{{count}} rules configured",
          "not_configured": "Not configured"
        }
      },
      "shadowsocks": {
        "cipher": {
          "label": "Encryption Method",
          "placeholder": "Select encryption method",
          "search_placeholder": "Search or enter custom encryption method...",
          "description": "Select preset encryption method or enter custom encryption method",
          "preset_group": "Preset Encryption Methods",
          "custom_group": "Custom Encryption Method",
          "current_value": "Current Value",
          "use_custom": "Use",
          "no_results": "No matching encryption method found",
          "custom_hint": "You can directly enter a custom encryption method, such as: aes-256-cfb",
          "custom_label": "Custom"
        },
        "plugin": {
          "label": "Plugin",
          "placeholder": "Select plugin",
          "obfs_hint": "Hint: Configuration format like obfs=http;obfs-host=www.bing.com;path=/",
          "v2ray_hint": "Hint: WebSocket mode format is mode=websocket;host=mydomain.me;path=/;tls=true, QUIC mode format is mode=quic;host=mydomain.me",
          "gost_hint": "Hint: Configuration format like mode=websocket;host=mydomain.me;path=/;tls=true",
          "shadow_tls_hint": "Hint: Configuration format like host=cloud.tencent.com;password=auth_password;version=3",
          "restls_hint": "Hint: Configuration format like host=www.microsoft.com;password=auth_password;version-hint=tls13;restls-script=300?100<1,400~100",
          "kcptun_hint": "Hint: Configuration format like key=psk;crypt=aes-128-gcm;mode=fast;mtu=1350"
        },
        "plugin_opts": {
          "label": "Plugin Options",
          "description": "Enter plugin options in key=value;key2=value2 format",
          "placeholder": "Example: mode=tls;host=bing.com"
        },
        "client_fingerprint": "Client Fingerprint",
        "client_fingerprint_placeholder": "Select client fingerprint",
        "client_fingerprint_description": "Client spoofing fingerprint to reduce detection risk",
        "obfs": {
          "label": "Obfuscation",
          "placeholder": "Select obfuscation method",
          "none": "None",
          "http": "HTTP"
        },
        "obfs_settings": {
          "path": "Path",
          "host": "Host"
        },
        "cert_config": {
          "tab": "TLS Cert",
          "cert_mode": {
            "label": "Cert Mode",
            "description": "Select how to manage certificates",
            "self_description": "Self-signed: Valid for 10 years, auto-generated by node",
            "http_description": "HTTP-01: Port 80 must be reachable",
            "dns_description": "DNS-01: Authenticate via DNS records, supports wildcard certs",
            "content_description": "Content: Push raw cert files to node"
          },
          "domain": {
            "label": "Domain",
            "placeholder": "example.com"
          },
          "email": {
            "label": "Notification Email",
            "placeholder": "admin@example.com"
          },
          "http_port": {
            "label": "Challenge Port",
            "description": "ACME challenge port (default 80)"
          },
          "dns_provider": {
            "label": "DNS Provider",
            "doc_link": "DNS provider configuration guide"
          },
          "dns_env": {
            "label": "Env Vars (API Keys)",
            "description_short": "One KEY=VALUE per line"
          },
          "cert_content": {
            "label": "Public Key content"
          },
          "key_content": {
            "label": "Private Key content"
          },
          "none_desc": "TLS config disabled"
        }
      },
      "vmess": {
        "tls": {
          "label": "TLS",
          "placeholder": "Please select security",
          "disabled": "Disabled",
          "enabled": "Enabled"
        },
        "tls_settings": {
          "server_name": {
            "label": "Server Name Indication (SNI)",
            "placeholder": "Leave empty if not used"
          },
          "allow_insecure": "Allow Insecure?"
        },
        "network": {
          "label": "Transport Protocol",
          "placeholder": "Select transport protocol"
        }
      },
      "trojan": {
        "server_name": {
          "label": "Server Name Indication (SNI)",
          "placeholder": "Used for certificate verification when node address differs from certificate"
        },
        "allow_insecure": "Allow Insecure?",
        "reality_settings": {
          "server_name": {
            "label": "Destination Site (dest)",
            "placeholder": "e.g., example.com"
          },
          "server_port": {
            "label": "Port",
            "placeholder": "e.g., 443"
          },
          "allow_insecure": "Allow Insecure?",
          "private_key": {
            "label": "Private Key"
          },
          "public_key": {
            "label": "Public Key"
          },
          "short_id": {
            "label": "Short ID",
            "placeholder": "Optional, length must be even, max 16 characters",
            "description": "List of shortIds available to clients, can be used to distinguish different clients, using hexadecimal characters 0-f",
            "generate": "Generate Short ID",
            "success": "Short ID generated successfully"
          },
          "key_pair": {
            "generate": "Generate Key Pair",
            "success": "Key pair generated successfully",
            "error": "Failed to generate key pair"
          }
        },
        "network": {
          "label": "Transport Protocol",
          "placeholder": "Select transport protocol"
        }
      },
      "hysteria": {
        "version": {
          "label": "Protocol Version",
          "placeholder": "Protocol version"
        },
        "alpn": {
          "label": "ALPN",
          "placeholder": "ALPN"
        },
        "obfs": {
          "label": "Obfuscation",
          "type": {
            "label": "Obfuscation Implementation",
            "placeholder": "Select obfuscation implementation",
            "salamander": "Salamander"
          },
          "password": {
            "label": "Obfuscation Password",
            "placeholder": "Please enter obfuscation password",
            "generate_success": "Obfuscation password generated successfully"
          }
        },
        "tls": {
          "server_name": {
            "label": "Server Name Indication (SNI)",
            "placeholder": "Used for certificate verification when node address differs from certificate"
          },
          "allow_insecure": "Allow Insecure?"
        },
        "bandwidth": {
          "up": {
            "label": "Upload Bandwidth",
            "placeholder": "Please enter upload bandwidth",
            "suffix": "Mbps",
            "bbr_tip": ", leave empty to use BBR"
          },
          "down": {
            "label": "Download Bandwidth",
            "placeholder": "Please enter download bandwidth",
            "suffix": "Mbps",
            "bbr_tip": ", leave empty to use BBR"
          }
        }
      },
      "vless": {
        "xhttp": {
          "path": "Path",
          "host": "Host",
          "mode": "XHTTP mode",
          "http": "HTTP version",
          "default": "Default",
          "split": "Separate upload and download",
          "address": "Download address",
          "port": "Download port",
          "security": "Download security",
          "none": "None",
          "sni": "Download server name",
          "publicKey": "Download Reality public key",
          "shortId": "Download Short ID",
          "sameInbound": "Both paths must reach the same XHTTP inbound."
        },
        "tls": {
          "label": "Security",
          "placeholder": "Please select security",
          "none": "None",
          "tls": "TLS",
          "reality": "Reality"
        },
        "tls_settings": {
          "server_name": {
            "label": "Server Name Indication (SNI)",
            "placeholder": "Leave empty if not used"
          },
          "allow_insecure": "Allow Insecure?"
        },
        "reality_settings": {
          "anti_abuse": {
            "label": "Anti-Abuse Mode",
            "description": "Camouflage fallback goes through a loopback-only inbound on the node; only TLS domains of the camouflage site are allowed, all other traffic is blocked"
          },
          "dest": {
            "label": "Destination (dest)",
            "placeholder": "e.g., 127.0.0.1:8443"
          },
          "server_name": {
            "label": "Handshake Domain (SNI)",
            "placeholder": "e.g., example.com"
          },
          "server_port": {
            "label": "Port",
            "placeholder": "e.g., 443"
          },
          "allow_insecure": "Allow Insecure?",
          "private_key": {
            "label": "Private Key"
          },
          "public_key": {
            "label": "Public Key"
          },
          "short_id": {
            "label": "Short ID",
            "placeholder": "Optional, length must be even, max 16 characters",
            "description": "List of shortIds available to clients, can be used to distinguish different clients, using hexadecimal characters 0-f",
            "generate": "Generate Short ID",
            "success": "Short ID generated successfully"
          },
          "key_pair": {
            "generate": "Generate Key Pair",
            "success": "Key pair generated successfully",
            "error": "Failed to generate key pair"
          }
        },
        "network": {
          "label": "Transport Protocol",
          "placeholder": "Select transport protocol"
        },
        "flow": {
          "label": "Flow Control",
          "placeholder": "Select flow control"
        },
        "encryption": {
          "label": "VLESS Encryption",
          "description": "Enable VLESS encryption",
          "server_label": "decryption",
          "server_placeholder": "./xray vlessenc",
          "server_description": "",
          "client_label": "encryption",
          "client_placeholder": "./xray vlessenc",
          "client_description": "",
          "generate_hint": "./xray vlessenc"
        }
      },
      "tuic": {
        "version": {
          "label": "Protocol Version",
          "placeholder": "Select TUIC Version"
        },
        "password": {
          "label": "Password",
          "placeholder": "Enter Password",
          "generate_success": "Password Generated Successfully"
        },
        "congestion_control": {
          "label": "Congestion Control",
          "placeholder": "Select Congestion Control Algorithm"
        },
        "udp_relay_mode": {
          "label": "UDP Relay Mode",
          "placeholder": "Select UDP Relay Mode"
        },
        "tls": {
          "server_name": {
            "label": "Server Name Indication (SNI)",
            "placeholder": "Used for certificate verification when domain differs from node address"
          },
          "allow_insecure": "Allow Insecure?",
          "alpn": {
            "label": "ALPN",
            "placeholder": "Select ALPN Protocols",
            "empty": "No ALPN Protocols Available"
          }
        }
      },
      "socks": {
        "version": {
          "label": "Protocol Version",
          "placeholder": "Select SOCKS Version"
        },
        "tls": {
          "label": "TLS",
          "placeholder": "Please select security",
          "disabled": "Disabled",
          "enabled": "Enabled"
        },
        "tls_settings": {
          "server_name": {
            "label": "Server Name Indication (SNI)",
            "placeholder": "Leave empty if not used"
          },
          "allow_insecure": "Allow Insecure?"
        },
        "network": {
          "label": "Transport Protocol",
          "placeholder": "Select transport protocol"
        }
      },
      "naive": {
        "tls_settings": {
          "server_name": {
            "label": "Server Name Indication (SNI)",
            "placeholder": "Used for certificate verification when domain differs from node address"
          },
          "allow_insecure": "Allow Insecure"
        },
        "tls": {
          "label": "TLS",
          "placeholder": "Please select security",
          "disabled": "Disabled",
          "enabled": "Enabled",
          "server_name": {
            "label": "Server Name Indication (SNI)",
            "placeholder": "Used for certificate verification when domain differs from node address"
          },
          "allow_insecure": "Allow Insecure"
        }
      },
      "http": {
        "tls_settings": {
          "server_name": {
            "label": "Server Name Indication (SNI)",
            "placeholder": "Used for certificate verification when domain differs from node address"
          },
          "allow_insecure": "Allow Insecure"
        },
        "tls": {
          "label": "TLS",
          "placeholder": "Please select security",
          "disabled": "Disabled",
          "enabled": "Enabled",
          "server_name": {
            "label": "Server Name Indication (SNI)",
            "placeholder": "Used for certificate verification when domain differs from node address"
          },
          "allow_insecure": "Allow Insecure"
        }
      },
      "mieru": {
        "transport": {
          "label": "Transport Protocol",
          "placeholder": "Select transport protocol"
        },
        "traffic_pattern": {
          "label": "Traffic Pattern (Base64)",
          "placeholder": "Enter Base64 string for network fine-tuning",
          "success": "Traffic pattern generated"
        }
      },
      "routing": {
        "outbounds_tab": "Custom Outbounds",
        "routes_tab": "Custom Routes",
        "outbounds": "Custom Outbounds (JSON)",
        "routes": "Custom Routes (JSON)",
        "error": {
          "must_be_array": "Must be a JSON array []",
          "invalid_json": "Invalid JSON format"
        }
      },
      "advanced": {
        "trigger_label": "Advanced Config",
        "dialog_title": "Advanced Protocol Configuration",
        "tls_tab": "TLS",
        "route_tab": "Routing",
        "multiplex_tab": "Multiplex"
      }
    },
    "network_settings": {
      "edit_protocol": "Edit Protocol",
      "edit_protocol_config": "Edit Protocol Configuration",
      "use_template": "Use {{template}} Template",
      "json_config_placeholder": "Please enter JSON configuration",
      "json_config_placeholder_with_template": "Please enter JSON configuration or select template above",
      "validation": {
        "must_be_object": "Configuration must be a JSON object",
        "invalid_json": "Invalid JSON format"
      },
      "errors": {
        "save_failed": "Error occurred while saving"
      }
    },
    "common": {
      "cancel": "Cancel",
      "confirm": "Confirm"
    }
  },
  "coupon": {
    "title": "Coupon Management",
    "description": "Here you can manage coupons, including adding, viewing, and deleting operations.",
    "table": {
      "columns": {
        "id": "ID",
        "show": "Enable",
        "name": "Coupon Name",
        "type": "Type",
        "code": "Code",
        "limitUse": "Remaining Uses",
        "limitUseWithUser": "Uses Per User",
        "validity": "Validity Period",
        "actions": "Actions"
      },
      "validity": {
        "expired": "Expired {{days}} days ago",
        "notStarted": "Starts in {{days}} days",
        "remaining": "{{days}} days remaining",
        "startTime": "Start Time",
        "endTime": "End Time",
        "unlimited": "Unlimited",
        "noLimit": "No Limit"
      },
      "actions": {
        "edit": "Edit",
        "delete": "Delete",
        "deleteConfirm": {
          "title": "Confirm Delete",
          "description": "This action will permanently delete this coupon and cannot be undone. Are you sure you want to continue?",
          "confirmText": "Delete"
        }
      },
      "toolbar": {
        "search": "Search coupons...",
        "type": "Type",
        "reset": "Reset",
        "types": {
          "1": "Fixed Amount",
          "2": "Percentage"
        }
      }
    },
    "form": {
      "add": "Add Coupon",
      "edit": "Edit Coupon",
      "name": {
        "label": "Coupon Name",
        "placeholder": "Enter coupon name",
        "required": "Please enter coupon name"
      },
      "type": {
        "label": "Coupon Type and Value",
        "placeholder": "Select coupon type"
      },
      "value": {
        "placeholder": "Enter value"
      },
      "validity": {
        "label": "Validity Period",
        "to": "to",
        "endTimeError": "End time must be later than start time"
      },
      "limitUse": {
        "label": "Maximum Uses",
        "placeholder": "Set maximum uses, leave empty for unlimited",
        "description": "Set the total number of times this coupon can be used, leave empty for unlimited uses"
      },
      "limitUseWithUser": {
        "label": "Uses Per User",
        "placeholder": "Set uses per user, leave empty for unlimited",
        "description": "Limit how many times each user can use this coupon, leave empty for unlimited uses per user"
      },
      "limitPeriod": {
        "label": "Subscription Periods",
        "placeholder": "Limit to specific subscription periods, leave empty for no restrictions",
        "description": "Select which subscription periods can use this coupon, leave empty for no period restrictions",
        "empty": "No matching periods found"
      },
      "limitPlan": {
        "label": "Subscription Plans",
        "placeholder": "Limit to specific subscription plans, leave empty for no restrictions",
        "description": "Select which subscription plans can use this coupon, leave empty for no plan restrictions",
        "empty": "No matching plans found"
      },
      "code": {
        "label": "Custom Coupon Code",
        "placeholder": "Enter custom code, leave empty for auto-generation",
        "description": "Customize the coupon code, leave empty for auto-generation"
      },
      "generateCount": {
        "label": "Batch Generation Count",
        "placeholder": "Number of coupons to generate, leave empty for single coupon",
        "description": "Generate multiple coupon codes at once, leave empty to generate a single code"
      },
      "submit": {
        "saving": "Saving...",
        "save": "Save"
      },
      "error": {
        "saveFailed": "Failed to save coupon"
      },
      "timeRange": {
        "quickSet": "Quick Set",
        "presets": {
          "1week": "1 Week",
          "2weeks": "2 Weeks",
          "1month": "1 Month",
          "3months": "3 Months",
          "6months": "6 Months",
          "1year": "1 Year"
        }
      }
    },
    "period": {
      "monthly": "Monthly",
      "quarterly": "Quarterly",
      "half_yearly": "Half Yearly",
      "yearly": "Yearly",
      "two_yearly": "Two Yearly",
      "three_yearly": "Three Yearly",
      "onetime": "One Time",
      "reset_traffic": "Reset Traffic"
    }
  },
  "route": {
    "tabs": {"rules": "Routing rules", "blocks": "Blocked requests"},
    "title": "Route Management",
    "description": "Manage all route groups, including adding, deleting, and editing operations.",
    "columns": {
      "id": "Group ID",
      "enabled": "Enabled",
      "remarks": "Remarks",
      "action": "Action",
      "actions": "Actions",
      "matchRules": "Match {{count}} rules",
      "portTag": "Port {{value}}",
      "networkTag": {
        "tcp": "TCP only",
        "udp": "UDP only"
      },
      "nodes": "{{count}} nodes",
      "applyToNewNodes": "Default for new nodes",
      "action_value": {
        "title": "Action Value",
        "dns": "DNS: {{value}}",
        "proxy": "Proxy ({{value}})",
        "block": "Block Access",
        "direct": "Direct Connection"
      }
    },
    "actions": {
      "dns": "Resolve using specified DNS server",
      "block": "Block access",
      "direct": "Direct connection",
      "proxy": "Proxy"
    },
    "form": {
      "add": "Add Route",
      "edit": "Edit Route",
      "create": "Create Route",
      "enabled": "Enable route",
      "remarks": "Remarks",
      "remarksPlaceholder": "Please enter remarks",
      "match": "Match (domain or IP)",
      "matchPlaceholder": "example.com\n*.example.com",
      "protocol": "Protocol",
      "protocolAny": "Any",
      "port": "Destination Port",
      "portPlaceholder": "25,465,6881-6889",
      "network": "Network",
      "networkAny": "TCP and UDP",
      "networkTcp": "TCP only",
      "networkUdp": "UDP only",
      "nodes": "Nodes",
      "nodesPlaceholder": "Select nodes",
      "nodesEmpty": "No nodes",
      "selectAllNodes": "Select all",
      "clearNodes": "Clear",
      "applyToNewNodes": "Apply to new nodes by default",
      "action": "Action",
      "actionPlaceholder": "Please select action",
      "dns": "DNS Server",
      "dnsPlaceholder": "Please enter DNS server",
      "proxy": "Outbound Tag",
      "proxyPlaceholder": "Please enter outbound tag",
      "cancel": "Cancel",
      "submit": "Submit",
      "validation": {
        "remarks": "Please enter valid remarks",
        "condition": "Fill in at least one match condition",
        "port": "Invalid destination port \"{{value}}\": use a port or range within 1-65535"
      }
    },
    "toolbar": {
      "searchPlaceholder": "Search routes...",
      "reset": "Reset"
    },
    "messages": {
      "deleteConfirm": "Confirm Delete",
      "deleteDescription": "This action will permanently delete this route group and cannot be recovered. Are you sure you want to continue?",
      "enableRoute": "Enable route: {{name}}",
      "disableRoute": "Disable route: {{name}}",
      "updateFailed": "Could not save route status. Please retry.",
      "deleteButton": "Delete",
      "deleteSuccess": "Deleted Successfully",
      "createSuccess": "Created Successfully",
      "updateSuccess": "Updated Successfully"
    }
  },
  "ticket": {
    "title": "Ticket Management",
    "description": "View and manage user tickets, including viewing, replying, and closing operations.",
    "columns": {
      "id": "Ticket ID",
      "subject": "Subject",
      "level": "Priority",
      "status": "Status",
      "updated_at": "Last Updated",
      "created_at": "Created At",
      "actions": "Actions"
    },
    "status": {
      "closed": "Closed",
      "replied": "Replied",
      "pending": "Pending",
      "processing": "Processing"
    },
    "level": {
      "low": "Low Priority",
      "medium": "Medium Priority",
      "high": "High Priority"
    },
    "filter": {
      "placeholder": "Search {field}...",
      "no_results": "No results found",
      "selected": "{count} selected",
      "clear": "Clear filters"
    },
    "actions": {
      "view_details": "View Details",
      "close_ticket": "Close Ticket",
      "close_confirm_title": "Confirm Close Ticket",
      "close_confirm_description": "Are you sure you want to close this ticket? It will move to the closed list, but you can still reply later.",
      "close_confirm_button": "Confirm Close",
      "close_success": "Ticket closed successfully",
      "view_ticket": "View Ticket"
    },
    "detail": {
      "no_messages": "No messages yet",
      "created_at": "Created at",
      "sender_admin": "Admin",
      "sender_user": "User",
      "user_info": "User Info",
      "traffic_records": "Traffic Records",
      "order_records": "Order Records",
      "input": {
        "closed_reply_placeholder": "This ticket is closed, but you can still reply...",
        "closed_hint": "This ticket is closed. You can keep replying and new messages will still be appended here.",
        "reply_placeholder": "Type your reply...",
        "sending": "Sending...",
        "send": "Send"
      }
    },
    "list": {
      "title": "Ticket List",
      "search_placeholder": "Search ticket subject or user email",
      "no_tickets": "No tickets",
      "no_open_tickets": "No open tickets",
      "no_closed_tickets": "No closed tickets",
      "no_search_results": "No matching tickets found",
      "collapse": "Collapse list",
      "expand": "Expand list"
    }
  },
  "machine": {
    "lite": {
      "binding_pending": "Waiting for a match; retries every minute",
      "binding_conflict": "IP match conflict; bind manually",
      "binding_matched": "Matched; waiting for automatic binding",
      "binding_paused": "Automatic binding paused",
      "resumeAuto": "Resume automatic binding",
      "connect": "Connect Lite",
      "description": "Automatically match public IPs every minute when enabled. Resolve conflicts manually.",
      "url": "Lite site URL",
      "key": "Site API key",
      "keepKey": "Leave blank to keep the saved key",
      "enabled": "Enable Lite",
      "saveRead": "Save and load",
      "read": "Load servers",
      "autoBind": "Match public IPs",
      "importSelected": "Import selected ({{count}})",
      "completed": "Processed {{count}} servers",
      "refreshFailed": "Operation completed, but the list could not be refreshed. Read it again.",
      "empty": "No servers in Lite",
      "select": "Select {{name}}",
      "boundTo": "Linked to: {{name}}",
      "unbind": "Unlink",
      "bindTarget": "Select a server for {{name}}",
      "chooseMachine": "Choose an existing server",
      "bind": "Link",
      "retry": "Retry",
      "loading": "Loading",
      "readFailed": "Read failed",
      "historyFailed": "Unable to load history",
      "missing": "Server no longer exists",
      "offline": "Offline",
      "online": "Online",
      "stale": "Data expired",
      "unknown": "Unknown",
      "lastReport": "Last report",
      "traffic": "Lite traffic / quota",
      "info": "Lite server information",
      "name": "Lite name",
      "country": "Country / region",
      "ip": "Public IP",
      "os": "Operating system / architecture",
      "cpu": "Processor",
      "cores": "CPU cores",
      "kernel": "Kernel version",
      "virtualization": "Virtualization",
      "group": "Group",
      "tags": "Tags",
      "bandwidth": "Bandwidth",
      "expires": "Expires",
      "resetDay": "Traffic reset day",
      "resetTime": "Reset time / timezone",
      "nextReset": "Next traffic reset",
      "mode": "Traffic counting method",
      "remark": "Public remark",
      "noReset": "No automatic reset",
      "monthlyDay": "Day {{day}} of each month",
      "mode_up": "Upload only",
      "mode_down": "Download only",
      "mode_sum": "Upload + download",
      "mode_max": "Larger of upload and download",
      "mode_min": "Smaller of upload and download"
    },
    "traffic": {
      "title": "Traffic used / total",
      "limit": "Traffic limit (GB, 0 unlimited)",
      "resetDay": "Monthly reset day",
      "mode": "Billing mode",
      "outbound": "One-way (outbound only)",
      "both": "Two-way (inbound + outbound)",
      "proxy": "Proxy traffic only",
      "interfaces": "Billing interfaces",
      "interfacesPlaceholder": "Automatic if empty; separate names with commas",
      "unlimitedPlaceholder": "0 for unlimited",
      "unlimited": "Unlimited",
      "invalidLimit": "Enter traffic between 0 and 8388607",
      "invalidMode": "Select a billing mode",
      "invalidDay": "Enter an integer from 1 to 31",
      "invalidInterfaces": "Enter valid interface names separated by commas",
      "exceeded": "Limit reached",
      "waiting": "Waiting for metering",
      "stale": "Metering report interrupted",
      "errors": {
        "interfaces_unavailable": "Billing interfaces unavailable",
        "state_lost": "Metering state lost; paused until next cycle",
        "state_write_failed": "Unable to save metering state"
      }
    },
    "agent": {
      "more": "More actions",
      "confirm": "Confirm",
      "cancel": "Cancel",
      "submission": "Submission",
      "version": "Running version",
      "publicIp": "Public IP",
      "operation": "Operation",
      "upgrade": "Update agent",
      "restart": "Restart agent",
      "batch_upgrade": "Batch update",
      "batch_restart": "Batch restart",
      "upgradeConfirm": "Update {{count}} selected servers?",
      "restartConfirm": "Restart {{count}} selected servers?",
      "interruption": "This briefly interrupts nodes managed by yz-agent on these servers. Updates use the latest stable release.",
      "selectPage": "Select current page",
      "selectServer": "Select server {{name}}",
      "clearSelection": "Clear selection ({{count}})",
      "queued": "Submitted: {{count}}; not submitted: {{failed}}",
      "inProgress": {
        "upgrade": "Updating",
        "restart": "Restarting"
      },
      "results": {
        "updated": "Updated and restarted",
        "up_to_date": "Already up to date",
        "current_newer": "Current version is newer; automatic downgrade skipped"
      },
      "states": {
        "pending": "Pending",
        "running": "Running",
        "succeeded": "Succeeded",
        "failed": "Failed",
        "timeout": "Unconfirmed timeout"
      },
      "errors": {
        "disabled": "Server disabled",
        "offline": "Server offline",
        "unsupported": "Remote operations unavailable",
        "busy": "Operation already running",
        "not_found": "Server not found",
        "launch_failed": "Worker could not start",
        "execution_failed": "Execution failed",
        "release_query_failed": "Could not query the latest stable release; upgrade stopped",
        "current_version_failed": "Could not read the installed version; upgrade stopped",
        "current_version_invalid": "Installed version is not recognized; upgrade stopped",
        "latest_version_invalid": "Latest stable version is not recognized; upgrade stopped",
        "timeout": "Timed out; check service status",
        "request_failed": "Submission unconfirmed; refresh and check"
      }
    },
    "title": "Server Management",
    "description": "Review server health, load, and hosted nodes, then launch node actions from an operations view.",
    "columns": {
      "id": "ID",
      "name": "Server Name",
      "status": "Status",
      "nodes": "Nodes",
      "nodesHosted": "hosting nodes",
      "nodesIdle": "idle",
      "proxyTraffic": "Server usage",
      "proxyTrafficTooltip": "Raw upload plus download for direct, forwarded and landing traffic. Same-server relay counts once. Excludes other programs.",
      "load": "Load",
      "lastSeen": "Last Seen",
      "actions": "Actions",
      "online": "Online",
      "offline": "Offline",
      "inactive": "Disabled",
      "noData": "No load data",
      "cpu": "CPU",
      "memory": "Memory",
      "disk": "Disk",
      "never": "Never",
      "lastReport": "Load report"
    },
    "toolbar": {
      "search": "Search by server name, notes or SID...",
      "status": "Status",
      "nodes": "Nodes",
      "nodesHosted": "hosting nodes",
      "nodesIdle": "idle",
      "with_nodes": "Hosting nodes",
      "idle_nodes": "Idle servers",
      "high_load": "High load",
      "online_ratio": "Online",
      "high_load_count": "High load",
      "reset": "Reset"
    },
    "overview": {
      "total": "Total Servers",
      "total_hint": "Hosting {{count}} nodes in total",
      "online": "Online Servers",
      "online_hint": "Heartbeat received in the last 5 minutes",
      "offline": "Offline / Lost",
      "offline_hint": "Heartbeat or agent should be checked",
      "high_load": "High Load",
      "high_load_hint": "CPU, memory or disk is near the threshold",
      "nodes_suffix": "nodes",
      "attention": "Attention",
      "stable": "Stable",
      "needs_review": "Review",
      "normal": "Normal"
    },
    "form": {
      "add": "Add Server",
      "create": "New Server",
      "edit": "Edit Server",
      "createDescription": "Create a server record when you want one host to manage multiple nodes.",
      "editDescription": "Modify server name, notes or status.",
      "name": "Server Name",
      "namePlaceholder": "e.g. HK-01",
      "nameError": "Server name is required",
      "notes": "Notes",
      "notesPlaceholder": "Optional notes about this server",
      "isActive": "Enable Server",
      "isActiveDescription": "Disabled servers will not be used by xboard-node.",
      "disableLogs": "Privacy protection mode",
      "disableLogsDescription": "Encrypt sensitive data and disable runtime logs while enabled. Turn off to restore them.",
      "cancel": "Cancel",
      "submit": "Submit",
      "update": "Update"
    },
    "token": {
      "title": "Server Token",
      "description": "This token is used by xboard-node to authenticate with the panel. Keep it safe.",
      "show": "View Token",
      "hide": "Hide Token",
      "reset": "Reset Token",
      "resetConfirm": "Reset Token?",
      "resetDescription": "The old token will be invalidated immediately. xboard-node must be reconfigured with the new token.",
      "copy": "Copy",
      "copied": "Token copied to clipboard",
      "copiedInline": "Copied!",
      "copyFailed": "Copy failed, please copy manually",
      "autoHide": "Auto-hides in {{time}}",
      "resetSuccess": "Token has been reset",
      "createdHint": "Token generated. You can view it anytime in the server detail page."
    },
    "install": {
      "title": "Install xboard-node",
      "description": "Run this command on the target server to install xboard-node in machine mode and connect it to this server record.",
      "copy": "Copy install command",
      "copied": "Install command copied",
      "copiedInline": "Copied!",
      "copyFailed": "Copy failed",
      "loading": "Generating command...",
      "hint": "Requires root or sudo privileges and a Linux server with systemd."
    },
    "detail": {
      "title": "Server Detail",
      "info": "Server Info",
      "associatedNodes": "Associated Nodes",
      "noNodes": "No nodes are hosted by this server.",
      "nodeId": "ID",
      "nodeName": "Name",
      "nodeType": "Type",
      "nodeHost": "Address",
      "nodePort": "Port",
      "nodeShow": "Visible",
      "nodeEnabled": "Enabled",
      "loadTrend": "Load Trend",
      "networkTrend": "Network Speed",
      "noHistory": "No historical load data yet.",
      "openNodeManage": "Open Node Management",
      "addNodeToServer": "Add Node To This Server",
      "nodeCount": "{{count}} nodes",
      "nodeEnabledCount": "{{count}} enabled",
      "toggleEnabledError": "Failed to toggle node status",
      "bindExistingButton": "Bind Existing",
      "bindExistingTitle": "Bind Existing Nodes",
      "bindExistingDescription": "Select nodes to bind to \"{{name}}\"",
      "bindSearchPlaceholder": "Search by name, address, type...",
      "noUnboundNodes": "No unbound nodes available",
      "noSearchResults": "No matching nodes",
      "selectAll": "Select all ({{count}})",
      "selectedCount": "{{count}} selected",
      "bindConfirm": "Bind {{count}} nodes",
      "binding": "Binding...",
      "bindSuccess": "Successfully bound {{count}} nodes to \"{{name}}\"",
      "bindFailed": "Binding failed",
      "unbindNode": "Unbind",
      "unbindSuccess": "\"{{name}}\" has been unbound",
      "unbindFailed": "Unbind failed",
      "cancel": "Cancel"
    },
    "messages": {
      "createSuccess": "Server created successfully",
      "updateSuccess": "Server updated successfully",
      "deleteConfirm": "Delete Server?",
      "deleteDescription": "Associated nodes will be unbound (not deleted). This action cannot be undone.",
      "deleteButton": "Delete",
      "deleteSuccess": "Server deleted successfully",
      "deleteFailed": "Failed to delete server",
      "saveFailed": "Failed to save server",
      "tokenFetchFailed": "Failed to fetch token",
      "tokenResetFailed": "Failed to reset token"
    },
    "nodeForm": {
      "machineId": "Bind to Server",
      "machineIdPlaceholder": "Select a server (optional)",
      "machineIdNone": "Standalone deployment",
      "enabled": "Enabled on Server",
      "enabledDescription": "Whether the node is activated on the selected server"
    }
  },
  "search": {
    "placeholder": "Search menus and functions...",
    "title": "Menu Navigation",
    "noResults": "No results found",
    "shortcut": {
      "label": "Search",
      "key": "⌘K"
    }
  },
  "knowledge": {
    "title": "Knowledge Base",
    "description": "Here you can configure the knowledge base, including adding, deleting, and editing operations.",
    "columns": {
      "id": "ID",
      "status": "Status",
      "title": "Title",
      "category": "Category",
      "actions": "Actions"
    },
    "form": {
      "add": "Add Knowledge",
      "edit": "Edit Knowledge",
      "title": "Title",
      "titlePlaceholder": "Please enter knowledge title",
      "category": "Category",
      "categoryPlaceholder": "Please enter category, it will be automatically classified",
      "language": "Language",
      "languagePlaceholder": "Please select language",
      "content": "Content",
      "show": "Show",
      "cancel": "Cancel",
      "submit": "Submit"
    },
    "languages": {
      "en-US": "English",
      "ja-JP": "日本語",
      "ko-KR": "한국어",
      "vi-VN": "Tiếng Việt",
      "zh-CN": "简体中文",
      "zh-TW": "繁體中文",
      "ru-RU": "Russian"
    },
    "messages": {
      "deleteConfirm": "Confirm Delete",
      "deleteDescription": "This action will permanently delete this knowledge base record and cannot be recovered. Are you sure you want to continue?",
      "deleteButton": "Delete",
      "operationSuccess": "Operation Successful"
    },
    "toolbar": {
      "searchPlaceholder": "Search knowledge...",
      "reset": "Reset",
      "sortModeHint": "Drag knowledge items to sort, click save when done",
      "editSort": "Edit Sort",
      "saveSort": "Save Sort"
    }
  },
  "common": {
    "loading": "Loading...",
    "error": "Error",
    "success": "Success",
    "save": "Save",
    "cancel": "Cancel",
    "confirm": "Confirm",
    "close": "Close",
    "delete": {
      "success": "Deleted successfully",
      "failed": "Failed to delete"
    },
    "edit": "Edit",
    "view": "View",
    "toggleNavigation": "Toggle Navigation",
    "toggleSidebar": "Toggle Sidebar",
    "search": "Search...",
    "theme": {
      "light": "Light",
      "dark": "Dark",
      "system": "System"
    },
    "user": "User",
    "defaultEmail": "user@example.com",
    "settings": "Settings",
    "logout": "Logout",
    "copy": {
      "success": "Copied successfully",
      "failed": "Failed to copy",
      "error": "Copy failed",
      "errorLog": "Error copying to clipboard"
    },
    "submit": "Submit",
    "saving": "Saving...",
    "table": {
      "noData": "No data available",
      "pagination": {
        "selected": "{{selected}} of {{total}} items selected",
        "itemsPerPage": "Per page",
        "page": "Page",
        "pageOf": "of {{total}} pages",
        "firstPage": "Go to first page",
        "previousPage": "Previous page",
        "nextPage": "Next page",
        "lastPage": "Go to last page"
      },
      "viewOptions": {
        "button": "Columns",
        "label": "Toggle columns"
      }
    },
    "update": {
      "title": "System Update",
      "newVersion": "New Version Available",
      "currentVersion": "Current Version",
      "latestVersion": "Latest Version",
      "updateLater": "Update Later",
      "updateNow": "Update Now",
      "updating": "Updating...",
      "updateSuccess": "Update successful, system will restart shortly",
      "updateFailed": "Update failed, please try again later"
    },
    "time": {
      "day": "day",
      "hour": " hour(s)"
    },
    "reset": "Reset",
    "export": "Export",
    "currency": {
      "yuan": "Yuan"
    },
    "http": {
      "notLoggedIn": "Not logged in",
      "unknownError": "Unknown error",
      "loginExpired": "Login expired",
      "noPermission": "No permission",
      "notFound": "Resource or API not found",
      "unknownException": "Unknown exception"
    }
  },
  "sidebar": {
    "dashboard": "Dashboard",
    "systemManagement": "System Management",
    "systemConfig": "System Configuration",
    "themeConfig": "Theme Configuration",
    "noticeManagement": "Notice Management",
    "paymentConfig": "Payment Configuration",
    "knowledgeManagement": "Knowledge Base",
    "nodeManagement": "Node Management",
    "permissionGroupManagement": "Permission Groups",
    "routeManagement": "Route Management",
    "subscriptionManagement": "Subscription Management",
    "planManagement": "Plan Management",
    "orderManagement": "Order Management",
    "couponManagement": "Coupon Management",
    "userManagement": "User Management",
    "ticketManagement": "Ticket Management"
  },
  "plugin": {
    "title": "Plugin Management",
    "description": "Manage and configure system plugins",
    "search": {
      "placeholder": "Search plugin name or description..."
    },
    "type": {
      "placeholder": "Select Plugin Type",
      "all": "All Types"
    },
    "tabs": {
      "all": "All Plugins",
      "installed": "Installed",
      "available": "Available"
    },
    "status": {
      "enabled": "Enabled",
      "disabled": "Disabled",
      "not_installed": "Not Installed",
      "protected": "Protected",
      "filter_placeholder": "Install Status",
      "all": "All Status",
      "installed": "Installed",
      "available": "Available"
    },
    "button": {
      "install": "Install",
      "upgrade": "Upgrade",
      "config": "Configure",
      "enable": "Enable",
      "disable": "Disable",
      "uninstall": "Uninstall",
      "readme": "View Documentation",
      "menuDemo": "Menu Demo"
    },
    "upload": {
      "button": "Upload Plugin",
      "title": "Upload Plugin",
      "description": "Upload a plugin package (.zip)",
      "dragText": "Drag and drop plugin package here, or",
      "clickText": "browse",
      "supportText": "Supports .zip files only",
      "uploading": "Uploading...",
      "error": {
        "format": "Only .zip files are supported"
      }
    },
    "delete": {
      "title": "Delete Plugin",
      "description": "Are you sure you want to delete this plugin? This action cannot be undone.",
      "button": "Delete"
    },
    "uninstall": {
      "title": "Uninstall Plugin",
      "description": "Are you sure you want to uninstall this plugin? Plugin data will be cleared after uninstallation.",
      "button": "Uninstall"
    },
    "upgrade": {
      "title": "Upgrade Plugin",
      "description": "Are you sure you want to upgrade this plugin? The plugin will be temporarily unavailable during the upgrade process.",
      "button": "Upgrade"
    },
    "config": {
      "title": "Configuration",
      "description": "Modify plugin configuration",
      "save": "Save",
      "cancel": "Cancel"
    },
    "readme": {
      "title": "Plugin Documentation"
    },
    "author": "Author",
    "messages": {
      "installSuccess": "Plugin installed successfully",
      "installError": "Failed to install plugin",
      "upgradeSuccess": "Plugin upgraded successfully",
      "upgradeError": "Failed to upgrade plugin",
      "uninstallSuccess": "Plugin uninstalled successfully",
      "uninstallError": "Failed to uninstall plugin",
      "enableSuccess": "Plugin enabled successfully",
      "enableError": "Failed to enable plugin",
      "disableSuccess": "Plugin disabled successfully",
      "disableError": "Failed to disable plugin",
      "configLoadError": "Failed to load plugin configuration",
      "configSaveSuccess": "Configuration saved successfully",
      "configSaveError": "Failed to save configuration",
      "uploadSuccess": "Plugin uploaded successfully",
      "uploadError": "Failed to upload plugin",
      "deleteSuccess": "Plugin deleted successfully",
      "deleteError": "Failed to delete plugin"
    }
  },
  "dashboard": {
    "title": "Dashboard",
    "stats": {
      "newUsers": "New Users",
      "totalScore": "Total Score",
      "monthlyUpload": "Monthly Upload",
      "vsLastMonth": "vs Last Month",
      "vsYesterday": "vs Yesterday",
      "todayIncome": "Today's Income",
      "monthlyIncome": "Monthly Income",
      "totalIncome": "Total Income",
      "totalUsers": "Total Users",
      "activeUsers": "Active Users: {{count}}",
      "totalOrders": "Total Orders",
      "revenue": "Revenue",
      "todayRegistered": "Today Registered",
      "monthlyRegistered": "Monthly Registered",
      "onlineUsers": "Online Users",
      "pendingTickets": "Pending Tickets",
      "hasPendingTickets": "There are tickets that need attention",
      "noPendingTickets": "No pending tickets",
      "pendingCommission": "Pending Commission",
      "hasPendingCommission": "There are commissions that need confirmation",
      "noPendingCommission": "No pending commission",
      "monthlyNewUsers": "Monthly New Users",
      "monthlyDownload": "Monthly Download",
      "todayTraffic": "Today: {{value}}",
      "activeUserTrend": "Active User Trend",
      "realtimeUsers": "Realtime Users",
      "todayPeak": "Today's Peak",
      "vsLastWeek": "vs Last Week"
    },
    "trafficRank": {
      "nodeTrafficRank": "Node Traffic Rank",
      "userTrafficRank": "User Traffic Rank",
      "today": "Today",
      "last7days": "Last 7 Days",
      "last30days": "Last 30 Days",
      "customRange": "Custom Range",
      "selectTimeRange": "Select Time Range",
      "selectDateRange": "Select Date Range",
      "currentTraffic": "Current Traffic",
      "previousTraffic": "Previous Traffic",
      "changeRate": "Change Rate",
      "recordTime": "Record Time"
    },
    "overview": {
      "title": "Revenue Overview",
      "thisMonth": "This Month",
      "lastMonth": "Last Month",
      "to": "to",
      "selectTimeRange": "Select Range",
      "selectDate": "Select Date",
      "last7Days": "Last 7 Days",
      "last30Days": "Last 30 Days",
      "last90Days": "Last 90 Days",
      "last180Days": "Last 180 Days",
      "lastYear": "Last Year",
      "customRange": "Custom Range",
      "amount": "Amount",
      "count": "Count",
      "transactions": "{{count}} transactions",
      "orderAmount": "Order Amount",
      "commissionAmount": "Commission Amount",
      "orderCount": "Order Count",
      "commissionCount": "Commission Count",
      "totalIncome": "Total Income",
      "totalCommission": "Total Commission",
      "totalTransactions": "Total: {{count}} transactions",
      "avgOrderAmount": "Average Order Amount:",
      "commissionRate": "Commission Rate:"
    },
    "traffic": {
      "title": "Traffic Ranking",
      "rank": "Rank",
      "domain": "Domain",
      "todayTraffic": "Today's Traffic",
      "monthlyTraffic": "Monthly Traffic"
    },
    "queue": {
      "title": "Queue Status",
      "jobDetails": "Job Details",
      "status": {
        "description": "Current queue running status",
        "running": "Running Status",
        "normal": "Normal",
        "abnormal": "Abnormal",
        "waitTime": "Current wait time: {{seconds}} seconds",
        "pending": "Pending",
        "processing": "Processing",
        "completed": "Completed",
        "failed": "Failed",
        "cancelled": "Cancelled"
      },
      "details": {
        "description": "Queue processing details",
        "recentJobs": "Recent Jobs",
        "statisticsPeriod": "Statistics Period: {{hours}} hours",
        "jobsPerMinute": "Jobs Per Minute",
        "maxThroughput": "Max Throughput: {{value}}",
        "failedJobs7Days": "Failed Jobs (7 days)",
        "retentionPeriod": "Retention Period: {{hours}} hours",
        "longestRunningQueue": "Longest Running Queue",
        "activeProcesses": "Active Processes",
        "id": "Job ID",
        "type": "Job Type",
        "status": "Status",
        "progress": "Progress",
        "createdAt": "Created At",
        "updatedAt": "Updated At",
        "error": "Error Message",
        "data": "Job Data",
        "result": "Result",
        "duration": "Duration",
        "attempts": "Attempts",
        "nextRetry": "Next Retry",
        "failedJobsDetailTitle": "Failed Jobs Details",
        "viewFailedJobs": "View Failed Jobs",
        "jobDetailTitle": "Job Details",
        "time": "Time",
        "queue": "Queue",
        "name": "Job Name",
        "exception": "Exception",
        "noFailedJobs": "No failed jobs",
        "connection": "Connection",
        "payload": "Job Payload",
        "viewDetail": "View Details",
        "action": "Action"
      },
      "actions": {
        "retry": "Retry",
        "cancel": "Cancel",
        "delete": "Delete",
        "viewDetails": "View Details"
      },
      "empty": "No jobs in queue",
      "loading": "Loading queue status...",
      "error": "Failed to load queue status"
    },
    "common": {
      "refresh": "Refresh",
      "close": "Close",
      "pagination": "Page {{current}}/{{total}}, {{count}} items total"
    },
    "search": {
      "placeholder": "Search menus and functions...",
      "title": "Menu Navigation",
      "noResults": "No results found",
      "loading": "Searching..."
    }
  },
  "order": {
    "title": "Order Management",
    "description": "Here you can view user orders, including assignment, viewing, deletion and other operations.",
    "table": {
      "columns": {
        "tradeNo": "Order No.",
        "type": "Type",
        "plan": "Subscription Plan",
        "period": "Period",
        "amount": "Payment Amount",
        "status": "Order Status",
        "commission": "Commission Amount",
        "commissionStatus": "Commission Status",
        "createdAt": "Created At"
      }
    },
    "type": {
      "NEW": "New Purchase",
      "RENEWAL": "Renewal",
      "UPGRADE": "Upgrade",
      "RESET_FLOW": "Reset Traffic"
    },
    "period": {
      "month_price": "Monthly",
      "quarter_price": "Quarterly",
      "half_year_price": "Semi-annually",
      "year_price": "Annually",
      "two_year_price": "2 Years",
      "three_year_price": "3 Years",
      "onetime_price": "One-time",
      "reset_price": "Reset Package"
    },
    "status": {
      "PENDING": "Pending",
      "PROCESSING": "Processing",
      "CANCELLED": "Cancelled",
      "COMPLETED": "Completed",
      "DISCOUNTED": "Discounted",
      "tooltip": "After marking as [Paid], the system will proceed with activation and completion"
    },
    "commission": {
      "PENDING": "Pending",
      "PROCESSING": "Processing",
      "VALID": "Valid",
      "INVALID": "Invalid"
    },
    "actions": {
      "markAsPaid": "Mark as Paid",
      "cancel": "Cancel Order",
      "openMenu": "Open Menu",
      "reset": "Reset"
    },
    "search": {
      "placeholder": "Search orders..."
    },
    "dialog": {
      "title": "Order Information",
      "basicInfo": "Basic Information",
      "amountInfo": "Amount Information",
      "timeInfo": "Time Information",
      "commissionInfo": "Commission Information",
      "commissionStatusActive": "Active",
      "addOrder": "Add Order",
      "assignOrder": "Assign Order",
      "fields": {
        "userEmail": "User Email",
        "userPhone": "User Phone",
        "orderPeriod": "Order Period",
        "subscriptionPlan": "Subscription Plan",
        "callbackNo": "Callback No.",
        "paymentAmount": "Payment Amount",
        "balancePayment": "Balance Payment",
        "discountAmount": "Discount Amount",
        "refundAmount": "Refund Amount",
        "deductionAmount": "Deduction Amount",
        "createdAt": "Created At",
        "updatedAt": "Updated At",
        "commissionStatus": "Commission Status",
        "commissionAmount": "Commission Amount",
        "actualCommissionAmount": "Actual Commission",
        "inviteUser": "Inviter",
        "inviteUserId": "Inviter ID"
      },
      "placeholders": {
        "email": "Please enter user email",
        "plan": "Please select subscription plan",
        "period": "Please select subscription period",
        "amount": "Please enter payment amount"
      },
      "actions": {
        "cancel": "Cancel",
        "confirm": "Confirm"
      },
      "messages": {
        "addSuccess": "Added successfully"
      }
    }
  },
  "theme": {
    "title": "Theme Configuration",
    "description": "Theme configuration, including theme colors, font sizes, etc. If you deploy V2board in a front-end and back-end separated way, theme configuration will not take effect.",
    "upload": {
      "button": "Upload Theme",
      "title": "Upload Theme",
      "description": "Please upload a valid theme package (.zip format). The theme package should contain a complete theme file structure.",
      "dragText": "Drag and drop theme file here, or",
      "clickText": "click to select",
      "supportText": "Supports .zip format theme packages",
      "uploading": "Uploading...",
      "error": {
        "format": "Only ZIP format theme files are supported"
      }
    },
    "preview": {
      "title": "Theme Preview",
      "imageCount": "{{current}} / {{total}}"
    },
    "card": {
      "version": "Version: {{version}}",
      "currentTheme": "Current Theme",
      "activateTheme": "Activate Theme",
      "configureTheme": "Theme Settings",
      "preview": "Preview",
      "delete": {
        "title": "Delete Theme",
        "description": "Are you sure you want to delete this theme? This action cannot be undone.",
        "button": "Delete",
        "error": {
          "active": "Cannot delete the currently active theme"
        }
      }
    },
    "config": {
      "title": "Configure {{name}} Theme",
      "description": "Modify theme styles, layouts, and other display options.",
      "cancel": "Cancel",
      "save": "Save",
      "success": "Settings saved successfully"
    }
  }
};
